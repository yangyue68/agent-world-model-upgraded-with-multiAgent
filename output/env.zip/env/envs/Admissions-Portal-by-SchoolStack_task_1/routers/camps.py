from typing import Optional
from fastapi import APIRouter, HTTPException, Query
from sqlalchemy import and_
from database import SessionLocal
from models import Camp, Applicant, User, Document
from schemas import (
    CampOut,
    CampCreate,
    CampUpdate,
    CampListOut,
    CampDeleteOut,
    ApplicantOut,
    ApplicantListOut,
)

router = APIRouter(prefix="/api/camps", tags=["Camps"])


@router.get("", summary="List all camps", description="Retrieve a list of all camps with optional filtering by name, term, and year.", tags=["Camps"], operation_id="list_camps", response_model=CampListOut)
async def list_camps(
    name: Optional[str] = Query(None),
    term: Optional[str] = Query(None),
    year: Optional[int] = Query(None),
):
    session = SessionLocal()
    query = session.query(Camp)
    if name is not None:
        query = query.filter(Camp.name == name)
    if term is not None:
        query = query.filter(Camp.term == term)
    if year is not None:
        query = query.filter(Camp.year == year)
    camps = query.all()
    result = CampListOut(camps=[CampOut.model_validate(c, from_attributes=True) for c in camps])
    session.close()
    return result


@router.get("/{camp_id}", summary="Get a camp by ID", description="Retrieve a single camp by its unique identifier.", tags=["Camps"], operation_id="get_camp", response_model=CampOut)
async def get_camp(camp_id: int):
    session = SessionLocal()
    camp = session.query(Camp).filter(Camp.id == camp_id).first()
    if camp is None:
        session.close()
        raise HTTPException(status_code=404, detail="Camp not found")
    result = CampOut.model_validate(camp, from_attributes=True)
    session.close()
    return result


@router.post("", summary="Create a new camp", description="Create a new camp with the provided name, term, year, and optional dates.", tags=["Camps"], operation_id="create_camp", response_model=CampOut)
async def create_camp(payload: CampCreate):
    session = SessionLocal()
    existing = (
        session.query(Camp)
        .filter(and_(Camp.name == payload.name, Camp.term == payload.term, Camp.year == payload.year))
        .first()
    )
    if existing is not None:
        session.close()
        raise HTTPException(status_code=409, detail="Camp with same name, term, and year already exists")
    camp = Camp(
        name=payload.name,
        term=payload.term,
        year=payload.year,
        start_date=payload.start_date,
        end_date=payload.end_date,
    )
    session.add(camp)
    session.commit()
    session.refresh(camp)
    result = CampOut.model_validate(camp, from_attributes=True)
    session.close()
    return result


@router.put("/{camp_id}", summary="Update a camp", description="Update an existing camp's details by its unique identifier.", tags=["Camps"], operation_id="update_camp", response_model=CampOut)
async def update_camp(camp_id: int, payload: CampUpdate):
    session = SessionLocal()
    camp = session.query(Camp).filter(Camp.id == camp_id).first()
    if camp is None:
        session.close()
        raise HTTPException(status_code=404, detail="Camp not found")
    if payload.name is not None:
        camp.name = payload.name
    if payload.term is not None:
        camp.term = payload.term
    if payload.year is not None:
        camp.year = payload.year
    if payload.start_date is not None:
        camp.start_date = payload.start_date
    if payload.end_date is not None:
        camp.end_date = payload.end_date
    session.commit()
    session.refresh(camp)
    result = CampOut.model_validate(camp, from_attributes=True)
    session.close()
    return result


@router.delete("/{camp_id}", summary="Delete a camp", description="Delete a camp by its unique identifier.", tags=["Camps"], operation_id="delete_camp", response_model=CampDeleteOut)
async def delete_camp(camp_id: int):
    session = SessionLocal()
    camp = session.query(Camp).filter(Camp.id == camp_id).first()
    if camp is None:
        session.close()
        raise HTTPException(status_code=404, detail="Camp not found")
    session.delete(camp)
    session.commit()
    session.close()
    return CampDeleteOut(message="Camp deleted successfully.")


@router.get("/{camp_id}/applicants", summary="List applicants for a camp", description="Retrieve a list of applicants for a specific camp, with optional filtering by application status and document type.", tags=["Camps"], operation_id="list_camp_applicants", response_model=ApplicantListOut)
async def list_camp_applicants(
    camp_id: int,
    application_status: Optional[str] = Query(None),
    missing_document_type: Optional[str] = Query(None),
):
    session = SessionLocal()
    camp = session.query(Camp).filter(Camp.id == camp_id).first()
    if camp is None:
        session.close()
        raise HTTPException(status_code=404, detail="Camp not found")
    query = session.query(Applicant, User).join(User, User.id == Applicant.user_id).filter(Applicant.camp_id == camp_id)
    if application_status is not None:
        query = query.filter(Applicant.application_status == application_status)
    if missing_document_type is not None:
        query = query.filter(
            ~session.query(Document.id)
            .filter(
                and_(
                    Document.applicant_id == Applicant.id,
                    Document.document_type == missing_document_type,
                )
            )
            .exists()
        )
    rows = query.all()
    applicants = []
    for applicant, user in rows:
        applicants.append(
            ApplicantOut(
                id=applicant.id,
                user_id=applicant.user_id,
                camp_id=applicant.camp_id,
                application_status=applicant.application_status,
                full_name=user.full_name,
                email=user.email,
                created_at=applicant.created_at,
                updated_at=applicant.updated_at,
            )
        )
    result = ApplicantListOut(applicants=applicants)
    session.close()
    return result