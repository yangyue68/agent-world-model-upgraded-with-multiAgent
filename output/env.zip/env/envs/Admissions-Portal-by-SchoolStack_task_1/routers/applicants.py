from typing import Optional
from fastapi import APIRouter, HTTPException, Query
from sqlalchemy import and_
from database import SessionLocal
from models import Applicant, User, Camp, Document
from schemas import (
    ApplicantOut,
    ApplicantCreate,
    ApplicantReplace,
    ApplicantUpdate,
    ApplicantListOut,
    ApplicantDeleteOut,
    DocumentOut,
    DocumentCreate,
    DocumentListOut,
    DocumentDeleteOut,
)

router = APIRouter(prefix="/api/applicants", tags=["Applicants"])

VALID_STATUSES = [
    "Incomplete",
    "Complete",
    "Submitted",
    "Under Review",
    "Accepted",
    "Rejected",
    "Waitlisted",
]

VALID_DOC_TYPES = [
    "Recommendation Letter",
    "Transcript",
    "Essay",
    "Resume",
    "Other",
]


def _build_applicant_out(applicant: Applicant, user: Optional[User]) -> ApplicantOut:
    return ApplicantOut(
        id=applicant.id,
        user_id=applicant.user_id,
        camp_id=applicant.camp_id,
        application_status=applicant.application_status,
        full_name=user.full_name if user is not None else None,
        email=user.email if user is not None else None,
        created_at=applicant.created_at,
        updated_at=applicant.updated_at,
    )


@router.get("", summary="List applicants with optional filters", description="Retrieve applicants filtered by camp, status, and missing document type.", tags=["Applicants"], operation_id="list_applicants", response_model=ApplicantListOut)
async def list_applicants(
    camp_name: Optional[str] = Query(None),
    camp_term: Optional[str] = Query(None),
    camp_year: Optional[int] = Query(None),
    application_status: Optional[str] = Query(None),
    missing_document_type: Optional[str] = Query(None),
):
    session = SessionLocal()
    query = session.query(Applicant, User).join(User, User.id == Applicant.user_id)
    if camp_name is not None or camp_term is not None or camp_year is not None:
        query = query.join(Camp, Camp.id == Applicant.camp_id)
        if camp_name is not None:
            query = query.filter(Camp.name == camp_name)
        if camp_term is not None:
            query = query.filter(Camp.term == camp_term)
        if camp_year is not None:
            query = query.filter(Camp.year == camp_year)
    if application_status is not None:
        query = query.filter(Applicant.application_status == application_status)
    if missing_document_type is not None:
        query = query.filter(
            ~session.query(Document.id)
            .filter(
                and_(
                    Document.applicant_id == Applicant.id,
                    Document.document_type == missing_document_type,
                )
            )
            .exists()
        )
    rows = query.all()
    applicants = [_build_applicant_out(a, u) for a, u in rows]
    result = ApplicantListOut(applicants=applicants)
    session.close()
    return result


@router.get("/{applicant_id}", summary="Get a single applicant by ID", description="Retrieve details of a specific applicant including user info.", tags=["Applicants"], operation_id="get_applicant", response_model=ApplicantOut)
async def get_applicant(applicant_id: int):
    session = SessionLocal()
    applicant = session.query(Applicant).filter(Applicant.id == applicant_id).first()
    if applicant is None:
        session.close()
        raise HTTPException(status_code=404, detail="Applicant not found")
    user = session.query(User).filter(User.id == applicant.user_id).first()
    result = _build_applicant_out(applicant, user)
    session.close()
    return result


@router.post("", summary="Create a new applicant", description="Create an applicant record for a user and camp.", tags=["Applicants"], operation_id="create_applicant", response_model=ApplicantOut)
async def create_applicant(payload: ApplicantCreate):
    session = SessionLocal()
    if payload.application_status not in VALID_STATUSES:
        session.close()
        raise HTTPException(status_code=422, detail="Invalid application_status")
    user = session.query(User).filter(User.id == payload.user_id).first()
    if user is None:
        session.close()
        raise HTTPException(status_code=404, detail="User not found")
    camp = session.query(Camp).filter(Camp.id == payload.camp_id).first()
    if camp is None:
        session.close()
        raise HTTPException(status_code=404, detail="Camp not found")
    existing = (
        session.query(Applicant)
        .filter(and_(Applicant.user_id == payload.user_id, Applicant.camp_id == payload.camp_id))
        .first()
    )
    if existing is not None:
        session.close()
        raise HTTPException(status_code=409, detail="Applicant already exists for this user and camp")
    applicant = Applicant(
        user_id=payload.user_id,
        camp_id=payload.camp_id,
        application_status=payload.application_status,
    )
    session.add(applicant)
    session.commit()
    session.refresh(applicant)
    result = _build_applicant_out(applicant, user)
    session.close()
    return result


@router.put("/{applicant_id}", summary="Replace an applicant record", description="Update all fields of an existing applicant.", tags=["Applicants"], operation_id="replace_applicant", response_model=ApplicantOut)
async def replace_applicant(applicant_id: int, payload: ApplicantReplace):
    session = SessionLocal()
    applicant = session.query(Applicant).filter(Applicant.id == applicant_id).first()
    if applicant is None:
        session.close()
        raise HTTPException(status_code=404, detail="Applicant not found")
    if payload.application_status not in VALID_STATUSES:
        session.close()
        raise HTTPException(status_code=422, detail="Invalid application_status")
    user = session.query(User).filter(User.id == payload.user_id).first()
    if user is None:
        session.close()
        raise HTTPException(status_code=404, detail="User not found")
    camp = session.query(Camp).filter(Camp.id == payload.camp_id).first()
    if camp is None:
        session.close()
        raise HTTPException(status_code=404, detail="Camp not found")
    conflict = (
        session.query(Applicant)
        .filter(
            and_(
                Applicant.user_id == payload.user_id,
                Applicant.camp_id == payload.camp_id,
                Applicant.id != applicant_id,
            )
        )
        .first()
    )
    if conflict is not None:
        session.close()
        raise HTTPException(status_code=409, detail="Applicant already exists for this user and camp")
    applicant.user_id = payload.user_id
    applicant.camp_id = payload.camp_id
    applicant.application_status = payload.application_status
    session.commit()
    session.refresh(applicant)
    result = _build_applicant_out(applicant, user)
    session.close()
    return result


@router.patch("/{applicant_id}", summary="Update applicant fields", description="Partially update an applicant's status or associations.", tags=["Applicants"], operation_id="update_applicant", response_model=ApplicantOut)
async def update_applicant(applicant_id: int, payload: ApplicantUpdate):
    session = SessionLocal()
    applicant = session.query(Applicant).filter(Applicant.id == applicant_id).first()
    if applicant is None:
        session.close()
        raise HTTPException(status_code=404, detail="Applicant not found")
    if payload.application_status is not None:
        if payload.application_status not in VALID_STATUSES:
            session.close()
            raise HTTPException(status_code=422, detail="Invalid application_status")
        applicant.application_status = payload.application_status
    if payload.camp_id is not None:
        camp = session.query(Camp).filter(Camp.id == payload.camp_id).first()
        if camp is None:
            session.close()
            raise HTTPException(status_code=404, detail="Camp not found")
        applicant.camp_id = payload.camp_id
    if payload.user_id is not None:
        user = session.query(User).filter(User.id == payload.user_id).first()
        if user is None:
            session.close()
            raise HTTPException(status_code=404, detail="User not found")
        applicant.user_id = payload.user_id
    session.commit()
    session.refresh(applicant)
    user = session.query(User).filter(User.id == applicant.user_id).first()
    result = _build_applicant_out(applicant, user)
    session.close()
    return result


@router.delete("/{applicant_id}", summary="Delete an applicant", description="Remove an applicant record and associated documents.", tags=["Applicants"], operation_id="delete_applicant", response_model=ApplicantDeleteOut)
async def delete_applicant(applicant_id: int):
    session = SessionLocal()
    applicant = session.query(Applicant).filter(Applicant.id == applicant_id).first()
    if applicant is None:
        session.close()
        raise HTTPException(status_code=404, detail="Applicant not found")
    session.delete(applicant)
    session.commit()
    session.close()
    return ApplicantDeleteOut(deleted=True)


@router.get("/{applicant_id}/documents", summary="List documents for an applicant", description="Retrieve all documents uploaded by a specific applicant.", tags=["Applicants"], operation_id="list_applicant_documents", response_model=DocumentListOut)
async def list_applicant_documents(applicant_id: int):
    session = SessionLocal()
    applicant = session.query(Applicant).filter(Applicant.id == applicant_id).first()
    if applicant is None:
        session.close()
        raise HTTPException(status_code=404, detail="Applicant not found")
    documents = session.query(Document).filter(Document.applicant_id == applicant_id).all()
    result = DocumentListOut(
        documents=[DocumentOut.model_validate(d, from_attributes=True) for d in documents],
        total=len(documents),
    )
    session.close()
    return result


@router.post("/{applicant_id}/documents", summary="Upload a document for an applicant", description="Add a new document record for the specified applicant.", tags=["Applicants"], operation_id="create_applicant_document", response_model=DocumentOut)
async def create_applicant_document(applicant_id: int, payload: DocumentCreate):
    session = SessionLocal()
    applicant = session.query(Applicant).filter(Applicant.id == applicant_id).first()
    if applicant is None:
        session.close()
        raise HTTPException(status_code=404, detail="Applicant not found")
    if payload.document_type not in VALID_DOC_TYPES:
        session.close()
        raise HTTPException(status_code=422, detail="Invalid document_type")
    document = Document(
        applicant_id=applicant_id,
        document_type=payload.document_type,
        file_path=payload.file_path,
    )
    session.add(document)
    session.commit()
    session.refresh(document)
    result = DocumentOut.model_validate(document, from_attributes=True)
    session.close()
    return result


@router.delete("/{applicant_id}/documents/{document_id}", summary="Delete a document from an applicant", description="Remove a specific document record for an applicant.", tags=["Applicants"], operation_id="delete_applicant_document", response_model=DocumentDeleteOut)
async def delete_applicant_document(applicant_id: int, document_id: int):
    session = SessionLocal()
    applicant = session.query(Applicant).filter(Applicant.id == applicant_id).first()
    if applicant is None:
        session.close()
        raise HTTPException(status_code=404, detail="Applicant not found")
    document = (
        session.query(Document)
        .filter(and_(Document.id == document_id, Document.applicant_id == applicant_id))
        .first()
    )
    if document is None:
        session.close()
        raise HTTPException(status_code=404, detail="Document not found")
    session.delete(document)
    session.commit()
    session.close()
    return DocumentDeleteOut(deleted=True)