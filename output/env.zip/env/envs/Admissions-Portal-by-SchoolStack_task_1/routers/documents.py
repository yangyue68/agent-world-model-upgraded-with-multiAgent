from datetime import datetime
from typing import Optional
from fastapi import APIRouter, HTTPException, Query
from database import SessionLocal
from models import Document, Applicant
from schemas import (
    DocumentOut,
    DocumentCreate,
    DocumentReplace,
    DocumentUpdate,
    DocumentListOut,
    DocumentDeleteOut,
)

router = APIRouter(prefix="/api/documents", tags=["Documents"])

VALID_DOC_TYPES = [
    "Recommendation Letter",
    "Transcript",
    "Essay",
    "Resume",
    "Other",
]


@router.get("", summary="List documents for the current user's applicants", description="Retrieve documents filtered by applicant_id, document_type, or uploaded_at.", tags=["Documents"], operation_id="list_documents", response_model=DocumentListOut)
async def list_documents(
    applicant_id: Optional[int] = Query(None),
    document_type: Optional[str] = Query(None),
    uploaded_after: Optional[str] = Query(None),
    limit: Optional[int] = Query(None),
    offset: Optional[int] = Query(None),
):
    session = SessionLocal()
    query = session.query(Document)
    if applicant_id is not None:
        query = query.filter(Document.applicant_id == applicant_id)
    if document_type is not None:
        query = query.filter(Document.document_type == document_type)
    if uploaded_after is not None:
        try:
            parsed = datetime.fromisoformat(uploaded_after.replace("Z", "+00:00"))
        except ValueError:
            session.close()
            raise HTTPException(status_code=422, detail="Invalid uploaded_after datetime format")
        query = query.filter(Document.uploaded_at >= parsed)
    total = query.count()
    if offset is not None:
        query = query.offset(offset)
    if limit is not None:
        query = query.limit(limit)
    documents = query.all()
    result = DocumentListOut(
        documents=[DocumentOut.model_validate(d, from_attributes=True) for d in documents],
        total=total,
    )
    session.close()
    return result


@router.post("", summary="Upload a new document for an applicant", description="Create a document record for the given applicant and document type.", tags=["Documents"], operation_id="create_document", response_model=DocumentOut)
async def create_document(payload: DocumentCreate):
    session = SessionLocal()
    if payload.applicant_id is None:
        session.close()
        raise HTTPException(status_code=422, detail="applicant_id is required")
    applicant = session.query(Applicant).filter(Applicant.id == payload.applicant_id).first()
    if applicant is None:
        session.close()
        raise HTTPException(status_code=404, detail="Applicant not found")
    if payload.document_type not in VALID_DOC_TYPES:
        session.close()
        raise HTTPException(status_code=422, detail="Invalid document_type")
    document = Document(
        applicant_id=payload.applicant_id,
        document_type=payload.document_type,
        file_path=payload.file_path,
    )
    session.add(document)
    session.commit()
    session.refresh(document)
    result = DocumentOut.model_validate(document, from_attributes=True)
    session.close()
    return result


@router.get("/{document_id}", summary="Get a document by ID", description="Retrieve a single document record by its ID.", tags=["Documents"], operation_id="get_document", response_model=DocumentOut)
async def get_document(document_id: int):
    session = SessionLocal()
    document = session.query(Document).filter(Document.id == document_id).first()
    if document is None:
        session.close()
        raise HTTPException(status_code=404, detail="Document not found")
    result = DocumentOut.model_validate(document, from_attributes=True)
    session.close()
    return result


@router.put("/{document_id}", summary="Replace a document record", description="Update all fields of an existing document record.", tags=["Documents"], operation_id="replace_document", response_model=DocumentOut)
async def replace_document(document_id: int, payload: DocumentReplace):
    session = SessionLocal()
    document = session.query(Document).filter(Document.id == document_id).first()
    if document is None:
        session.close()
        raise HTTPException(status_code=404, detail="Document not found")
    applicant = session.query(Applicant).filter(Applicant.id == payload.applicant_id).first()
    if applicant is None:
        session.close()
        raise HTTPException(status_code=404, detail="Applicant not found")
    if payload.document_type not in VALID_DOC_TYPES:
        session.close()
        raise HTTPException(status_code=422, detail="Invalid document_type")
    document.applicant_id = payload.applicant_id
    document.document_type = payload.document_type
    document.file_path = payload.file_path
    session.commit()
    session.refresh(document)
    result = DocumentOut.model_validate(document, from_attributes=True)
    session.close()
    return result


@router.patch("/{document_id}", summary="Partially update a document record", description="Update one or more fields of an existing document record.", tags=["Documents"], operation_id="update_document", response_model=DocumentOut)
async def update_document(document_id: int, payload: DocumentUpdate):
    session = SessionLocal()
    document = session.query(Document).filter(Document.id == document_id).first()
    if document is None:
        session.close()
        raise HTTPException(status_code=404, detail="Document not found")
    if payload.applicant_id is not None:
        applicant = session.query(Applicant).filter(Applicant.id == payload.applicant_id).first()
        if applicant is None:
            session.close()
            raise HTTPException(status_code=404, detail="Applicant not found")
        document.applicant_id = payload.applicant_id
    if payload.document_type is not None:
        if payload.document_type not in VALID_DOC_TYPES:
            session.close()
            raise HTTPException(status_code=422, detail="Invalid document_type")
        document.document_type = payload.document_type
    if payload.file_path is not None:
        document.file_path = payload.file_path
    session.commit()
    session.refresh(document)
    result = DocumentOut.model_validate(document, from_attributes=True)
    session.close()
    return result


@router.delete("/{document_id}", summary="Delete a document record", description="Delete a document record by its ID.", tags=["Documents"], operation_id="delete_document", response_model=DocumentDeleteOut)
async def delete_document(document_id: int):
    session = SessionLocal()
    document = session.query(Document).filter(Document.id == document_id).first()
    if document is None:
        session.close()
        raise HTTPException(status_code=404, detail="Document not found")
    session.delete(document)
    session.commit()
    session.close()
    return DocumentDeleteOut(deleted=True)