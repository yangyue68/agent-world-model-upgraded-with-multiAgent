from typing import Optional
from fastapi import APIRouter, HTTPException, Query
from sqlalchemy import and_
from database import SessionLocal
from models import User, Applicant, Camp, Document
from schemas import (
    UserOut,
    UserCreate,
    UserUpdate,
    UserListOut,
    CampDeleteOut,
    IncompleteApplicantOut,
    IncompleteApplicantListOut,
)

router = APIRouter(prefix="/api/users", tags=["Users"])


@router.get("", summary="List all users", description="Retrieve a list of all users with optional filtering by email.", tags=["Users"], operation_id="list_users", response_model=UserListOut)
async def list_users(email: Optional[str] = Query(None)):
    session = SessionLocal()
    query = session.query(User)
    if email is not None:
        query = query.filter(User.email == email)
    users = query.all()
    result = UserListOut(users=[UserOut.model_validate(u, from_attributes=True) for u in users])
    session.close()
    return result


@router.get("/incomplete-applicants", summary="List incomplete applicants without recommendation letter", description="Retrieve names and emails of applicants with status 'Incomplete' and no recommendation letter for a given camp.", tags=["Users"], operation_id="list_incomplete_applicants_without_recommendation", response_model=IncompleteApplicantListOut)
async def list_incomplete_applicants_without_recommendation(
    camp_name: str = Query(...),
    term: str = Query(...),
    year: int = Query(...),
):
    session = SessionLocal()
    rows = (
        session.query(User.full_name, User.email)
        .join(Applicant, Applicant.user_id == User.id)
        .join(Camp, Camp.id == Applicant.camp_id)
        .filter(
            and_(
                Camp.name == camp_name,
                Camp.term == term,
                Camp.year == year,
                Applicant.application_status == "Incomplete",
                ~session.query(Document.id)
                .filter(
                    and_(
                        Document.applicant_id == Applicant.id,
                        Document.document_type == "Recommendation Letter",
                    )
                )
                .exists(),
            )
        )
        .all()
    )
    applicants = [IncompleteApplicantOut(full_name=r[0], email=r[1]) for r in rows]
    result = IncompleteApplicantListOut(applicants=applicants)
    session.close()
    return result


@router.get("/{id}", summary="Get a user by ID", description="Retrieve a single user by their unique identifier.", tags=["Users"], operation_id="get_user", response_model=UserOut)
async def get_user(id: int):
    session = SessionLocal()
    user = session.query(User).filter(User.id == id).first()
    if user is None:
        session.close()
        raise HTTPException(status_code=404, detail="User not found")
    result = UserOut.model_validate(user, from_attributes=True)
    session.close()
    return result


@router.post("", summary="Create a new user", description="Create a new user with full name and email.", tags=["Users"], operation_id="create_user", response_model=UserOut)
async def create_user(payload: UserCreate):
    session = SessionLocal()
    existing = session.query(User).filter(User.email == payload.email).first()
    if existing is not None:
        session.close()
        raise HTTPException(status_code=409, detail="Email already exists")
    user = User(full_name=payload.full_name, email=payload.email)
    session.add(user)
    session.commit()
    session.refresh(user)
    result = UserOut.model_validate(user, from_attributes=True)
    session.close()
    return result


@router.put("/{id}", summary="Update a user", description="Update an existing user's full name and email.", tags=["Users"], operation_id="update_user", response_model=UserOut)
async def update_user(id: int, payload: UserUpdate):
    session = SessionLocal()
    user = session.query(User).filter(User.id == id).first()
    if user is None:
        session.close()
        raise HTTPException(status_code=404, detail="User not found")
    conflict = session.query(User).filter(User.email == payload.email, User.id != id).first()
    if conflict is not None:
        session.close()
        raise HTTPException(status_code=409, detail="Email already exists")
    user.full_name = payload.full_name
    user.email = payload.email
    session.commit()
    session.refresh(user)
    result = UserOut.model_validate(user, from_attributes=True)
    session.close()
    return result


@router.delete("/{id}", summary="Delete a user", description="Delete a user by their unique identifier.", tags=["Users"], operation_id="delete_user", response_model=CampDeleteOut)
async def delete_user(id: int):
    session = SessionLocal()
    user = session.query(User).filter(User.id == id).first()
    if user is None:
        session.close()
        raise HTTPException(status_code=404, detail="User not found")
    session.delete(user)
    session.commit()
    session.close()
    return CampDeleteOut(message="User deleted successfully.")