from datetime import date, datetime
from typing import Optional, List
from pydantic import BaseModel, ConfigDict, Field

class UserOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    full_name: str
    email: str
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class UserCreate(BaseModel):
    full_name: str
    email: str

class UserUpdate(BaseModel):
    full_name: str
    email: str

class UserListOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    users: List[UserOut]

class CampOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    name: str
    term: str
    year: int
    start_date: Optional[date] = None
    end_date: Optional[date] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class CampCreate(BaseModel):
    name: str
    term: str
    year: int
    start_date: Optional[date] = None
    end_date: Optional[date] = None

class CampUpdate(BaseModel):
    name: Optional[str] = None
    term: Optional[str] = None
    year: Optional[int] = None
    start_date: Optional[date] = None
    end_date: Optional[date] = None

class CampListOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    camps: List[CampOut]

class CampDeleteOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    message: str

class ApplicantOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    user_id: int
    camp_id: int
    application_status: str
    full_name: Optional[str] = None
    email: Optional[str] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class ApplicantCreate(BaseModel):
    user_id: int
    camp_id: int
    application_status: str

class ApplicantReplace(BaseModel):
    user_id: int
    camp_id: int
    application_status: str

class ApplicantUpdate(BaseModel):
    user_id: Optional[int] = None
    camp_id: Optional[int] = None
    application_status: Optional[str] = None

class ApplicantListOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    applicants: List[ApplicantOut]

class ApplicantDeleteOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    deleted: bool

class DocumentOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    applicant_id: int
    document_type: str
    file_path: str
    uploaded_at: Optional[datetime] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class DocumentCreate(BaseModel):
    applicant_id: Optional[int] = None
    document_type: str
    file_path: str

class DocumentReplace(BaseModel):
    applicant_id: int
    document_type: str
    file_path: str

class DocumentUpdate(BaseModel):
    applicant_id: Optional[int] = None
    document_type: Optional[str] = None
    file_path: Optional[str] = None

class DocumentListOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    documents: List[DocumentOut]
    total: int

class DocumentDeleteOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    deleted: bool

class IncompleteApplicantOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    full_name: str
    email: str

class IncompleteApplicantListOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    applicants: List[IncompleteApplicantOut]