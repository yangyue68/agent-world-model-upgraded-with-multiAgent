import os
import uvicorn
from fastapi import FastAPI
from database import Base, engine
from routers import users, camps, applicants, documents

Base.metadata.create_all(bind=engine)

app = FastAPI(title="Admissions Portal by SchoolStack", version="1.0.0")

app.include_router(users.router)
app.include_router(camps.router)
app.include_router(applicants.router)
app.include_router(documents.router)


@app.get("/", summary="Root", description="Root endpoint returning service info.", tags=["Root"], operation_id="root")
async def root():
    return {"service": "Admissions Portal by SchoolStack", "status": "ok"}


if __name__ == "__main__":
    host = os.getenv("HOST", "127.0.0.1")
    port = int(os.getenv("PORT", "8000"))
    uvicorn.run(app, host=host, port=port)