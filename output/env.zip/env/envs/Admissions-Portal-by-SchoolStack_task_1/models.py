from sqlalchemy import Column, Integer, String, Date, DateTime, ForeignKey, UniqueConstraint, Index, func
from sqlalchemy.orm import relationship
from database import Base


class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True)
    full_name = Column(String, nullable=False)
    email = Column(String, unique=True, nullable=False)
    created_at = Column(DateTime, default=func.current_timestamp())
    updated_at = Column(DateTime, default=func.current_timestamp())

    applicants = relationship("Applicant", back_populates="user", cascade="all, delete-orphan")

    __table_args__ = (
        Index("idx_users_email", "email"),
    )


class Camp(Base):
    __tablename__ = "camps"

    id = Column(Integer, primary_key=True)
    name = Column(String, nullable=False)
    term = Column(String, nullable=False)
    year = Column(Integer, nullable=False)
    start_date = Column(Date, nullable=True)
    end_date = Column(Date, nullable=True)
    created_at = Column(DateTime, default=func.current_timestamp())
    updated_at = Column(DateTime, default=func.current_timestamp())

    applicants = relationship("Applicant", back_populates="camp", cascade="all, delete-orphan")

    __table_args__ = (
        UniqueConstraint("name", "term", "year", name="uq_camps_name_term_year"),
        Index("idx_camps_name_term_year", "name", "term", "year"),
    )


class Applicant(Base):
    __tablename__ = "applicants"

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    camp_id = Column(Integer, ForeignKey("camps.id", ondelete="CASCADE"), nullable=False)
    application_status = Column(String, nullable=False)
    created_at = Column(DateTime, default=func.current_timestamp())
    updated_at = Column(DateTime, default=func.current_timestamp())

    user = relationship("User", back_populates="applicants")
    camp = relationship("Camp", back_populates="applicants")
    documents = relationship("Document", back_populates="applicant", cascade="all, delete-orphan")

    __table_args__ = (
        UniqueConstraint("user_id", "camp_id", name="uq_applicants_user_camp"),
        Index("idx_applicants_camp_status", "camp_id", "application_status"),
        Index("idx_applicants_user_id", "user_id"),
    )


class Document(Base):
    __tablename__ = "documents"

    id = Column(Integer, primary_key=True)
    applicant_id = Column(Integer, ForeignKey("applicants.id", ondelete="CASCADE"), nullable=False)
    document_type = Column(String, nullable=False)
    file_path = Column(String, nullable=False)
    uploaded_at = Column(DateTime, default=func.current_timestamp())
    created_at = Column(DateTime, default=func.current_timestamp())
    updated_at = Column(DateTime, default=func.current_timestamp())

    applicant = relationship("Applicant", back_populates="documents")

    __table_args__ = (
        Index("idx_documents_applicant_type", "applicant_id", "document_type"),
    )