import os
import uvicorn
from fastapi import FastAPI
from database import Base, engine
from routers import programs, applicants

Base.metadata.create_all(bind=engine)

app = FastAPI(title="Admissions Portal by SchoolStack", version="1.0.0")

app.include_router(programs.router)
app.include_router(applicants.router)


@app.get("/", tags=["Health"], summary="Health check", description="Returns a simple health check message.", operation_id="health_check")
async def health_check():
    return {"status": "ok"}


if __name__ == "__main__":
    host = os.getenv("HOST", "127.0.0.1")
    port = int(os.getenv("PORT", "8000"))
    uvicorn.run(app, host=host, port=port)