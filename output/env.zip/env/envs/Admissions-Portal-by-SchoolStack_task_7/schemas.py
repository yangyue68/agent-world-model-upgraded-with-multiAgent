from datetime import datetime
from typing import List, Optional
from pydantic import BaseModel, ConfigDict, Field

class ProgramCreate(BaseModel):
    name: str = Field(..., description='Name of the program.')
    term: str = Field(..., description='Term of the program.')

class ProgramUpdate(BaseModel):
    name: str = Field(..., description='New name of the program.')
    term: str = Field(..., description='New term of the program.')

class ProgramOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    name: str
    term: str
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class ProgramListOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    programs: List[ProgramOut]

class ApplicantOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    applicant_code: str
    full_name: str
    phone: Optional[str] = None
    mailing_address: Optional[str] = None
    city: Optional[str] = None
    state: Optional[str] = None
    postal_code: Optional[str] = None
    program_id: int
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class ApplicantListOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    applicants: List[ApplicantOut]

class ApplicantUpdate(BaseModel):
    phone: Optional[str] = Field(None, description='New phone number.')
    mailing_address: Optional[str] = Field(None, description='New street address.')
    city: Optional[str] = Field(None, description='New city.')
    state: Optional[str] = Field(None, description='New state or province.')
    postal_code: Optional[str] = Field(None, description='New postal code.')

class ApplicantNoteCreate(BaseModel):
    note: str = Field(..., description='Text content of the internal note.')

class ApplicantNoteUpdate(BaseModel):
    note: str = Field(..., description='New content of the note.')

class ApplicantNoteOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    applicant_id: int
    user_id: int
    note: str
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class ApplicantNoteListOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    notes: List[ApplicantNoteOut]
    total: int

class DeleteNoteOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    deleted: bool

class MessageOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    message: str