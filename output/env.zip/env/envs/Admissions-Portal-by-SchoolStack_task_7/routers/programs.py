from fastapi import APIRouter, Body, HTTPException, Query
from sqlalchemy.exc import IntegrityError
from database import SessionLocal
from models import Program, Applicant
from schemas import ProgramCreate, ProgramUpdate, ProgramOut, ProgramListOut, ApplicantListOut, ApplicantOut, MessageOut

router = APIRouter(prefix="/api/programs", tags=["Programs"])


@router.get("", response_model=ProgramListOut, summary="List all programs", description="Retrieve a list of all programs with optional filtering by name and term.", operation_id="list_programs")
async def list_programs(name: str = Query(None), term: str = Query(None)):
    session = SessionLocal()
    try:
        query = session.query(Program)
        if name is not None:
            query = query.filter(Program.name == name)
        if term is not None:
            query = query.filter(Program.term == term)
        programs = query.all()
        return ProgramListOut(programs=[ProgramOut.model_validate(p, from_attributes=True) for p in programs])
    finally:
        session.close()


@router.post("", response_model=ProgramOut, summary="Create a new program", description="Create a new program with a unique name and term combination.", operation_id="create_program")
async def create_program(payload: ProgramCreate = Body(...)):
    session = SessionLocal()
    try:
        program = Program(name=payload.name, term=payload.term)
        session.add(program)
        try:
            session.commit()
        except IntegrityError:
            session.rollback()
            raise HTTPException(status_code=409, detail="A program with this name and term already exists.")
        session.refresh(program)
        return ProgramOut.model_validate(program, from_attributes=True)
    finally:
        session.close()


@router.get("/{id}", response_model=ProgramOut, summary="Get a program by ID", description="Retrieve a single program by its unique identifier.", operation_id="get_program")
async def get_program(id: int):
    session = SessionLocal()
    try:
        program = session.query(Program).filter(Program.id == id).first()
        if program is None:
            raise HTTPException(status_code=404, detail="Program not found.")
        return ProgramOut.model_validate(program, from_attributes=True)
    finally:
        session.close()


@router.put("/{id}", response_model=ProgramOut, summary="Update a program by ID", description="Replace all fields of an existing program identified by its ID.", operation_id="update_program")
async def update_program(id: int, payload: ProgramUpdate = Body(...)):
    session = SessionLocal()
    try:
        program = session.query(Program).filter(Program.id == id).first()
        if program is None:
            raise HTTPException(status_code=404, detail="Program not found.")
        program.name = payload.name
        program.term = payload.term
        try:
            session.commit()
        except IntegrityError:
            session.rollback()
            raise HTTPException(status_code=409, detail="A program with this name and term already exists.")
        session.refresh(program)
        return ProgramOut.model_validate(program, from_attributes=True)
    finally:
        session.close()


@router.delete("/{id}", response_model=MessageOut, summary="Delete a program by ID", description="Delete a program identified by its ID. Fails if applicants are associated.", operation_id="delete_program")
async def delete_program(id: int):
    session = SessionLocal()
    try:
        program = session.query(Program).filter(Program.id == id).first()
        if program is None:
            raise HTTPException(status_code=404, detail="Program not found.")
        applicant_count = session.query(Applicant).filter(Applicant.program_id == id).count()
        if applicant_count > 0:
            raise HTTPException(status_code=409, detail="Cannot delete program with associated applicants.")
        session.delete(program)
        session.commit()
        return MessageOut(message="Program deleted successfully.")
    finally:
        session.close()


@router.get("/{id}/applicants", response_model=ApplicantListOut, summary="List applicants for a program", description="Retrieve a list of applicants associated with a specific program.", operation_id="list_program_applicants")
async def list_program_applicants(id: int):
    session = SessionLocal()
    try:
        program = session.query(Program).filter(Program.id == id).first()
        if program is None:
            raise HTTPException(status_code=404, detail="Program not found.")
        applicants = session.query(Applicant).filter(Applicant.program_id == id).all()
        return ApplicantListOut(applicants=[ApplicantOut.model_validate(a, from_attributes=True) for a in applicants])
    finally:
        session.close()