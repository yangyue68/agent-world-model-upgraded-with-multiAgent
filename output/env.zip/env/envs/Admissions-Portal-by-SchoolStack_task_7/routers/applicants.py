from datetime import datetime
from fastapi import APIRouter, Body, HTTPException, Query
from sqlalchemy.exc import IntegrityError
from database import SessionLocal
from models import Applicant, ApplicantNote
from schemas import ApplicantOut, ApplicantListOut, ApplicantUpdate, ApplicantNoteCreate, ApplicantNoteUpdate, ApplicantNoteOut, ApplicantNoteListOut, DeleteNoteOut

router = APIRouter(prefix="/api/applicants", tags=["Applicants"])

CURRENT_USER_ID = 1


@router.get("", response_model=ApplicantListOut, summary="List applicants with optional filters", description="Retrieve applicants, optionally filtered by program, name, or applicant code.", operation_id="list_applicants")
async def list_applicants(program_id: int = Query(None), full_name: str = Query(None), applicant_code: str = Query(None)):
    session = SessionLocal()
    try:
        query = session.query(Applicant)
        if program_id is not None:
            query = query.filter(Applicant.program_id == program_id)
        if full_name is not None:
            query = query.filter(Applicant.full_name.ilike(f"%{full_name}%"))
        if applicant_code is not None:
            query = query.filter(Applicant.applicant_code == applicant_code)
        applicants = query.all()
        return ApplicantListOut(applicants=[ApplicantOut.model_validate(a, from_attributes=True) for a in applicants])
    finally:
        session.close()


@router.get("/{applicant_id}", response_model=ApplicantOut, summary="Get a single applicant by ID", description="Retrieve detailed information for one applicant.", operation_id="get_applicant")
async def get_applicant(applicant_id: int):
    session = SessionLocal()
    try:
        applicant = session.query(Applicant).filter(Applicant.id == applicant_id).first()
        if applicant is None:
            raise HTTPException(status_code=404, detail="Applicant not found.")
        return ApplicantOut.model_validate(applicant, from_attributes=True)
    finally:
        session.close()


@router.patch("/{applicant_id}", response_model=ApplicantOut, summary="Update applicant contact and address fields", description="Partially update an applicant's phone, mailing address, city, state, or postal code.", operation_id="update_applicant")
async def update_applicant(applicant_id: int, payload: ApplicantUpdate = Body(...)):
    session = SessionLocal()
    try:
        applicant = session.query(Applicant).filter(Applicant.id == applicant_id).first()
        if applicant is None:
            raise HTTPException(status_code=404, detail="Applicant not found.")
        data = payload.model_dump(exclude_unset=True)
        for field, value in data.items():
            setattr(applicant, field, value)
        applicant.updated_at = datetime.utcnow()
        try:
            session.commit()
        except IntegrityError:
            session.rollback()
            raise HTTPException(status_code=409, detail="Unable to update applicant due to a data conflict.")
        session.refresh(applicant)
        return ApplicantOut.model_validate(applicant, from_attributes=True)
    finally:
        session.close()


@router.post("/{applicant_id}/notes", response_model=ApplicantNoteOut, summary="Add an internal note to an applicant", description="Create a note for the applicant, automatically attributed to the current user (user_id=1).", operation_id="create_applicant_note")
async def create_applicant_note(applicant_id: int, payload: ApplicantNoteCreate = Body(...)):
    session = SessionLocal()
    try:
        applicant = session.query(Applicant).filter(Applicant.id == applicant_id).first()
        if applicant is None:
            raise HTTPException(status_code=404, detail="Applicant not found.")
        note = ApplicantNote(applicant_id=applicant_id, user_id=CURRENT_USER_ID, note=payload.note)
        session.add(note)
        try:
            session.commit()
        except IntegrityError:
            session.rollback()
            raise HTTPException(status_code=409, detail="Unable to create note due to a data conflict.")
        session.refresh(note)
        return ApplicantNoteOut.model_validate(note, from_attributes=True)
    finally:
        session.close()


@router.get("/{applicant_id}/notes", response_model=ApplicantNoteListOut, summary="List internal notes for an applicant", description="Retrieve all notes associated with the applicant, ordered by creation date.", operation_id="list_applicant_notes")
async def list_applicant_notes(applicant_id: int, limit: int = Query(50), offset: int = Query(0)):
    session = SessionLocal()
    try:
        applicant = session.query(Applicant).filter(Applicant.id == applicant_id).first()
        if applicant is None:
            raise HTTPException(status_code=404, detail="Applicant not found.")
        base_query = session.query(ApplicantNote).filter(ApplicantNote.applicant_id == applicant_id)
        total = base_query.count()
        notes = base_query.order_by(ApplicantNote.created_at.desc()).offset(offset).limit(limit).all()
        return ApplicantNoteListOut(notes=[ApplicantNoteOut.model_validate(n, from_attributes=True) for n in notes], total=total)
    finally:
        session.close()


@router.get("/{applicant_id}/notes/{note_id}", response_model=ApplicantNoteOut, summary="Get a single applicant note", description="Retrieve a specific note by its ID for the given applicant.", operation_id="get_applicant_note")
async def get_applicant_note(applicant_id: int, note_id: int):
    session = SessionLocal()
    try:
        note = session.query(ApplicantNote).filter(ApplicantNote.id == note_id, ApplicantNote.applicant_id == applicant_id).first()
        if note is None:
            raise HTTPException(status_code=404, detail="Note not found.")
        return ApplicantNoteOut.model_validate(note, from_attributes=True)
    finally:
        session.close()


@router.put("/{applicant_id}/notes/{note_id}", response_model=ApplicantNoteOut, summary="Replace an applicant note", description="Update the content of an existing note for the given applicant.", operation_id="replace_applicant_note")
async def replace_applicant_note(applicant_id: int, note_id: int, payload: ApplicantNoteUpdate = Body(...)):
    session = SessionLocal()
    try:
        note = session.query(ApplicantNote).filter(ApplicantNote.id == note_id, ApplicantNote.applicant_id == applicant_id).first()
        if note is None:
            raise HTTPException(status_code=404, detail="Note not found.")
        note.note = payload.note
        note.updated_at = datetime.utcnow()
        try:
            session.commit()
        except IntegrityError:
            session.rollback()
            raise HTTPException(status_code=409, detail="Unable to update note due to a data conflict.")
        session.refresh(note)
        return ApplicantNoteOut.model_validate(note, from_attributes=True)
    finally:
        session.close()


@router.delete("/{applicant_id}/notes/{note_id}", response_model=DeleteNoteOut, summary="Delete an applicant note", description="Remove a specific note from the given applicant.", operation_id="delete_applicant_note")
async def delete_applicant_note(applicant_id: int, note_id: int):
    session = SessionLocal()
    try:
        note = session.query(ApplicantNote).filter(ApplicantNote.id == note_id, ApplicantNote.applicant_id == applicant_id).first()
        if note is None:
            raise HTTPException(status_code=404, detail="Note not found.")
        session.delete(note)
        session.commit()
        return DeleteNoteOut(deleted=True)
    finally:
        session.close()