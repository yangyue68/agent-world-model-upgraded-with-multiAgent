from sqlalchemy import Column, Integer, Text, DateTime, ForeignKey, func
from sqlalchemy.orm import relationship
from database import Base


class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True)
    full_name = Column(Text, nullable=False)
    email = Column(Text, unique=True, nullable=False)
    created_at = Column(DateTime, default=func.current_timestamp())
    updated_at = Column(DateTime, default=func.current_timestamp())

    notes = relationship("ApplicantNote", back_populates="user", foreign_keys="ApplicantNote.user_id")


class Program(Base):
    __tablename__ = "programs"

    id = Column(Integer, primary_key=True)
    name = Column(Text, nullable=False)
    term = Column(Text, nullable=False)
    created_at = Column(DateTime, default=func.current_timestamp())
    updated_at = Column(DateTime, default=func.current_timestamp())

    applicants = relationship("Applicant", back_populates="program")


class Applicant(Base):
    __tablename__ = "applicants"

    id = Column(Integer, primary_key=True)
    applicant_code = Column(Text, unique=True, nullable=False)
    full_name = Column(Text, nullable=False)
    phone = Column(Text)
    mailing_address = Column(Text)
    city = Column(Text)
    state = Column(Text)
    postal_code = Column(Text)
    program_id = Column(Integer, ForeignKey("programs.id", ondelete="RESTRICT", onupdate="CASCADE"), nullable=False)
    created_at = Column(DateTime, default=func.current_timestamp())
    updated_at = Column(DateTime, default=func.current_timestamp())

    program = relationship("Program", back_populates="applicants")
    notes = relationship("ApplicantNote", back_populates="applicant", cascade="all, delete-orphan")


class ApplicantNote(Base):
    __tablename__ = "applicant_notes"

    id = Column(Integer, primary_key=True)
    applicant_id = Column(Integer, ForeignKey("applicants.id", ondelete="CASCADE", onupdate="CASCADE"), nullable=False)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="RESTRICT", onupdate="CASCADE"), nullable=False)
    note = Column(Text, nullable=False)
    created_at = Column(DateTime, default=func.current_timestamp())
    updated_at = Column(DateTime, default=func.current_timestamp())

    applicant = relationship("Applicant", back_populates="notes")
    user = relationship("User", back_populates="notes", foreign_keys=[user_id])