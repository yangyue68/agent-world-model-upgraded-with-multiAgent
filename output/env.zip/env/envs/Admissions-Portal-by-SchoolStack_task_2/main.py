import os
import uvicorn
from fastapi import FastAPI
from database import Base, engine
from routers import intakes, applicants, interviews

Base.metadata.create_all(bind=engine)

app = FastAPI(title="Admissions Portal by SchoolStack", version="1.0.0")

app.include_router(intakes.router)
app.include_router(applicants.router)
app.include_router(interviews.router)


@app.get("/", summary="Root health check", description="Returns a simple health check message for the service.", tags=["Health"], operation_id="root_health")
async def root():
    return {"status": "ok", "service": "Admissions Portal by SchoolStack"}


if __name__ == "__main__":
    host = os.getenv("HOST", "127.0.0.1")
    port = int(os.getenv("PORT", "8000"))
    uvicorn.run(app, host=host, port=port)