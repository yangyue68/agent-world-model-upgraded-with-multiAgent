from datetime import datetime
from sqlalchemy import Column, Integer, String, Float, DateTime, ForeignKey, Index, UniqueConstraint, CheckConstraint
from sqlalchemy.orm import relationship
from database import Base


class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, autoincrement=True)
    username = Column(String, unique=True, nullable=False)
    full_name = Column(String, nullable=True)
    email = Column(String, unique=True, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow)

    applicants = relationship("Applicant", back_populates="user", cascade="all, delete-orphan")

    __table_args__ = (
        Index("idx_users_username", "username"),
        Index("idx_users_email", "email"),
    )


class Intake(Base):
    __tablename__ = "intakes"

    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String, nullable=False)
    term = Column(String, nullable=False)
    year = Column(Integer, nullable=False)
    program = Column(String, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow)

    applicants = relationship("Applicant", back_populates="intake", cascade="all, delete-orphan")

    __table_args__ = (
        UniqueConstraint("term", "year", "program", name="uq_intakes_term_year_program"),
        Index("idx_intakes_term_year_program", "term", "year", "program"),
    )


class Applicant(Base):
    __tablename__ = "applicants"

    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    intake_id = Column(Integer, ForeignKey("intakes.id", ondelete="CASCADE"), nullable=False)
    gpa = Column(Float, nullable=False)
    decision_flag = Column(String, nullable=False)
    submission_date = Column(DateTime, nullable=False, default=datetime.utcnow)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow)

    user = relationship("User", back_populates="applicants")
    intake = relationship("Intake", back_populates="applicants")
    interviews = relationship("Interview", back_populates="applicant", cascade="all, delete-orphan")

    __table_args__ = (
        CheckConstraint("gpa >= 0.0 AND gpa <= 4.0", name="ck_applicants_gpa"),
        CheckConstraint("decision_flag IN ('Pending', 'Accepted', 'Rejected', 'Waitlist')", name="ck_applicants_decision_flag"),
        Index("idx_applicants_intake_gpa", "intake_id", "gpa"),
        Index("idx_applicants_intake_decision", "intake_id", "decision_flag"),
        Index("idx_applicants_submission_date", "submission_date"),
        Index("idx_applicants_user_id", "user_id"),
    )


class Interview(Base):
    __tablename__ = "interviews"

    id = Column(Integer, primary_key=True, autoincrement=True)
    applicant_id = Column(Integer, ForeignKey("applicants.id", ondelete="CASCADE"), nullable=False)
    scheduled_at = Column(DateTime, nullable=False)
    status = Column(String, nullable=False, default="Scheduled")
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow)

    applicant = relationship("Applicant", back_populates="interviews")

    __table_args__ = (
        CheckConstraint("status IN ('Scheduled', 'Completed', 'Cancelled', 'No Show')", name="ck_interviews_status"),
        Index("idx_interviews_applicant_id", "applicant_id"),
        Index("idx_interviews_scheduled_at", "scheduled_at"),
        Index("idx_interviews_status", "status"),
    )