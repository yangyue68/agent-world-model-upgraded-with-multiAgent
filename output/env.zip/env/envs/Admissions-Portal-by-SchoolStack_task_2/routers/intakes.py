from datetime import datetime
from typing import Optional
from fastapi import APIRouter, HTTPException, Query
from sqlalchemy import asc, desc
from sqlalchemy.exc import IntegrityError
from database import SessionLocal
from models import Intake, Applicant, Interview
from schemas import (
    IntakeOut,
    IntakeListOut,
    IntakeCreateRequest,
    IntakeUpdateRequest,
    IntakeDeleteOut,
    IntakeApplicantListOut,
    ApplicantDetailOut,
    InterviewOut,
)

router = APIRouter(prefix="/api/intakes", tags=["Intakes"])


@router.get("", summary="List all intakes", description="Retrieve all intakes with optional filters by term, year, and program.", tags=["Intakes"], operation_id="list_intakes", response_model=IntakeListOut)
async def list_intakes(
    term: Optional[str] = Query(None),
    year: Optional[int] = Query(None),
    program: Optional[str] = Query(None),
):
    session = SessionLocal()
    try:
        query = session.query(Intake)
        if term is not None:
            query = query.filter(Intake.term == term)
        if year is not None:
            query = query.filter(Intake.year == year)
        if program is not None:
            query = query.filter(Intake.program == program)
        intakes = query.order_by(Intake.id.asc()).all()
        return IntakeListOut(intakes=[IntakeOut.model_validate(i, from_attributes=True) for i in intakes])
    finally:
        session.close()


@router.get("/{intake_id}", summary="Get a single intake by ID", description="Retrieve details of a specific intake using its unique ID.", tags=["Intakes"], operation_id="get_intake", response_model=IntakeOut)
async def get_intake(intake_id: int):
    session = SessionLocal()
    try:
        intake = session.query(Intake).filter(Intake.id == intake_id).first()
        if intake is None:
            raise HTTPException(status_code=404, detail="Intake not found")
        return IntakeOut.model_validate(intake, from_attributes=True)
    finally:
        session.close()


@router.post("", summary="Create a new intake", description="Create a new intake record with term, year, and program.", tags=["Intakes"], operation_id="create_intake", response_model=IntakeOut)
async def create_intake(payload: IntakeCreateRequest):
    session = SessionLocal()
    try:
        intake = Intake(
            name=payload.name,
            term=payload.term,
            year=payload.year,
            program=payload.program,
        )
        session.add(intake)
        try:
            session.commit()
        except IntegrityError:
            session.rollback()
            raise HTTPException(status_code=409, detail="Intake with this term, year, and program already exists")
        session.refresh(intake)
        return IntakeOut.model_validate(intake, from_attributes=True)
    finally:
        session.close()


@router.put("/{intake_id}", summary="Update an existing intake", description="Replace all fields of an intake by its ID.", tags=["Intakes"], operation_id="update_intake", response_model=IntakeOut)
async def update_intake(intake_id: int, payload: IntakeUpdateRequest):
    session = SessionLocal()
    try:
        intake = session.query(Intake).filter(Intake.id == intake_id).first()
        if intake is None:
            raise HTTPException(status_code=404, detail="Intake not found")
        intake.name = payload.name
        intake.term = payload.term
        intake.year = payload.year
        intake.program = payload.program
        intake.updated_at = datetime.utcnow()
        try:
            session.commit()
        except IntegrityError:
            session.rollback()
            raise HTTPException(status_code=409, detail="Intake with this term, year, and program already exists")
        session.refresh(intake)
        return IntakeOut.model_validate(intake, from_attributes=True)
    finally:
        session.close()


@router.delete("/{intake_id}", summary="Delete an intake by ID", description="Delete an intake and cascade delete related applicants and interviews.", tags=["Intakes"], operation_id="delete_intake", response_model=IntakeDeleteOut)
async def delete_intake(intake_id: int):
    session = SessionLocal()
    try:
        intake = session.query(Intake).filter(Intake.id == intake_id).first()
        if intake is None:
            raise HTTPException(status_code=404, detail="Intake not found")
        session.delete(intake)
        session.commit()
        return IntakeDeleteOut(message="Intake deleted successfully.")
    finally:
        session.close()


@router.get("/{intake_id}/applicants", summary="List applicants for an intake with filters", description="Retrieve applicants for a specific intake, filterable by GPA, interview status, decision flag, and sortable.", tags=["Intakes"], operation_id="list_intake_applicants", response_model=IntakeApplicantListOut)
async def list_intake_applicants(
    intake_id: int,
    gpa_min: Optional[float] = Query(None),
    gpa_max: Optional[float] = Query(None),
    interview_status: Optional[str] = Query(None),
    decision_flag: Optional[str] = Query(None),
    sort_by: Optional[str] = Query("submission_date"),
    sort_order: Optional[str] = Query("desc"),
):
    session = SessionLocal()
    try:
        intake = session.query(Intake).filter(Intake.id == intake_id).first()
        if intake is None:
            raise HTTPException(status_code=404, detail="Intake not found")

        query = session.query(Applicant).filter(Applicant.intake_id == intake_id)

        if gpa_min is not None:
            query = query.filter(Applicant.gpa >= gpa_min)
        if gpa_max is not None:
            query = query.filter(Applicant.gpa <= gpa_max)
        if decision_flag is not None:
            query = query.filter(Applicant.decision_flag == decision_flag)
        if interview_status is not None:
            query = query.join(Interview, Interview.applicant_id == Applicant.id).filter(Interview.status == interview_status)

        sort_field = sort_by if sort_by is not None else "submission_date"
        order_dir = (sort_order or "desc").lower()

        if sort_field == "gpa":
            sort_column = Applicant.gpa
        else:
            sort_column = Applicant.submission_date

        if order_dir == "asc":
            query = query.order_by(asc(sort_column))
        else:
            query = query.order_by(desc(sort_column))

        applicants = query.all()

        results = []
        for applicant in applicants:
            interview = (
                session.query(Interview)
                .filter(Interview.applicant_id == applicant.id)
                .order_by(Interview.scheduled_at.desc())
                .first()
            )
            detail = ApplicantDetailOut.model_validate(applicant, from_attributes=True)
            if interview is not None:
                detail.interview = InterviewOut.model_validate(interview, from_attributes=True)
            results.append(detail)

        return IntakeApplicantListOut(applicants=results)
    finally:
        session.close()