from datetime import datetime
from typing import Optional
from fastapi import APIRouter, HTTPException, Query
from sqlalchemy import asc, desc
from sqlalchemy.exc import IntegrityError
from database import SessionLocal
from models import Applicant, Interview, Intake
from schemas import (
    ApplicantOut,
    ApplicantListOut,
    ApplicantCreateRequest,
    ApplicantUpdateRequest,
    ApplicantPatchRequest,
    ApplicantDeleteOut,
    InterviewOut,
    InterviewListOut,
    InterviewCreateRequest,
)

router = APIRouter(prefix="/api/applicants", tags=["Applicants"])

CURRENT_USER_ID = 1


@router.get("", summary="List applicants with filters, sorting, and pagination", description="Retrieve applicants for the current user, optionally filtered by intake, gpa, decision_flag, interview status, and sorted.", tags=["Applicants"], operation_id="list_applicants", response_model=ApplicantListOut)
async def list_applicants(
    intake_id: Optional[int] = Query(None),
    gpa_min: Optional[float] = Query(None),
    gpa_max: Optional[float] = Query(None),
    decision_flag: Optional[str] = Query(None),
    interview_status: Optional[str] = Query(None),
    has_interview: Optional[bool] = Query(None),
    sort_by: Optional[str] = Query("submission_date"),
    sort_order: Optional[str] = Query("desc"),
    limit: Optional[int] = Query(None),
    offset: Optional[int] = Query(0),
):
    session = SessionLocal()
    try:
        query = session.query(Applicant).filter(Applicant.user_id == CURRENT_USER_ID)

        if intake_id is not None:
            query = query.filter(Applicant.intake_id == intake_id)
        if gpa_min is not None:
            query = query.filter(Applicant.gpa >= gpa_min)
        if gpa_max is not None:
            query = query.filter(Applicant.gpa <= gpa_max)
        if decision_flag is not None:
            query = query.filter(Applicant.decision_flag == decision_flag)
        if interview_status is not None:
            query = query.join(Interview, Interview.applicant_id == Applicant.id).filter(Interview.status == interview_status)
        if has_interview is True:
            query = query.filter(Applicant.interviews.any())
        elif has_interview is False:
            query = query.filter(~Applicant.interviews.any())

        sort_field = sort_by if sort_by is not None else "submission_date"
        order_dir = (sort_order or "desc").lower()

        if sort_field == "gpa":
            sort_column = Applicant.gpa
        elif sort_field == "decision_flag":
            sort_column = Applicant.decision_flag
        else:
            sort_column = Applicant.submission_date

        if order_dir == "asc":
            query = query.order_by(asc(sort_column))
        else:
            query = query.order_by(desc(sort_column))

        total = query.count()

        if offset is not None and offset > 0:
            query = query.offset(offset)
        if limit is not None and limit > 0:
            query = query.limit(limit)

        applicants = query.all()
        return ApplicantListOut(
            applicants=[ApplicantOut.model_validate(a, from_attributes=True) for a in applicants],
            total=total,
        )
    finally:
        session.close()


@router.get("/{id}", summary="Get a single applicant by ID", description="Retrieve detailed information for a specific applicant belonging to the current user.", tags=["Applicants"], operation_id="get_applicant", response_model=ApplicantOut)
async def get_applicant(id: int):
    session = SessionLocal()
    try:
        applicant = (
            session.query(Applicant)
            .filter(Applicant.id == id, Applicant.user_id == CURRENT_USER_ID)
            .first()
        )
        if applicant is None:
            raise HTTPException(status_code=404, detail="Applicant not found")
        return ApplicantOut.model_validate(applicant, from_attributes=True)
    finally:
        session.close()


@router.post("", summary="Create a new applicant", description="Create a new applicant record for the current user.", tags=["Applicants"], operation_id="create_applicant", response_model=ApplicantOut)
async def create_applicant(payload: ApplicantCreateRequest):
    session = SessionLocal()
    try:
        intake = session.query(Intake).filter(Intake.id == payload.intake_id).first()
        if intake is None:
            raise HTTPException(status_code=404, detail="Intake not found")
        if payload.gpa < 0.0 or payload.gpa > 4.0:
            raise HTTPException(status_code=422, detail="gpa must be between 0.0 and 4.0")
        if payload.decision_flag not in ("Pending", "Accepted", "Rejected", "Waitlist"):
            raise HTTPException(status_code=422, detail="Invalid decision_flag")

        applicant = Applicant(
            user_id=CURRENT_USER_ID,
            intake_id=payload.intake_id,
            gpa=payload.gpa,
            decision_flag=payload.decision_flag,
            submission_date=payload.submission_date if payload.submission_date is not None else datetime.utcnow(),
        )
        session.add(applicant)
        try:
            session.commit()
        except IntegrityError:
            session.rollback()
            raise HTTPException(status_code=409, detail="Could not create applicant due to constraint violation")
        session.refresh(applicant)
        return ApplicantOut.model_validate(applicant, from_attributes=True)
    finally:
        session.close()


@router.put("/{id}", summary="Replace an applicant record", description="Update all fields of an existing applicant belonging to the current user.", tags=["Applicants"], operation_id="replace_applicant", response_model=ApplicantOut)
async def replace_applicant(id: int, payload: ApplicantUpdateRequest):
    session = SessionLocal()
    try:
        applicant = (
            session.query(Applicant)
            .filter(Applicant.id == id, Applicant.user_id == CURRENT_USER_ID)
            .first()
        )
        if applicant is None:
            raise HTTPException(status_code=404, detail="Applicant not found")
        intake = session.query(Intake).filter(Intake.id == payload.intake_id).first()
        if intake is None:
            raise HTTPException(status_code=404, detail="Intake not found")
        if payload.gpa < 0.0 or payload.gpa > 4.0:
            raise HTTPException(status_code=422, detail="gpa must be between 0.0 and 4.0")
        if payload.decision_flag not in ("Pending", "Accepted", "Rejected", "Waitlist"):
            raise HTTPException(status_code=422, detail="Invalid decision_flag")

        applicant.intake_id = payload.intake_id
        applicant.gpa = payload.gpa
        applicant.decision_flag = payload.decision_flag
        if payload.submission_date is not None:
            applicant.submission_date = payload.submission_date
        applicant.updated_at = datetime.utcnow()
        try:
            session.commit()
        except IntegrityError:
            session.rollback()
            raise HTTPException(status_code=409, detail="Could not update applicant due to constraint violation")
        session.refresh(applicant)
        return ApplicantOut.model_validate(applicant, from_attributes=True)
    finally:
        session.close()


@router.patch("/{id}", summary="Partially update an applicant", description="Update one or more fields of an existing applicant belonging to the current user.", tags=["Applicants"], operation_id="update_applicant", response_model=ApplicantOut)
async def update_applicant(id: int, payload: ApplicantPatchRequest):
    session = SessionLocal()
    try:
        applicant = (
            session.query(Applicant)
            .filter(Applicant.id == id, Applicant.user_id == CURRENT_USER_ID)
            .first()
        )
        if applicant is None:
            raise HTTPException(status_code=404, detail="Applicant not found")

        if payload.intake_id is not None:
            intake = session.query(Intake).filter(Intake.id == payload.intake_id).first()
            if intake is None:
                raise HTTPException(status_code=404, detail="Intake not found")
            applicant.intake_id = payload.intake_id
        if payload.gpa is not None:
            if payload.gpa < 0.0 or payload.gpa > 4.0:
                raise HTTPException(status_code=422, detail="gpa must be between 0.0 and 4.0")
            applicant.gpa = payload.gpa
        if payload.decision_flag is not None:
            if payload.decision_flag not in ("Pending", "Accepted", "Rejected", "Waitlist"):
                raise HTTPException(status_code=422, detail="Invalid decision_flag")
            applicant.decision_flag = payload.decision_flag
        if payload.submission_date is not None:
            applicant.submission_date = payload.submission_date

        applicant.updated_at = datetime.utcnow()
        try:
            session.commit()
        except IntegrityError:
            session.rollback()
            raise HTTPException(status_code=409, detail="Could not update applicant due to constraint violation")
        session.refresh(applicant)
        return ApplicantOut.model_validate(applicant, from_attributes=True)
    finally:
        session.close()


@router.delete("/{id}", summary="Delete an applicant", description="Delete an applicant record belonging to the current user.", tags=["Applicants"], operation_id="delete_applicant", response_model=ApplicantDeleteOut)
async def delete_applicant(id: int):
    session = SessionLocal()
    try:
        applicant = (
            session.query(Applicant)
            .filter(Applicant.id == id, Applicant.user_id == CURRENT_USER_ID)
            .first()
        )
        if applicant is None:
            raise HTTPException(status_code=404, detail="Applicant not found")
        session.delete(applicant)
        session.commit()
        return ApplicantDeleteOut(success=True)
    finally:
        session.close()


@router.get("/{id}/interviews", summary="List interviews for an applicant", description="Retrieve all interviews associated with a specific applicant belonging to the current user.", tags=["Applicants"], operation_id="list_applicant_interviews_by_applicant", response_model=InterviewListOut)
async def list_applicant_interviews(id: int):
    session = SessionLocal()
    try:
        applicant = (
            session.query(Applicant)
            .filter(Applicant.id == id, Applicant.user_id == CURRENT_USER_ID)
            .first()
        )
        if applicant is None:
            raise HTTPException(status_code=404, detail="Applicant not found")
        interviews = (
            session.query(Interview)
            .filter(Interview.applicant_id == id)
            .order_by(Interview.scheduled_at.asc())
            .all()
        )
        return InterviewListOut(
            interviews=[InterviewOut.model_validate(i, from_attributes=True) for i in interviews],
            total=len(interviews),
        )
    finally:
        session.close()


@router.post("/{id}/interviews", summary="Schedule an interview for an applicant", description="Create a new interview record for a specific applicant belonging to the current user.", tags=["Applicants"], operation_id="create_applicant_interview_by_applicant", response_model=InterviewOut)
async def create_applicant_interview(id: int, payload: InterviewCreateRequest):
    session = SessionLocal()
    try:
        applicant = (
            session.query(Applicant)
            .filter(Applicant.id == id, Applicant.user_id == CURRENT_USER_ID)
            .first()
        )
        if applicant is None:
            raise HTTPException(status_code=404, detail="Applicant not found")
        status_value = payload.status if payload.status is not None else "Scheduled"
        if status_value not in ("Scheduled", "Completed", "Cancelled", "No Show"):
            raise HTTPException(status_code=422, detail="Invalid interview status")
        interview = Interview(
            applicant_id=id,
            scheduled_at=payload.scheduled_at,
            status=status_value,
        )
        session.add(interview)
        try:
            session.commit()
        except IntegrityError:
            session.rollback()
            raise HTTPException(status_code=409, detail="Could not create interview due to constraint violation")
        session.refresh(interview)
        return InterviewOut.model_validate(interview, from_attributes=True)
    finally:
        session.close()