from datetime import datetime
from typing import Optional
from fastapi import APIRouter, HTTPException, Query
from sqlalchemy.exc import IntegrityError
from database import SessionLocal
from models import Interview, Applicant
from schemas import (
    InterviewOut,
    InterviewListOut,
    InterviewCreateRequest,
    InterviewUpdateRequest,
    InterviewPatchRequest,
    InterviewDeleteOut,
)

router = APIRouter(prefix="/api/interviews", tags=["Interviews"])

CURRENT_USER_ID = 1


def _parse_datetime(value: Optional[str]) -> Optional[datetime]:
    if value is None:
        return None
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00")).replace(tzinfo=None)
    except ValueError:
        raise HTTPException(status_code=422, detail="Invalid datetime format")


@router.get("", summary="List interviews with optional filters", description="Retrieve interviews, optionally filtered by applicant, status, and scheduled date range.", tags=["Interviews"], operation_id="list_interviews", response_model=InterviewListOut)
async def list_interviews(
    applicant_id: Optional[int] = Query(None),
    status: Optional[str] = Query(None),
    scheduled_from: Optional[str] = Query(None),
    scheduled_to: Optional[str] = Query(None),
    limit: Optional[int] = Query(None),
    offset: Optional[int] = Query(0),
):
    session = SessionLocal()
    try:
        query = (
            session.query(Interview)
            .join(Applicant, Applicant.id == Interview.applicant_id)
            .filter(Applicant.user_id == CURRENT_USER_ID)
        )
        if applicant_id is not None:
            query = query.filter(Interview.applicant_id == applicant_id)
        if status is not None:
            query = query.filter(Interview.status == status)
        from_dt = _parse_datetime(scheduled_from)
        to_dt = _parse_datetime(scheduled_to)
        if from_dt is not None:
            query = query.filter(Interview.scheduled_at >= from_dt)
        if to_dt is not None:
            query = query.filter(Interview.scheduled_at <= to_dt)

        query = query.order_by(Interview.scheduled_at.asc())
        total = query.count()

        if offset is not None and offset > 0:
            query = query.offset(offset)
        if limit is not None and limit > 0:
            query = query.limit(limit)

        interviews = query.all()
        return InterviewListOut(
            interviews=[InterviewOut.model_validate(i, from_attributes=True) for i in interviews],
            total=total,
        )
    finally:
        session.close()


@router.get("/{id}", summary="Get an interview by id", description="Retrieve a single interview record by its id.", tags=["Interviews"], operation_id="get_interview", response_model=InterviewOut)
async def get_interview(id: int):
    session = SessionLocal()
    try:
        interview = (
            session.query(Interview)
            .join(Applicant, Applicant.id == Interview.applicant_id)
            .filter(Interview.id == id, Applicant.user_id == CURRENT_USER_ID)
            .first()
        )
        if interview is None:
            raise HTTPException(status_code=404, detail="Interview not found")
        return InterviewOut.model_validate(interview, from_attributes=True)
    finally:
        session.close()


@router.post("", summary="Schedule a new interview", description="Create an interview for an applicant with a scheduled datetime and status.", tags=["Interviews"], operation_id="create_interview", response_model=InterviewOut)
async def create_interview(payload: InterviewCreateRequest):
    session = SessionLocal()
    try:
        if payload.applicant_id is None:
            raise HTTPException(status_code=422, detail="applicant_id is required")
        applicant = (
            session.query(Applicant)
            .filter(Applicant.id == payload.applicant_id, Applicant.user_id == CURRENT_USER_ID)
            .first()
        )
        if applicant is None:
            raise HTTPException(status_code=404, detail="Applicant not found")
        status_value = payload.status if payload.status is not None else "Scheduled"
        if status_value not in ("Scheduled", "Completed", "Cancelled", "No Show"):
            raise HTTPException(status_code=422, detail="Invalid interview status")
        interview = Interview(
            applicant_id=payload.applicant_id,
            scheduled_at=payload.scheduled_at,
            status=status_value,
        )
        session.add(interview)
        try:
            session.commit()
        except IntegrityError:
            session.rollback()
            raise HTTPException(status_code=409, detail="Could not create interview due to constraint violation")
        session.refresh(interview)
        return InterviewOut.model_validate(interview, from_attributes=True)
    finally:
        session.close()


@router.put("/{id}", summary="Replace an interview record", description="Fully update an interview's scheduled datetime and status.", tags=["Interviews"], operation_id="replace_interview", response_model=InterviewOut)
async def replace_interview(id: int, payload: InterviewUpdateRequest):
    session = SessionLocal()
    try:
        interview = (
            session.query(Interview)
            .join(Applicant, Applicant.id == Interview.applicant_id)
            .filter(Interview.id == id, Applicant.user_id == CURRENT_USER_ID)
            .first()
        )
        if interview is None:
            raise HTTPException(status_code=404, detail="Interview not found")
        applicant = (
            session.query(Applicant)
            .filter(Applicant.id == payload.applicant_id, Applicant.user_id == CURRENT_USER_ID)
            .first()
        )
        if applicant is None:
            raise HTTPException(status_code=404, detail="Applicant not found")
        if payload.status not in ("Scheduled", "Completed", "Cancelled", "No Show"):
            raise HTTPException(status_code=422, detail="Invalid interview status")
        interview.applicant_id = payload.applicant_id
        interview.scheduled_at = payload.scheduled_at
        interview.status = payload.status
        interview.updated_at = datetime.utcnow()
        try:
            session.commit()
        except IntegrityError:
            session.rollback()
            raise HTTPException(status_code=409, detail="Could not update interview due to constraint violation")
        session.refresh(interview)
        return InterviewOut.model_validate(interview, from_attributes=True)
    finally:
        session.close()


@router.patch("/{id}", summary="Partially update an interview", description="Update one or more fields of an interview, such as status or scheduled datetime.", tags=["Interviews"], operation_id="update_interview", response_model=InterviewOut)
async def update_interview(id: int, payload: InterviewPatchRequest):
    session = SessionLocal()
    try:
        interview = (
            session.query(Interview)
            .join(Applicant, Applicant.id == Interview.applicant_id)
            .filter(Interview.id == id, Applicant.user_id == CURRENT_USER_ID)
            .first()
        )
        if interview is None:
            raise HTTPException(status_code=404, detail="Interview not found")
        if payload.scheduled_at is not None:
            interview.scheduled_at = payload.scheduled_at
        if payload.status is not None:
            if payload.status not in ("Scheduled", "Completed", "Cancelled", "No Show"):
                raise HTTPException(status_code=422, detail="Invalid interview status")
            interview.status = payload.status
        interview.updated_at = datetime.utcnow()
        try:
            session.commit()
        except IntegrityError:
            session.rollback()
            raise HTTPException(status_code=409, detail="Could not update interview due to constraint violation")
        session.refresh(interview)
        return InterviewOut.model_validate(interview, from_attributes=True)
    finally:
        session.close()


@router.delete("/{id}", summary="Delete an interview", description="Remove an interview record by its id.", tags=["Interviews"], operation_id="delete_interview", response_model=InterviewDeleteOut)
async def delete_interview(id: int):
    session = SessionLocal()
    try:
        interview = (
            session.query(Interview)
            .join(Applicant, Applicant.id == Interview.applicant_id)
            .filter(Interview.id == id, Applicant.user_id == CURRENT_USER_ID)
            .first()
        )
        if interview is None:
            raise HTTPException(status_code=404, detail="Interview not found")
        session.delete(interview)
        session.commit()
        return InterviewDeleteOut(deleted=True, id=id)
    finally:
        session.close()


@router.get("/applicants/{applicant_id}/interviews", summary="List interviews for an applicant", description="Retrieve all interviews belonging to a specific applicant.", tags=["Interviews"], operation_id="list_applicant_interviews", response_model=InterviewListOut)
async def list_applicant_interviews(
    applicant_id: int,
    status: Optional[str] = Query(None),
):
    session = SessionLocal()
    try:
        applicant = (
            session.query(Applicant)
            .filter(Applicant.id == applicant_id, Applicant.user_id == CURRENT_USER_ID)
            .first()
        )
        if applicant is None:
            raise HTTPException(status_code=404, detail="Applicant not found")
        query = session.query(Interview).filter(Interview.applicant_id == applicant_id)
        if status is not None:
            query = query.filter(Interview.status == status)
        interviews = query.order_by(Interview.scheduled_at.asc()).all()
        return InterviewListOut(
            interviews=[InterviewOut.model_validate(i, from_attributes=True) for i in interviews],
            total=len(interviews),
        )
    finally:
        session.close()


@router.post("/applicants/{applicant_id}/interviews", summary="Schedule an interview for an applicant", description="Create an interview under a specific applicant with scheduled datetime and status.", tags=["Interviews"], operation_id="create_applicant_interview", response_model=InterviewOut)
async def create_applicant_interview(applicant_id: int, payload: InterviewCreateRequest):
    session = SessionLocal()
    try:
        applicant = (
            session.query(Applicant)
            .filter(Applicant.id == applicant_id, Applicant.user_id == CURRENT_USER_ID)
            .first()
        )
        if applicant is None:
            raise HTTPException(status_code=404, detail="Applicant not found")
        status_value = payload.status if payload.status is not None else "Scheduled"
        if status_value not in ("Scheduled", "Completed", "Cancelled", "No Show"):
            raise HTTPException(status_code=422, detail="Invalid interview status")
        interview = Interview(
            applicant_id=applicant_id,
            scheduled_at=payload.scheduled_at,
            status=status_value,
        )
        session.add(interview)
        try:
            session.commit()
        except IntegrityError:
            session.rollback()
            raise HTTPException(status_code=409, detail="Could not create interview due to constraint violation")
        session.refresh(interview)
        return InterviewOut.model_validate(interview, from_attributes=True)
    finally:
        session.close()