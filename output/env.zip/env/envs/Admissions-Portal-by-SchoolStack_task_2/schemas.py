from datetime import datetime
from typing import Optional, List
from pydantic import BaseModel, ConfigDict, Field

class UserOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    username: str
    full_name: Optional[str] = None
    email: Optional[str] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class IntakeOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    name: str
    term: str
    year: int
    program: str
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class IntakeListOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    intakes: List[IntakeOut]

class IntakeCreateRequest(BaseModel):
    name: str
    term: str
    year: int
    program: str

class IntakeUpdateRequest(BaseModel):
    name: str
    term: str
    year: int
    program: str

class IntakeDeleteOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    message: str

class InterviewOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    applicant_id: int
    scheduled_at: datetime
    status: str
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class InterviewListOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    interviews: List[InterviewOut]
    total: int

class InterviewCreateRequest(BaseModel):
    applicant_id: Optional[int] = None
    scheduled_at: datetime
    status: Optional[str] = 'Scheduled'

class InterviewUpdateRequest(BaseModel):
    applicant_id: int
    scheduled_at: datetime
    status: str

class InterviewPatchRequest(BaseModel):
    scheduled_at: Optional[datetime] = None
    status: Optional[str] = None

class InterviewDeleteOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    deleted: bool
    id: int

class ApplicantOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    user_id: int
    intake_id: int
    gpa: float
    decision_flag: str
    submission_date: datetime
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class ApplicantDetailOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    user_id: int
    intake_id: int
    gpa: float
    decision_flag: str
    submission_date: datetime
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    user: Optional[UserOut] = None
    interview: Optional[InterviewOut] = None

class ApplicantListOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    applicants: List[ApplicantOut]
    total: int

class IntakeApplicantListOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    applicants: List[ApplicantDetailOut]

class ApplicantCreateRequest(BaseModel):
    intake_id: int
    gpa: float
    decision_flag: str
    submission_date: Optional[datetime] = None

class ApplicantUpdateRequest(BaseModel):
    intake_id: int
    gpa: float
    decision_flag: str
    submission_date: Optional[datetime] = None

class ApplicantPatchRequest(BaseModel):
    intake_id: Optional[int] = None
    gpa: Optional[float] = None
    decision_flag: Optional[str] = None
    submission_date: Optional[datetime] = None

class ApplicantDeleteOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    success: bool