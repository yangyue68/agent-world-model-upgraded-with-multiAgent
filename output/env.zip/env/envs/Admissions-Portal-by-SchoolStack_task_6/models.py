from sqlalchemy import Column, Integer, String, Text, DateTime, ForeignKey, CheckConstraint, UniqueConstraint
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func

from database import Base


class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, autoincrement=True)
    username = Column(String, unique=True, nullable=False)
    email = Column(String, unique=True, nullable=False)
    full_name = Column(String)
    created_at = Column(DateTime, default=func.current_timestamp())
    updated_at = Column(DateTime, default=func.current_timestamp())


class Program(Base):
    __tablename__ = "programs"

    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String, nullable=False)
    code = Column(String, unique=True, nullable=False)
    description = Column(Text)
    created_at = Column(DateTime, default=func.current_timestamp())
    updated_at = Column(DateTime, default=func.current_timestamp())


class Application(Base):
    __tablename__ = "applications"

    id = Column(Integer, primary_key=True, autoincrement=True)
    program_id = Column(Integer, ForeignKey("programs.id", ondelete="CASCADE"), nullable=False)
    applicant_user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    status = Column(String, nullable=False, default="Draft")
    submitted_at = Column(DateTime)
    created_at = Column(DateTime, default=func.current_timestamp())
    updated_at = Column(DateTime, default=func.current_timestamp())

    __table_args__ = (
        CheckConstraint("status IN ('Draft','Submitted','Under Review','Waitlist Review','Accepted','Rejected','Withdrawn')", name="ck_application_status"),
    )


class RecommendationRequirement(Base):
    __tablename__ = "recommendation_requirements"

    id = Column(Integer, primary_key=True, autoincrement=True)
    program_id = Column(Integer, ForeignKey("programs.id", ondelete="CASCADE"), nullable=False)
    requirement_type = Column(String, nullable=False)
    required_count = Column(Integer, nullable=False, default=1)
    created_at = Column(DateTime, default=func.current_timestamp())
    updated_at = Column(DateTime, default=func.current_timestamp())

    __table_args__ = (
        CheckConstraint("requirement_type IN ('Science Faculty','Clinical Supervisor','Other')", name="ck_rec_req_type"),
        CheckConstraint("required_count > 0", name="ck_rec_req_count"),
        UniqueConstraint("program_id", "requirement_type", name="uq_rec_req_program_type"),
    )


class RecommendationRequest(Base):
    __tablename__ = "recommendation_requests"

    id = Column(Integer, primary_key=True, autoincrement=True)
    application_id = Column(Integer, ForeignKey("applications.id", ondelete="CASCADE"), nullable=False)
    requirement_id = Column(Integer, ForeignKey("recommendation_requirements.id", ondelete="CASCADE"), nullable=False)
    recommender_name = Column(String, nullable=False)
    recommender_email = Column(String, nullable=False)
    recommender_type = Column(String, nullable=False)
    status = Column(String, nullable=False, default="Pending")
    requested_at = Column(DateTime, default=func.current_timestamp())
    submitted_at = Column(DateTime)
    created_at = Column(DateTime, default=func.current_timestamp())
    updated_at = Column(DateTime, default=func.current_timestamp())

    __table_args__ = (
        CheckConstraint("recommender_type IN ('Science Faculty','Clinical Supervisor','Other')", name="ck_rec_req_recommender_type"),
        CheckConstraint("status IN ('Pending','Submitted','Incomplete','Expired')", name="ck_rec_req_status"),
    )


class DeadlineRule(Base):
    __tablename__ = "deadline_rules"

    id = Column(Integer, primary_key=True, autoincrement=True)
    program_id = Column(Integer, ForeignKey("programs.id", ondelete="CASCADE"), nullable=False)
    rule_name = Column(String, nullable=False)
    deadline_type = Column(String, nullable=False)
    deadline_date = Column(DateTime, nullable=False)
    action_on_missing = Column(String, nullable=False)
    created_at = Column(DateTime, default=func.current_timestamp())
    updated_at = Column(DateTime, default=func.current_timestamp())

    __table_args__ = (
        CheckConstraint("deadline_type IN ('Recommendation Submission','Final Application','Other')", name="ck_deadline_type"),
        CheckConstraint("action_on_missing IN ('Waitlist Review','Reject','Notify')", name="ck_deadline_action"),
    )


class ReminderSchedule(Base):
    __tablename__ = "reminder_schedules"

    id = Column(Integer, primary_key=True, autoincrement=True)
    program_id = Column(Integer, ForeignKey("programs.id", ondelete="CASCADE"), nullable=False)
    reminder_type = Column(String, nullable=False)
    interval_days = Column(Integer, nullable=False)
    start_date = Column(DateTime, nullable=False)
    end_date = Column(DateTime)
    is_active = Column(Integer, nullable=False, default=1)
    created_at = Column(DateTime, default=func.current_timestamp())
    updated_at = Column(DateTime, default=func.current_timestamp())

    __table_args__ = (
        CheckConstraint("reminder_type IN ('Recommendation Incomplete','Application Incomplete','Other')", name="ck_reminder_type"),
        CheckConstraint("interval_days > 0", name="ck_reminder_interval"),
        CheckConstraint("is_active IN (0,1)", name="ck_reminder_active"),
    )


class ReminderLog(Base):
    __tablename__ = "reminder_logs"

    id = Column(Integer, primary_key=True, autoincrement=True)
    reminder_schedule_id = Column(Integer, ForeignKey("reminder_schedules.id", ondelete="CASCADE"), nullable=False)
    application_id = Column(Integer, ForeignKey("applications.id", ondelete="CASCADE"), nullable=False)
    sent_at = Column(DateTime, default=func.current_timestamp())
    status = Column(String, nullable=False, default="Sent")
    created_at = Column(DateTime, default=func.current_timestamp())

    __table_args__ = (
        CheckConstraint("status IN ('Sent','Failed','Skipped')", name="ck_reminder_log_status"),
    )