import os
import uvicorn
from fastapi import FastAPI

from database import Base, engine
import models
from routers import programs, applications, recommendation_requirements, recommendation_requests, deadline_rules, reminder_schedules, reminder_logs, workflow

Base.metadata.create_all(engine)

app = FastAPI(title="Admissions Portal by SchoolStack", version="1.0.0")

app.include_router(programs.router)
app.include_router(applications.router)
app.include_router(recommendation_requirements.router)
app.include_router(recommendation_requests.router)
app.include_router(deadline_rules.router)
app.include_router(reminder_schedules.router)
app.include_router(reminder_logs.router)
app.include_router(workflow.router)


@app.get("/", summary="Root", description="Health check root endpoint", tags=["Root"], operation_id="root")
async def root():
    return {"message": "Admissions Portal by SchoolStack API"}


if __name__ == "__main__":
    host = os.getenv("HOST", "127.0.0.1")
    port = int(os.getenv("PORT", "8000"))
    uvicorn.run(app, host=host, port=port)