from datetime import datetime
from typing import Optional, List
from pydantic import BaseModel, ConfigDict, Field

class ProgramBase(BaseModel):
    name: str
    code: str
    description: Optional[str] = None

class ProgramCreate(ProgramBase):
    pass

class ProgramUpdate(BaseModel):
    name: Optional[str] = None
    code: Optional[str] = None
    description: Optional[str] = None

class ProgramOut(ProgramBase):
    model_config = ConfigDict(from_attributes=True)
    id: int
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class ProgramListOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    programs: List[ProgramOut]

class RecommendationRequirementBase(BaseModel):
    requirement_type: str
    required_count: int

class RecommendationRequirementCreate(RecommendationRequirementBase):
    pass

class RecommendationRequirementUpdate(BaseModel):
    requirement_type: Optional[str] = None
    required_count: Optional[int] = None

class RecommendationRequirementOut(RecommendationRequirementBase):
    model_config = ConfigDict(from_attributes=True)
    id: int
    program_id: int
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class RecommendationRequirementListOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    recommendation_requirements: List[RecommendationRequirementOut]

class RecommendationRequestBase(BaseModel):
    application_id: int
    requirement_id: int
    recommender_name: str
    recommender_email: str
    recommender_type: str
    status: Optional[str] = 'Pending'
    submitted_at: Optional[datetime] = None

class RecommendationRequestCreate(BaseModel):
    application_id: int
    requirement_id: int
    recommender_name: str
    recommender_email: str
    recommender_type: str
    status: Optional[str] = 'Pending'

class RecommendationRequestUpdate(BaseModel):
    application_id: Optional[int] = None
    requirement_id: Optional[int] = None
    recommender_name: Optional[str] = None
    recommender_email: Optional[str] = None
    recommender_type: Optional[str] = None
    status: Optional[str] = None
    submitted_at: Optional[datetime] = None

class RecommendationRequestOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    application_id: int
    requirement_id: int
    recommender_name: str
    recommender_email: str
    recommender_type: str
    status: str
    requested_at: Optional[datetime] = None
    submitted_at: Optional[datetime] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class RecommendationRequestListOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    recommendation_requests: List[RecommendationRequestOut]

class DeadlineRuleBase(BaseModel):
    rule_name: str
    deadline_type: str
    deadline_date: datetime
    action_on_missing: str

class DeadlineRuleCreate(DeadlineRuleBase):
    pass

class DeadlineRuleUpdate(BaseModel):
    rule_name: Optional[str] = None
    deadline_type: Optional[str] = None
    deadline_date: Optional[datetime] = None
    action_on_missing: Optional[str] = None

class DeadlineRuleOut(DeadlineRuleBase):
    model_config = ConfigDict(from_attributes=True)
    id: int
    program_id: int
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class DeadlineRuleListOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    deadline_rules: List[DeadlineRuleOut]

class ReminderScheduleBase(BaseModel):
    reminder_type: str
    interval_days: int
    start_date: datetime
    end_date: Optional[datetime] = None
    is_active: Optional[int] = 1

class ReminderScheduleCreate(ReminderScheduleBase):
    pass

class ReminderScheduleUpdate(BaseModel):
    reminder_type: Optional[str] = None
    interval_days: Optional[int] = None
    start_date: Optional[datetime] = None
    end_date: Optional[datetime] = None
    is_active: Optional[int] = None

class ReminderScheduleOut(ReminderScheduleBase):
    model_config = ConfigDict(from_attributes=True)
    id: int
    program_id: int
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class ReminderScheduleListOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    reminder_schedules: List[ReminderScheduleOut]

class ReminderLogBase(BaseModel):
    reminder_schedule_id: int
    application_id: int
    sent_at: Optional[datetime] = None
    status: Optional[str] = 'Sent'

class ReminderLogCreate(BaseModel):
    reminder_schedule_id: Optional[int] = None
    application_id: int
    sent_at: Optional[datetime] = None
    status: Optional[str] = 'Sent'

class ReminderLogUpdate(BaseModel):
    status: Optional[str] = None
    sent_at: Optional[datetime] = None

class ReminderLogOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    reminder_schedule_id: int
    application_id: int
    sent_at: Optional[datetime] = None
    status: str
    created_at: Optional[datetime] = None

class ReminderLogListOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    reminder_logs: List[ReminderLogOut]
    total: Optional[int] = None

class ApplicationBase(BaseModel):
    program_id: int
    status: Optional[str] = 'Draft'

class ApplicationCreate(BaseModel):
    program_id: int
    status: Optional[str] = 'Draft'

class ApplicationUpdate(BaseModel):
    status: Optional[str] = None
    submitted_at: Optional[datetime] = None

class ApplicationOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    program_id: int
    applicant_user_id: int
    status: str
    submitted_at: Optional[datetime] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class ApplicationListOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    applications: List[ApplicationOut]

class MessageOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    message: str

class DeletedOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    deleted: bool
    id: Optional[int] = None

class WorkflowApplyResult(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    rule_id: int
    rule_name: str
    action_on_missing: str
    affected_application_ids: List[int]
    affected_count: int

class WorkflowReminderResult(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    schedule_id: int
    reminder_type: str
    generated_log_ids: List[int]
    generated_count: int