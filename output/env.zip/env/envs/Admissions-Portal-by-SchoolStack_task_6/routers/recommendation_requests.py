from datetime import datetime
from fastapi import APIRouter, Body, HTTPException, Query
from sqlalchemy.exc import IntegrityError

from database import SessionLocal
from models import RecommendationRequest
from schemas import (
    RecommendationRequestCreate, RecommendationRequestUpdate, RecommendationRequestOut, RecommendationRequestListOut,
    DeletedOut,
)

router = APIRouter(prefix="/api", tags=["RecommendationRequests"])


@router.get("/recommendation-requests", response_model=RecommendationRequestListOut, summary="List recommendation requests", description="Retrieve recommendation requests, optionally filtered by application, requirement, or status.", operation_id="list_recommendation_requests_filtered")
async def list_recommendation_requests_filtered(
    application_id: int = Query(None),
    requirement_id: int = Query(None),
    status: str = Query(None),
    recommender_type: str = Query(None),
):
    session = SessionLocal()
    query = session.query(RecommendationRequest)
    if application_id is not None:
        query = query.filter(RecommendationRequest.application_id == application_id)
    if requirement_id is not None:
        query = query.filter(RecommendationRequest.requirement_id == requirement_id)
    if status is not None:
        query = query.filter(RecommendationRequest.status == status)
    if recommender_type is not None:
        query = query.filter(RecommendationRequest.recommender_type == recommender_type)
    reqs = query.all()
    result = RecommendationRequestListOut(recommendation_requests=[RecommendationRequestOut.model_validate(r, from_attributes=True) for r in reqs])
    session.close()
    return result


@router.get("/recommendation-requests/{id}", response_model=RecommendationRequestOut, summary="Get a recommendation request by ID", description="Retrieve a single recommendation request by its unique ID.", operation_id="get_recommendation_request_by_id")
async def get_recommendation_request_by_id(id: int):
    session = SessionLocal()
    req = session.query(RecommendationRequest).filter(RecommendationRequest.id == id).first()
    if not req:
        session.close()
        raise HTTPException(status_code=404, detail="Recommendation request not found")
    result = RecommendationRequestOut.model_validate(req, from_attributes=True)
    session.close()
    return result


@router.post("/recommendation-requests", response_model=RecommendationRequestOut, summary="Create a new recommendation request", description="Create a recommendation request for an application and requirement.", operation_id="create_recommendation_request_standalone")
async def create_recommendation_request_standalone(payload: RecommendationRequestCreate = Body(...)):
    session = SessionLocal()
    req = RecommendationRequest(
        application_id=payload.application_id,
        requirement_id=payload.requirement_id,
        recommender_name=payload.recommender_name,
        recommender_email=payload.recommender_email,
        recommender_type=payload.recommender_type,
        status=payload.status if payload.status else "Pending",
        requested_at=datetime.utcnow(),
    )
    session.add(req)
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Invalid recommendation request data")
    session.refresh(req)
    result = RecommendationRequestOut.model_validate(req, from_attributes=True)
    session.close()
    return result


@router.put("/recommendation-requests/{id}", response_model=RecommendationRequestOut, summary="Update a recommendation request", description="Replace all fields of a recommendation request by ID.", operation_id="replace_recommendation_request")
async def replace_recommendation_request(id: int, payload: RecommendationRequestUpdate = Body(...)):
    session = SessionLocal()
    req = session.query(RecommendationRequest).filter(RecommendationRequest.id == id).first()
    if not req:
        session.close()
        raise HTTPException(status_code=404, detail="Recommendation request not found")
    if payload.application_id is not None:
        req.application_id = payload.application_id
    if payload.requirement_id is not None:
        req.requirement_id = payload.requirement_id
    if payload.recommender_name is not None:
        req.recommender_name = payload.recommender_name
    if payload.recommender_email is not None:
        req.recommender_email = payload.recommender_email
    if payload.recommender_type is not None:
        req.recommender_type = payload.recommender_type
    if payload.status is not None:
        req.status = payload.status
    if payload.submitted_at is not None:
        req.submitted_at = payload.submitted_at
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Invalid recommendation request update")
    session.refresh(req)
    result = RecommendationRequestOut.model_validate(req, from_attributes=True)
    session.close()
    return result


@router.patch("/recommendation-requests/{id}", response_model=RecommendationRequestOut, summary="Partially update a recommendation request", description="Update one or more fields of a recommendation request by ID.", operation_id="patch_recommendation_request")
async def patch_recommendation_request(id: int, payload: RecommendationRequestUpdate = Body(...)):
    session = SessionLocal()
    req = session.query(RecommendationRequest).filter(RecommendationRequest.id == id).first()
    if not req:
        session.close()
        raise HTTPException(status_code=404, detail="Recommendation request not found")
    if payload.status is not None:
        req.status = payload.status
    if payload.submitted_at is not None:
        req.submitted_at = payload.submitted_at
    if payload.recommender_name is not None:
        req.recommender_name = payload.recommender_name
    if payload.recommender_email is not None:
        req.recommender_email = payload.recommender_email
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Invalid recommendation request update")
    session.refresh(req)
    result = RecommendationRequestOut.model_validate(req, from_attributes=True)
    session.close()
    return result


@router.delete("/recommendation-requests/{id}", response_model=DeletedOut, summary="Delete a recommendation request", description="Delete a recommendation request by ID.", operation_id="delete_recommendation_request_by_id")
async def delete_recommendation_request_by_id(id: int):
    session = SessionLocal()
    req = session.query(RecommendationRequest).filter(RecommendationRequest.id == id).first()
    if not req:
        session.close()
        raise HTTPException(status_code=404, detail="Recommendation request not found")
    session.delete(req)
    session.commit()
    session.close()
    return DeletedOut(deleted=True, id=id)