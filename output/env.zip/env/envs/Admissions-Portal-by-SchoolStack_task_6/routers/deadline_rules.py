from fastapi import APIRouter, Body, HTTPException
from sqlalchemy.exc import IntegrityError

from database import SessionLocal
from models import Program, DeadlineRule
from schemas import (
    DeadlineRuleCreate, DeadlineRuleUpdate, DeadlineRuleOut, DeadlineRuleListOut,
    DeletedOut,
)

router = APIRouter(prefix="/api", tags=["DeadlineRules"])


@router.get("/programs/{program_id}/deadline-rules", response_model=DeadlineRuleListOut, summary="List deadline rules for a program", description="Retrieve all deadline rules configured for the given program.", operation_id="list_deadline_rules_by_program")
async def list_deadline_rules_by_program(program_id: int):
    session = SessionLocal()
    program = session.query(Program).filter(Program.id == program_id).first()
    if not program:
        session.close()
        raise HTTPException(status_code=404, detail="Program not found")
    rules = session.query(DeadlineRule).filter(DeadlineRule.program_id == program_id).all()
    result = DeadlineRuleListOut(deadline_rules=[DeadlineRuleOut.model_validate(r, from_attributes=True) for r in rules])
    session.close()
    return result


@router.post("/programs/{program_id}/deadline-rules", response_model=DeadlineRuleOut, summary="Create a deadline rule for a program", description="Add a new deadline rule specifying type, date, and action on missing items.", operation_id="create_deadline_rule_for_program")
async def create_deadline_rule_for_program(program_id: int, payload: DeadlineRuleCreate = Body(...)):
    session = SessionLocal()
    program = session.query(Program).filter(Program.id == program_id).first()
    if not program:
        session.close()
        raise HTTPException(status_code=404, detail="Program not found")
    rule = DeadlineRule(program_id=program_id, rule_name=payload.rule_name, deadline_type=payload.deadline_type, deadline_date=payload.deadline_date, action_on_missing=payload.action_on_missing)
    session.add(rule)
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Invalid deadline rule")
    session.refresh(rule)
    result = DeadlineRuleOut.model_validate(rule, from_attributes=True)
    session.close()
    return result


@router.get("/deadline-rules/{id}", response_model=DeadlineRuleOut, summary="Get a deadline rule by ID", description="Retrieve details of a single deadline rule.", operation_id="get_deadline_rule")
async def get_deadline_rule(id: int):
    session = SessionLocal()
    rule = session.query(DeadlineRule).filter(DeadlineRule.id == id).first()
    if not rule:
        session.close()
        raise HTTPException(status_code=404, detail="Deadline rule not found")
    result = DeadlineRuleOut.model_validate(rule, from_attributes=True)
    session.close()
    return result


@router.put("/deadline-rules/{id}", response_model=DeadlineRuleOut, summary="Update a deadline rule", description="Replace all fields of an existing deadline rule.", operation_id="replace_deadline_rule")
async def replace_deadline_rule(id: int, payload: DeadlineRuleUpdate = Body(...)):
    session = SessionLocal()
    rule = session.query(DeadlineRule).filter(DeadlineRule.id == id).first()
    if not rule:
        session.close()
        raise HTTPException(status_code=404, detail="Deadline rule not found")
    if payload.rule_name is not None:
        rule.rule_name = payload.rule_name
    if payload.deadline_type is not None:
        rule.deadline_type = payload.deadline_type
    if payload.deadline_date is not None:
        rule.deadline_date = payload.deadline_date
    if payload.action_on_missing is not None:
        rule.action_on_missing = payload.action_on_missing
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Invalid deadline rule update")
    session.refresh(rule)
    result = DeadlineRuleOut.model_validate(rule, from_attributes=True)
    session.close()
    return result


@router.patch("/deadline-rules/{id}", response_model=DeadlineRuleOut, summary="Partially update a deadline rule", description="Update one or more fields of an existing deadline rule.", operation_id="patch_deadline_rule")
async def patch_deadline_rule(id: int, payload: DeadlineRuleUpdate = Body(...)):
    session = SessionLocal()
    rule = session.query(DeadlineRule).filter(DeadlineRule.id == id).first()
    if not rule:
        session.close()
        raise HTTPException(status_code=404, detail="Deadline rule not found")
    if payload.rule_name is not None:
        rule.rule_name = payload.rule_name
    if payload.deadline_type is not None:
        rule.deadline_type = payload.deadline_type
    if payload.deadline_date is not None:
        rule.deadline_date = payload.deadline_date
    if payload.action_on_missing is not None:
        rule.action_on_missing = payload.action_on_missing
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Invalid deadline rule update")
    session.refresh(rule)
    result = DeadlineRuleOut.model_validate(rule, from_attributes=True)
    session.close()
    return result


@router.delete("/deadline-rules/{id}", response_model=DeletedOut, summary="Delete a deadline rule", description="Remove a deadline rule by its ID.", operation_id="delete_deadline_rule_by_id")
async def delete_deadline_rule_by_id(id: int):
    session = SessionLocal()
    rule = session.query(DeadlineRule).filter(DeadlineRule.id == id).first()
    if not rule:
        session.close()
        raise HTTPException(status_code=404, detail="Deadline rule not found")
    session.delete(rule)
    session.commit()
    session.close()
    return DeletedOut(deleted=True, id=id)