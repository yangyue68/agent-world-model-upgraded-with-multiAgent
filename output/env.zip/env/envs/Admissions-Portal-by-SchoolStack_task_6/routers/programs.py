from fastapi import APIRouter, Body, HTTPException
from sqlalchemy.exc import IntegrityError

from database import SessionLocal
from models import Program, RecommendationRequirement, DeadlineRule, ReminderSchedule
from schemas import (
    ProgramCreate, ProgramUpdate, ProgramOut, ProgramListOut,
    RecommendationRequirementCreate, RecommendationRequirementUpdate, RecommendationRequirementOut, RecommendationRequirementListOut,
    DeadlineRuleCreate, DeadlineRuleUpdate, DeadlineRuleOut, DeadlineRuleListOut,
    ReminderScheduleCreate, ReminderScheduleUpdate, ReminderScheduleOut, ReminderScheduleListOut,
    MessageOut,
)

router = APIRouter(prefix="/api", tags=["Programs"])


@router.get("/programs", response_model=ProgramListOut, summary="List all programs", description="Retrieve a list of all programs in the admissions portal.", operation_id="list_programs")
async def list_programs():
    session = SessionLocal()
    programs = session.query(Program).all()
    result = ProgramListOut(programs=[ProgramOut.model_validate(p, from_attributes=True) for p in programs])
    session.close()
    return result


@router.post("/programs", response_model=ProgramOut, summary="Create a new program", description="Create a new program with name, code, and optional description.", operation_id="create_program")
async def create_program(payload: ProgramCreate = Body(...)):
    session = SessionLocal()
    program = Program(name=payload.name, code=payload.code, description=payload.description)
    session.add(program)
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Program code must be unique")
    session.refresh(program)
    result = ProgramOut.model_validate(program, from_attributes=True)
    session.close()
    return result


@router.get("/programs/{program_id}", response_model=ProgramOut, summary="Get a program by ID", description="Retrieve details of a specific program by its ID.", operation_id="get_program")
async def get_program(program_id: int):
    session = SessionLocal()
    program = session.query(Program).filter(Program.id == program_id).first()
    if not program:
        session.close()
        raise HTTPException(status_code=404, detail="Program not found")
    result = ProgramOut.model_validate(program, from_attributes=True)
    session.close()
    return result


@router.put("/programs/{program_id}", response_model=ProgramOut, summary="Update a program", description="Update an existing program's name, code, or description.", operation_id="update_program")
async def update_program(program_id: int, payload: ProgramUpdate = Body(...)):
    session = SessionLocal()
    program = session.query(Program).filter(Program.id == program_id).first()
    if not program:
        session.close()
        raise HTTPException(status_code=404, detail="Program not found")
    if payload.name is not None:
        program.name = payload.name
    if payload.code is not None:
        program.code = payload.code
    if payload.description is not None:
        program.description = payload.description
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Program code must be unique")
    session.refresh(program)
    result = ProgramOut.model_validate(program, from_attributes=True)
    session.close()
    return result


@router.delete("/programs/{program_id}", response_model=MessageOut, summary="Delete a program", description="Delete a program and all associated data by its ID.", operation_id="delete_program")
async def delete_program(program_id: int):
    session = SessionLocal()
    program = session.query(Program).filter(Program.id == program_id).first()
    if not program:
        session.close()
        raise HTTPException(status_code=404, detail="Program not found")
    session.delete(program)
    session.commit()
    session.close()
    return MessageOut(message="Program deleted successfully")


@router.get("/programs/{program_id}/recommendation-requirements", response_model=RecommendationRequirementListOut, summary="List recommendation requirements for a program", description="Retrieve all recommendation requirements for a specific program.", operation_id="list_recommendation_requirements")
async def list_recommendation_requirements(program_id: int):
    session = SessionLocal()
    program = session.query(Program).filter(Program.id == program_id).first()
    if not program:
        session.close()
        raise HTTPException(status_code=404, detail="Program not found")
    reqs = session.query(RecommendationRequirement).filter(RecommendationRequirement.program_id == program_id).all()
    result = RecommendationRequirementListOut(recommendation_requirements=[RecommendationRequirementOut.model_validate(r, from_attributes=True) for r in reqs])
    session.close()
    return result


@router.post("/programs/{program_id}/recommendation-requirements", response_model=RecommendationRequirementOut, summary="Create a recommendation requirement", description="Add a new recommendation requirement to a program.", operation_id="create_recommendation_requirement")
async def create_recommendation_requirement(program_id: int, payload: RecommendationRequirementCreate = Body(...)):
    session = SessionLocal()
    program = session.query(Program).filter(Program.id == program_id).first()
    if not program:
        session.close()
        raise HTTPException(status_code=404, detail="Program not found")
    req = RecommendationRequirement(program_id=program_id, requirement_type=payload.requirement_type, required_count=payload.required_count)
    session.add(req)
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Recommendation requirement already exists for this program and type")
    session.refresh(req)
    result = RecommendationRequirementOut.model_validate(req, from_attributes=True)
    session.close()
    return result


@router.put("/programs/{program_id}/recommendation-requirements/{requirement_id}", response_model=RecommendationRequirementOut, summary="Update a recommendation requirement", description="Update an existing recommendation requirement for a program.", operation_id="update_recommendation_requirement")
async def update_recommendation_requirement(program_id: int, requirement_id: int, payload: RecommendationRequirementUpdate = Body(...)):
    session = SessionLocal()
    req = session.query(RecommendationRequirement).filter(RecommendationRequirement.id == requirement_id, RecommendationRequirement.program_id == program_id).first()
    if not req:
        session.close()
        raise HTTPException(status_code=404, detail="Recommendation requirement not found")
    if payload.requirement_type is not None:
        req.requirement_type = payload.requirement_type
    if payload.required_count is not None:
        req.required_count = payload.required_count
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Invalid recommendation requirement update")
    session.refresh(req)
    result = RecommendationRequirementOut.model_validate(req, from_attributes=True)
    session.close()
    return result


@router.delete("/programs/{program_id}/recommendation-requirements/{requirement_id}", response_model=MessageOut, summary="Delete a recommendation requirement", description="Remove a recommendation requirement from a program.", operation_id="delete_recommendation_requirement")
async def delete_recommendation_requirement(program_id: int, requirement_id: int):
    session = SessionLocal()
    req = session.query(RecommendationRequirement).filter(RecommendationRequirement.id == requirement_id, RecommendationRequirement.program_id == program_id).first()
    if not req:
        session.close()
        raise HTTPException(status_code=404, detail="Recommendation requirement not found")
    session.delete(req)
    session.commit()
    session.close()
    return MessageOut(message="Recommendation requirement deleted successfully")


@router.get("/programs/{program_id}/deadline-rules", response_model=DeadlineRuleListOut, summary="List deadline rules for a program", description="Retrieve all deadline rules configured for a specific program.", operation_id="list_deadline_rules")
async def list_deadline_rules(program_id: int):
    session = SessionLocal()
    program = session.query(Program).filter(Program.id == program_id).first()
    if not program:
        session.close()
        raise HTTPException(status_code=404, detail="Program not found")
    rules = session.query(DeadlineRule).filter(DeadlineRule.program_id == program_id).all()
    result = DeadlineRuleListOut(deadline_rules=[DeadlineRuleOut.model_validate(r, from_attributes=True) for r in rules])
    session.close()
    return result


@router.post("/programs/{program_id}/deadline-rules", response_model=DeadlineRuleOut, summary="Create a deadline rule", description="Add a new deadline rule to a program.", operation_id="create_deadline_rule")
async def create_deadline_rule(program_id: int, payload: DeadlineRuleCreate = Body(...)):
    session = SessionLocal()
    program = session.query(Program).filter(Program.id == program_id).first()
    if not program:
        session.close()
        raise HTTPException(status_code=404, detail="Program not found")
    rule = DeadlineRule(program_id=program_id, rule_name=payload.rule_name, deadline_type=payload.deadline_type, deadline_date=payload.deadline_date, action_on_missing=payload.action_on_missing)
    session.add(rule)
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Invalid deadline rule")
    session.refresh(rule)
    result = DeadlineRuleOut.model_validate(rule, from_attributes=True)
    session.close()
    return result


@router.put("/programs/{program_id}/deadline-rules/{rule_id}", response_model=DeadlineRuleOut, summary="Update a deadline rule", description="Update an existing deadline rule for a program.", operation_id="update_deadline_rule")
async def update_deadline_rule(program_id: int, rule_id: int, payload: DeadlineRuleUpdate = Body(...)):
    session = SessionLocal()
    rule = session.query(DeadlineRule).filter(DeadlineRule.id == rule_id, DeadlineRule.program_id == program_id).first()
    if not rule:
        session.close()
        raise HTTPException(status_code=404, detail="Deadline rule not found")
    if payload.rule_name is not None:
        rule.rule_name = payload.rule_name
    if payload.deadline_type is not None:
        rule.deadline_type = payload.deadline_type
    if payload.deadline_date is not None:
        rule.deadline_date = payload.deadline_date
    if payload.action_on_missing is not None:
        rule.action_on_missing = payload.action_on_missing
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Invalid deadline rule update")
    session.refresh(rule)
    result = DeadlineRuleOut.model_validate(rule, from_attributes=True)
    session.close()
    return result


@router.delete("/programs/{program_id}/deadline-rules/{rule_id}", response_model=MessageOut, summary="Delete a deadline rule", description="Remove a deadline rule from a program.", operation_id="delete_deadline_rule")
async def delete_deadline_rule(program_id: int, rule_id: int):
    session = SessionLocal()
    rule = session.query(DeadlineRule).filter(DeadlineRule.id == rule_id, DeadlineRule.program_id == program_id).first()
    if not rule:
        session.close()
        raise HTTPException(status_code=404, detail="Deadline rule not found")
    session.delete(rule)
    session.commit()
    session.close()
    return MessageOut(message="Deadline rule deleted successfully")


@router.get("/programs/{program_id}/reminder-schedules", response_model=ReminderScheduleListOut, summary="List reminder schedules for a program", description="Retrieve all reminder schedules configured for a specific program.", operation_id="list_reminder_schedules")
async def list_reminder_schedules(program_id: int):
    session = SessionLocal()
    program = session.query(Program).filter(Program.id == program_id).first()
    if not program:
        session.close()
        raise HTTPException(status_code=404, detail="Program not found")
    schedules = session.query(ReminderSchedule).filter(ReminderSchedule.program_id == program_id).all()
    result = ReminderScheduleListOut(reminder_schedules=[ReminderScheduleOut.model_validate(s, from_attributes=True) for s in schedules])
    session.close()
    return result


@router.post("/programs/{program_id}/reminder-schedules", response_model=ReminderScheduleOut, summary="Create a reminder schedule", description="Add a new reminder schedule to a program.", operation_id="create_reminder_schedule")
async def create_reminder_schedule(program_id: int, payload: ReminderScheduleCreate = Body(...)):
    session = SessionLocal()
    program = session.query(Program).filter(Program.id == program_id).first()
    if not program:
        session.close()
        raise HTTPException(status_code=404, detail="Program not found")
    schedule = ReminderSchedule(program_id=program_id, reminder_type=payload.reminder_type, interval_days=payload.interval_days, start_date=payload.start_date, end_date=payload.end_date, is_active=payload.is_active if payload.is_active is not None else 1)
    session.add(schedule)
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Invalid reminder schedule")
    session.refresh(schedule)
    result = ReminderScheduleOut.model_validate(schedule, from_attributes=True)
    session.close()
    return result


@router.put("/programs/{program_id}/reminder-schedules/{schedule_id}", response_model=ReminderScheduleOut, summary="Update a reminder schedule", description="Update an existing reminder schedule for a program.", operation_id="update_reminder_schedule")
async def update_reminder_schedule(program_id: int, schedule_id: int, payload: ReminderScheduleUpdate = Body(...)):
    session = SessionLocal()
    schedule = session.query(ReminderSchedule).filter(ReminderSchedule.id == schedule_id, ReminderSchedule.program_id == program_id).first()
    if not schedule:
        session.close()
        raise HTTPException(status_code=404, detail="Reminder schedule not found")
    if payload.reminder_type is not None:
        schedule.reminder_type = payload.reminder_type
    if payload.interval_days is not None:
        schedule.interval_days = payload.interval_days
    if payload.start_date is not None:
        schedule.start_date = payload.start_date
    if payload.end_date is not None:
        schedule.end_date = payload.end_date
    if payload.is_active is not None:
        schedule.is_active = payload.is_active
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Invalid reminder schedule update")
    session.refresh(schedule)
    result = ReminderScheduleOut.model_validate(schedule, from_attributes=True)
    session.close()
    return result


@router.delete("/programs/{program_id}/reminder-schedules/{schedule_id}", response_model=MessageOut, summary="Delete a reminder schedule", description="Remove a reminder schedule from a program.", operation_id="delete_reminder_schedule")
async def delete_reminder_schedule(program_id: int, schedule_id: int):
    session = SessionLocal()
    schedule = session.query(ReminderSchedule).filter(ReminderSchedule.id == schedule_id, ReminderSchedule.program_id == program_id).first()
    if not schedule:
        session.close()
        raise HTTPException(status_code=404, detail="Reminder schedule not found")
    session.delete(schedule)
    session.commit()
    session.close()
    return MessageOut(message="Reminder schedule deleted successfully")