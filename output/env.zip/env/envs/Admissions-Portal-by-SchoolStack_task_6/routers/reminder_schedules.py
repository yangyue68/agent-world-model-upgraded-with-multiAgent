from fastapi import APIRouter, Body, HTTPException, Query
from sqlalchemy.exc import IntegrityError

from database import SessionLocal
from models import Program, ReminderSchedule
from schemas import (
    ReminderScheduleCreate, ReminderScheduleUpdate, ReminderScheduleOut, ReminderScheduleListOut,
    DeletedOut,
)

router = APIRouter(prefix="/api", tags=["ReminderSchedules"])


@router.get("/programs/{program_id}/reminder-schedules", response_model=ReminderScheduleListOut, summary="List reminder schedules for a program", description="Retrieve all reminder schedules configured for the given program.", operation_id="list_reminder_schedules_by_program")
async def list_reminder_schedules_by_program(program_id: int, is_active: int = Query(None), reminder_type: str = Query(None)):
    session = SessionLocal()
    program = session.query(Program).filter(Program.id == program_id).first()
    if not program:
        session.close()
        raise HTTPException(status_code=404, detail="Program not found")
    query = session.query(ReminderSchedule).filter(ReminderSchedule.program_id == program_id)
    if is_active is not None:
        query = query.filter(ReminderSchedule.is_active == is_active)
    if reminder_type is not None:
        query = query.filter(ReminderSchedule.reminder_type == reminder_type)
    schedules = query.all()
    result = ReminderScheduleListOut(reminder_schedules=[ReminderScheduleOut.model_validate(s, from_attributes=True) for s in schedules])
    session.close()
    return result


@router.post("/programs/{program_id}/reminder-schedules", response_model=ReminderScheduleOut, summary="Create a reminder schedule for a program", description="Create a new reminder schedule defining reminder type, interval, and date range.", operation_id="create_reminder_schedule_for_program")
async def create_reminder_schedule_for_program(program_id: int, payload: ReminderScheduleCreate = Body(...)):
    session = SessionLocal()
    program = session.query(Program).filter(Program.id == program_id).first()
    if not program:
        session.close()
        raise HTTPException(status_code=404, detail="Program not found")
    schedule = ReminderSchedule(program_id=program_id, reminder_type=payload.reminder_type, interval_days=payload.interval_days, start_date=payload.start_date, end_date=payload.end_date, is_active=payload.is_active if payload.is_active is not None else 1)
    session.add(schedule)
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Invalid reminder schedule")
    session.refresh(schedule)
    result = ReminderScheduleOut.model_validate(schedule, from_attributes=True)
    session.close()
    return result


@router.get("/reminder-schedules/{id}", response_model=ReminderScheduleOut, summary="Get a reminder schedule by ID", description="Retrieve a single reminder schedule record by its ID.", operation_id="get_reminder_schedule")
async def get_reminder_schedule(id: int):
    session = SessionLocal()
    schedule = session.query(ReminderSchedule).filter(ReminderSchedule.id == id).first()
    if not schedule:
        session.close()
        raise HTTPException(status_code=404, detail="Reminder schedule not found")
    result = ReminderScheduleOut.model_validate(schedule, from_attributes=True)
    session.close()
    return result


@router.put("/reminder-schedules/{id}", response_model=ReminderScheduleOut, summary="Replace a reminder schedule", description="Fully update a reminder schedule record with new values.", operation_id="replace_reminder_schedule")
async def replace_reminder_schedule(id: int, payload: ReminderScheduleUpdate = Body(...)):
    session = SessionLocal()
    schedule = session.query(ReminderSchedule).filter(ReminderSchedule.id == id).first()
    if not schedule:
        session.close()
        raise HTTPException(status_code=404, detail="Reminder schedule not found")
    if payload.reminder_type is not None:
        schedule.reminder_type = payload.reminder_type
    if payload.interval_days is not None:
        schedule.interval_days = payload.interval_days
    if payload.start_date is not None:
        schedule.start_date = payload.start_date
    if payload.end_date is not None:
        schedule.end_date = payload.end_date
    if payload.is_active is not None:
        schedule.is_active = payload.is_active
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Invalid reminder schedule update")
    session.refresh(schedule)
    result = ReminderScheduleOut.model_validate(schedule, from_attributes=True)
    session.close()
    return result


@router.patch("/reminder-schedules/{id}", response_model=ReminderScheduleOut, summary="Partially update a reminder schedule", description="Update selected fields of a reminder schedule record.", operation_id="patch_reminder_schedule")
async def patch_reminder_schedule(id: int, payload: ReminderScheduleUpdate = Body(...)):
    session = SessionLocal()
    schedule = session.query(ReminderSchedule).filter(ReminderSchedule.id == id).first()
    if not schedule:
        session.close()
        raise HTTPException(status_code=404, detail="Reminder schedule not found")
    if payload.reminder_type is not None:
        schedule.reminder_type = payload.reminder_type
    if payload.interval_days is not None:
        schedule.interval_days = payload.interval_days
    if payload.start_date is not None:
        schedule.start_date = payload.start_date
    if payload.end_date is not None:
        schedule.end_date = payload.end_date
    if payload.is_active is not None:
        schedule.is_active = payload.is_active
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Invalid reminder schedule update")
    session.refresh(schedule)
    result = ReminderScheduleOut.model_validate(schedule, from_attributes=True)
    session.close()
    return result


@router.delete("/reminder-schedules/{id}", response_model=DeletedOut, summary="Delete a reminder schedule", description="Delete a reminder schedule record by its ID.", operation_id="delete_reminder_schedule_by_id")
async def delete_reminder_schedule_by_id(id: int):
    session = SessionLocal()
    schedule = session.query(ReminderSchedule).filter(ReminderSchedule.id == id).first()
    if not schedule:
        session.close()
        raise HTTPException(status_code=404, detail="Reminder schedule not found")
    session.delete(schedule)
    session.commit()
    session.close()
    return DeletedOut(deleted=True, id=id)