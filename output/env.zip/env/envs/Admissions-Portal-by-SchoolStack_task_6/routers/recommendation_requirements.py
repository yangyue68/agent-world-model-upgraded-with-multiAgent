from fastapi import APIRouter, Body, HTTPException
from sqlalchemy.exc import IntegrityError

from database import SessionLocal
from models import Program, RecommendationRequirement
from schemas import (
    RecommendationRequirementCreate, RecommendationRequirementUpdate, RecommendationRequirementOut, RecommendationRequirementListOut,
    DeletedOut,
)

router = APIRouter(prefix="/api", tags=["RecommendationRequirements"])


@router.get("/programs/{program_id}/recommendation-requirements", response_model=RecommendationRequirementListOut, summary="List recommendation requirements for a program", description="Retrieve all recommendation requirements configured for the given program.", operation_id="list_recommendation_requirements_by_program")
async def list_recommendation_requirements_by_program(program_id: int):
    session = SessionLocal()
    program = session.query(Program).filter(Program.id == program_id).first()
    if not program:
        session.close()
        raise HTTPException(status_code=404, detail="Program not found")
    reqs = session.query(RecommendationRequirement).filter(RecommendationRequirement.program_id == program_id).all()
    result = RecommendationRequirementListOut(recommendation_requirements=[RecommendationRequirementOut.model_validate(r, from_attributes=True) for r in reqs])
    session.close()
    return result


@router.post("/programs/{program_id}/recommendation-requirements", response_model=RecommendationRequirementOut, summary="Create a recommendation requirement for a program", description="Add a new recommendation requirement specifying type and required count.", operation_id="create_recommendation_requirement_for_program")
async def create_recommendation_requirement_for_program(program_id: int, payload: RecommendationRequirementCreate = Body(...)):
    session = SessionLocal()
    program = session.query(Program).filter(Program.id == program_id).first()
    if not program:
        session.close()
        raise HTTPException(status_code=404, detail="Program not found")
    req = RecommendationRequirement(program_id=program_id, requirement_type=payload.requirement_type, required_count=payload.required_count)
    session.add(req)
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Recommendation requirement already exists for this program and type")
    session.refresh(req)
    result = RecommendationRequirementOut.model_validate(req, from_attributes=True)
    session.close()
    return result


@router.get("/recommendation-requirements/{requirement_id}", response_model=RecommendationRequirementOut, summary="Get a recommendation requirement by ID", description="Retrieve a single recommendation requirement record.", operation_id="get_recommendation_requirement")
async def get_recommendation_requirement(requirement_id: int):
    session = SessionLocal()
    req = session.query(RecommendationRequirement).filter(RecommendationRequirement.id == requirement_id).first()
    if not req:
        session.close()
        raise HTTPException(status_code=404, detail="Recommendation requirement not found")
    result = RecommendationRequirementOut.model_validate(req, from_attributes=True)
    session.close()
    return result


@router.put("/recommendation-requirements/{requirement_id}", response_model=RecommendationRequirementOut, summary="Update a recommendation requirement", description="Replace the details of an existing recommendation requirement.", operation_id="update_recommendation_requirement_by_id")
async def update_recommendation_requirement_by_id(requirement_id: int, payload: RecommendationRequirementUpdate = Body(...)):
    session = SessionLocal()
    req = session.query(RecommendationRequirement).filter(RecommendationRequirement.id == requirement_id).first()
    if not req:
        session.close()
        raise HTTPException(status_code=404, detail="Recommendation requirement not found")
    if payload.requirement_type is not None:
        req.requirement_type = payload.requirement_type
    if payload.required_count is not None:
        req.required_count = payload.required_count
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Invalid recommendation requirement update")
    session.refresh(req)
    result = RecommendationRequirementOut.model_validate(req, from_attributes=True)
    session.close()
    return result


@router.delete("/recommendation-requirements/{requirement_id}", response_model=DeletedOut, summary="Delete a recommendation requirement", description="Remove a recommendation requirement and its associated requests.", operation_id="delete_recommendation_requirement_by_id")
async def delete_recommendation_requirement_by_id(requirement_id: int):
    session = SessionLocal()
    req = session.query(RecommendationRequirement).filter(RecommendationRequirement.id == requirement_id).first()
    if not req:
        session.close()
        raise HTTPException(status_code=404, detail="Recommendation requirement not found")
    session.delete(req)
    session.commit()
    session.close()
    return DeletedOut(deleted=True, id=requirement_id)