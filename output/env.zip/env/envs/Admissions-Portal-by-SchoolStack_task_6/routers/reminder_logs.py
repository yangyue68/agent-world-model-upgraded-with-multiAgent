from datetime import datetime
from fastapi import APIRouter, Body, HTTPException, Query
from sqlalchemy.exc import IntegrityError

from database import SessionLocal
from models import ReminderLog, ReminderSchedule, Application
from schemas import (
    ReminderLogCreate, ReminderLogUpdate, ReminderLogOut, ReminderLogListOut,
    DeletedOut,
)

router = APIRouter(prefix="/api", tags=["ReminderLogs"])


@router.get("/reminder-logs", response_model=ReminderLogListOut, summary="List reminder logs with optional filters", description="Retrieve reminder logs, optionally filtered by schedule, application, or status.", operation_id="list_reminder_logs")
async def list_reminder_logs(
    reminder_schedule_id: int = Query(None),
    application_id: int = Query(None),
    status: str = Query(None),
    limit: int = Query(None),
    offset: int = Query(None),
):
    session = SessionLocal()
    query = session.query(ReminderLog)
    if reminder_schedule_id is not None:
        query = query.filter(ReminderLog.reminder_schedule_id == reminder_schedule_id)
    if application_id is not None:
        query = query.filter(ReminderLog.application_id == application_id)
    if status is not None:
        query = query.filter(ReminderLog.status == status)
    total = query.count()
    if offset is not None:
        query = query.offset(offset)
    if limit is not None:
        query = query.limit(limit)
    logs = query.all()
    result = ReminderLogListOut(reminder_logs=[ReminderLogOut.model_validate(l, from_attributes=True) for l in logs], total=total)
    session.close()
    return result


@router.get("/reminder-logs/{id}", response_model=ReminderLogOut, summary="Get a single reminder log by id", description="Retrieve one reminder log record by its primary key.", operation_id="get_reminder_log")
async def get_reminder_log(id: int):
    session = SessionLocal()
    log = session.query(ReminderLog).filter(ReminderLog.id == id).first()
    if not log:
        session.close()
        raise HTTPException(status_code=404, detail="Reminder log not found")
    result = ReminderLogOut.model_validate(log, from_attributes=True)
    session.close()
    return result


@router.post("/reminder-logs", response_model=ReminderLogOut, summary="Create a reminder log entry", description="Record a reminder delivery attempt for a schedule and application.", operation_id="create_reminder_log")
async def create_reminder_log(payload: ReminderLogCreate = Body(...)):
    session = SessionLocal()
    schedule_id = payload.reminder_schedule_id
    if schedule_id is None:
        session.close()
        raise HTTPException(status_code=400, detail="reminder_schedule_id is required")
    schedule = session.query(ReminderSchedule).filter(ReminderSchedule.id == schedule_id).first()
    if not schedule:
        session.close()
        raise HTTPException(status_code=404, detail="Reminder schedule not found")
    app = session.query(Application).filter(Application.id == payload.application_id).first()
    if not app:
        session.close()
        raise HTTPException(status_code=404, detail="Application not found")
    log = ReminderLog(
        reminder_schedule_id=schedule_id,
        application_id=payload.application_id,
        sent_at=payload.sent_at if payload.sent_at is not None else datetime.utcnow(),
        status=payload.status if payload.status else "Sent",
    )
    session.add(log)
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Invalid reminder log data")
    session.refresh(log)
    result = ReminderLogOut.model_validate(log, from_attributes=True)
    session.close()
    return result


@router.patch("/reminder-logs/{id}", response_model=ReminderLogOut, summary="Update a reminder log status", description="Update the status of an existing reminder log record.", operation_id="update_reminder_log")
async def update_reminder_log(id: int, payload: ReminderLogUpdate = Body(...)):
    session = SessionLocal()
    log = session.query(ReminderLog).filter(ReminderLog.id == id).first()
    if not log:
        session.close()
        raise HTTPException(status_code=404, detail="Reminder log not found")
    if payload.status is not None:
        log.status = payload.status
    if payload.sent_at is not None:
        log.sent_at = payload.sent_at
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Invalid reminder log update")
    session.refresh(log)
    result = ReminderLogOut.model_validate(log, from_attributes=True)
    session.close()
    return result


@router.delete("/reminder-logs/{id}", response_model=DeletedOut, summary="Delete a reminder log", description="Permanently delete a reminder log record by id.", operation_id="delete_reminder_log")
async def delete_reminder_log(id: int):
    session = SessionLocal()
    log = session.query(ReminderLog).filter(ReminderLog.id == id).first()
    if not log:
        session.close()
        raise HTTPException(status_code=404, detail="Reminder log not found")
    session.delete(log)
    session.commit()
    session.close()
    return DeletedOut(deleted=True, id=id)


@router.get("/reminder-schedules/{schedule_id}/reminder-logs", response_model=ReminderLogListOut, summary="List logs for a reminder schedule", description="Retrieve all reminder logs associated with a specific reminder schedule.", operation_id="list_reminder_logs_by_schedule")
async def list_reminder_logs_by_schedule(schedule_id: int, status: str = Query(None)):
    session = SessionLocal()
    schedule = session.query(ReminderSchedule).filter(ReminderSchedule.id == schedule_id).first()
    if not schedule:
        session.close()
        raise HTTPException(status_code=404, detail="Reminder schedule not found")
    query = session.query(ReminderLog).filter(ReminderLog.reminder_schedule_id == schedule_id)
    if status is not None:
        query = query.filter(ReminderLog.status == status)
    logs = query.all()
    result = ReminderLogListOut(reminder_logs=[ReminderLogOut.model_validate(l, from_attributes=True) for l in logs])
    session.close()
    return result


@router.get("/applications/{application_id}/reminder-logs", response_model=ReminderLogListOut, summary="List logs for an application", description="Retrieve all reminder logs associated with a specific application.", operation_id="list_reminder_logs_by_application")
async def list_reminder_logs_by_application(application_id: int, status: str = Query(None)):
    session = SessionLocal()
    app = session.query(Application).filter(Application.id == application_id).first()
    if not app:
        session.close()
        raise HTTPException(status_code=404, detail="Application not found")
    query = session.query(ReminderLog).filter(ReminderLog.application_id == application_id)
    if status is not None:
        query = query.filter(ReminderLog.status == status)
    logs = query.all()
    result = ReminderLogListOut(reminder_logs=[ReminderLogOut.model_validate(l, from_attributes=True) for l in logs])
    session.close()
    return result