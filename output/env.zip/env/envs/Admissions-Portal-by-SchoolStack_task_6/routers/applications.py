from datetime import datetime
from fastapi import APIRouter, Body, HTTPException, Query
from sqlalchemy.exc import IntegrityError

from database import SessionLocal
from models import Application, RecommendationRequest
from schemas import (
    ApplicationCreate, ApplicationUpdate, ApplicationOut, ApplicationListOut,
    RecommendationRequestCreate, RecommendationRequestUpdate, RecommendationRequestOut, RecommendationRequestListOut,
    MessageOut,
)

router = APIRouter(prefix="/api", tags=["Applications"])

CURRENT_USER_ID = 1


@router.get("/applications", response_model=ApplicationListOut, summary="List applications for the current user", description="Retrieve all applications belonging to the current user (user_id=1).", operation_id="list_applications")
async def list_applications(program_id: int = Query(None), status: str = Query(None)):
    session = SessionLocal()
    query = session.query(Application).filter(Application.applicant_user_id == CURRENT_USER_ID)
    if program_id is not None:
        query = query.filter(Application.program_id == program_id)
    if status is not None:
        query = query.filter(Application.status == status)
    apps = query.all()
    result = ApplicationListOut(applications=[ApplicationOut.model_validate(a, from_attributes=True) for a in apps])
    session.close()
    return result


@router.post("/applications", response_model=ApplicationOut, summary="Create a new application", description="Create a new application for the current user (user_id=1).", operation_id="create_application")
async def create_application(payload: ApplicationCreate = Body(...)):
    session = SessionLocal()
    app = Application(program_id=payload.program_id, applicant_user_id=CURRENT_USER_ID, status=payload.status if payload.status else "Draft")
    session.add(app)
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Invalid application data")
    session.refresh(app)
    result = ApplicationOut.model_validate(app, from_attributes=True)
    session.close()
    return result


@router.get("/applications/{application_id}", response_model=ApplicationOut, summary="Get an application by ID", description="Retrieve a specific application belonging to the current user (user_id=1).", operation_id="get_application")
async def get_application(application_id: int):
    session = SessionLocal()
    app = session.query(Application).filter(Application.id == application_id, Application.applicant_user_id == CURRENT_USER_ID).first()
    if not app:
        session.close()
        raise HTTPException(status_code=404, detail="Application not found")
    result = ApplicationOut.model_validate(app, from_attributes=True)
    session.close()
    return result


@router.patch("/applications/{application_id}", response_model=ApplicationOut, summary="Update an application", description="Update fields of an application belonging to the current user (user_id=1).", operation_id="update_application")
async def update_application(application_id: int, payload: ApplicationUpdate = Body(...)):
    session = SessionLocal()
    app = session.query(Application).filter(Application.id == application_id, Application.applicant_user_id == CURRENT_USER_ID).first()
    if not app:
        session.close()
        raise HTTPException(status_code=404, detail="Application not found")
    if payload.status is not None:
        app.status = payload.status
    if payload.submitted_at is not None:
        app.submitted_at = payload.submitted_at
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Invalid application update")
    session.refresh(app)
    result = ApplicationOut.model_validate(app, from_attributes=True)
    session.close()
    return result


@router.delete("/applications/{application_id}", response_model=MessageOut, summary="Delete an application", description="Delete an application belonging to the current user (user_id=1).", operation_id="delete_application")
async def delete_application(application_id: int):
    session = SessionLocal()
    app = session.query(Application).filter(Application.id == application_id, Application.applicant_user_id == CURRENT_USER_ID).first()
    if not app:
        session.close()
        raise HTTPException(status_code=404, detail="Application not found")
    session.delete(app)
    session.commit()
    session.close()
    return MessageOut(message="Application deleted successfully.")


@router.get("/applications/{application_id}/recommendation-requests", response_model=RecommendationRequestListOut, summary="List recommendation requests for an application", description="Retrieve all recommendation requests for a specific application owned by the current user (user_id=1).", operation_id="list_recommendation_requests")
async def list_recommendation_requests(application_id: int):
    session = SessionLocal()
    app = session.query(Application).filter(Application.id == application_id, Application.applicant_user_id == CURRENT_USER_ID).first()
    if not app:
        session.close()
        raise HTTPException(status_code=404, detail="Application not found")
    reqs = session.query(RecommendationRequest).filter(RecommendationRequest.application_id == application_id).all()
    result = RecommendationRequestListOut(recommendation_requests=[RecommendationRequestOut.model_validate(r, from_attributes=True) for r in reqs])
    session.close()
    return result


@router.post("/applications/{application_id}/recommendation-requests", response_model=RecommendationRequestOut, summary="Create a recommendation request", description="Create a new recommendation request for a specific application owned by the current user (user_id=1).", operation_id="create_recommendation_request")
async def create_recommendation_request(application_id: int, payload: RecommendationRequestCreate = Body(...)):
    session = SessionLocal()
    app = session.query(Application).filter(Application.id == application_id, Application.applicant_user_id == CURRENT_USER_ID).first()
    if not app:
        session.close()
        raise HTTPException(status_code=404, detail="Application not found")
    req = RecommendationRequest(
        application_id=application_id,
        requirement_id=payload.requirement_id,
        recommender_name=payload.recommender_name,
        recommender_email=payload.recommender_email,
        recommender_type=payload.recommender_type,
        status=payload.status if payload.status else "Pending",
        requested_at=datetime.utcnow(),
    )
    session.add(req)
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Invalid recommendation request data")
    session.refresh(req)
    result = RecommendationRequestOut.model_validate(req, from_attributes=True)
    session.close()
    return result


@router.patch("/applications/{application_id}/recommendation-requests/{request_id}", response_model=RecommendationRequestOut, summary="Update a recommendation request", description="Update fields of a recommendation request for an application owned by the current user (user_id=1).", operation_id="update_recommendation_request")
async def update_recommendation_request(application_id: int, request_id: int, payload: RecommendationRequestUpdate = Body(...)):
    session = SessionLocal()
    app = session.query(Application).filter(Application.id == application_id, Application.applicant_user_id == CURRENT_USER_ID).first()
    if not app:
        session.close()
        raise HTTPException(status_code=404, detail="Application not found")
    req = session.query(RecommendationRequest).filter(RecommendationRequest.id == request_id, RecommendationRequest.application_id == application_id).first()
    if not req:
        session.close()
        raise HTTPException(status_code=404, detail="Recommendation request not found")
    if payload.status is not None:
        req.status = payload.status
    if payload.submitted_at is not None:
        req.submitted_at = payload.submitted_at
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Invalid recommendation request update")
    session.refresh(req)
    result = RecommendationRequestOut.model_validate(req, from_attributes=True)
    session.close()
    return result


@router.delete("/applications/{application_id}/recommendation-requests/{request_id}", response_model=MessageOut, summary="Delete a recommendation request", description="Delete a recommendation request for an application owned by the current user (user_id=1).", operation_id="delete_recommendation_request")
async def delete_recommendation_request(application_id: int, request_id: int):
    session = SessionLocal()
    app = session.query(Application).filter(Application.id == application_id, Application.applicant_user_id == CURRENT_USER_ID).first()
    if not app:
        session.close()
        raise HTTPException(status_code=404, detail="Application not found")
    req = session.query(RecommendationRequest).filter(RecommendationRequest.id == request_id, RecommendationRequest.application_id == application_id).first()
    if not req:
        session.close()
        raise HTTPException(status_code=404, detail="Recommendation request not found")
    session.delete(req)
    session.commit()
    session.close()
    return MessageOut(message="Recommendation request deleted successfully.")