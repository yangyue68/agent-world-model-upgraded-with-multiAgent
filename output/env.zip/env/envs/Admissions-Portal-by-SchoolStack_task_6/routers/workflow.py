from datetime import datetime, timedelta
from fastapi import APIRouter, HTTPException

from database import SessionLocal
from models import Application, DeadlineRule, RecommendationRequirement, RecommendationRequest, ReminderSchedule, ReminderLog
from schemas import WorkflowApplyResult, WorkflowReminderResult

router = APIRouter(prefix="/api", tags=["Workflow"])


@router.post("/programs/{program_id}/workflow/apply-deadline-rules", response_model=list[WorkflowApplyResult], summary="Apply deadline rules for a program", description="Apply deadline rules to applications missing required items, moving them per action_on_missing.", operation_id="apply_deadline_rules")
async def apply_deadline_rules(program_id: int):
    session = SessionLocal()
    rules = session.query(DeadlineRule).filter(DeadlineRule.program_id == program_id).all()
    if not rules:
        session.close()
        raise HTTPException(status_code=404, detail="No deadline rules found for this program")
    requirements = session.query(RecommendationRequirement).filter(RecommendationRequirement.program_id == program_id).all()
    applications = session.query(Application).filter(Application.program_id == program_id).all()
    results = []
    for rule in rules:
        affected_ids = []
        for app in applications:
            missing = False
            for req in requirements:
                submitted_count = session.query(RecommendationRequest).filter(
                    RecommendationRequest.application_id == app.id,
                    RecommendationRequest.requirement_id == req.id,
                    RecommendationRequest.status == "Submitted",
                ).count()
                if submitted_count < req.required_count:
                    missing = True
                    break
            if missing:
                if rule.action_on_missing == "Waitlist Review":
                    app.status = "Waitlist Review"
                elif rule.action_on_missing == "Reject":
                    app.status = "Rejected"
                affected_ids.append(app.id)
        session.commit()
        results.append(WorkflowApplyResult(
            rule_id=rule.id,
            rule_name=rule.rule_name,
            action_on_missing=rule.action_on_missing,
            affected_application_ids=affected_ids,
            affected_count=len(affected_ids),
        ))
    session.close()
    return results


@router.post("/programs/{program_id}/workflow/generate-reminders", response_model=list[WorkflowReminderResult], summary="Generate reminder logs for incomplete recommendations", description="Generate simulated reminder log entries for applications with incomplete recommendations.", operation_id="generate_reminders")
async def generate_reminders(program_id: int):
    session = SessionLocal()
    schedules = session.query(ReminderSchedule).filter(
        ReminderSchedule.program_id == program_id,
        ReminderSchedule.is_active == 1,
        ReminderSchedule.reminder_type == "Recommendation Incomplete",
    ).all()
    if not schedules:
        session.close()
        raise HTTPException(status_code=404, detail="No active recommendation reminder schedules found for this program")
    requirements = session.query(RecommendationRequirement).filter(RecommendationRequirement.program_id == program_id).all()
    applications = session.query(Application).filter(Application.program_id == program_id).all()
    results = []
    for schedule in schedules:
        generated_ids = []
        for app in applications:
            missing = False
            for req in requirements:
                submitted_count = session.query(RecommendationRequest).filter(
                    RecommendationRequest.application_id == app.id,
                    RecommendationRequest.requirement_id == req.id,
                    RecommendationRequest.status == "Submitted",
                ).count()
                if submitted_count < req.required_count:
                    missing = True
                    break
            if missing:
                log = ReminderLog(
                    reminder_schedule_id=schedule.id,
                    application_id=app.id,
                    sent_at=datetime.utcnow(),
                    status="Sent",
                )
                session.add(log)
                session.flush()
                generated_ids.append(log.id)
        session.commit()
        results.append(WorkflowReminderResult(
            schedule_id=schedule.id,
            reminder_type=schedule.reminder_type,
            generated_log_ids=generated_ids,
            generated_count=len(generated_ids),
        ))
    session.close()
    return results