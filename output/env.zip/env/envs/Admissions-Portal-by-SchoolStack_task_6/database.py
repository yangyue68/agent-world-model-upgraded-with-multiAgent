import os
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base

DATABASE_PATH = os.getenv("DATABASE_PATH", "sqlite:///xxxx.db")

engine = create_engine(DATABASE_PATH, connect_args={"check_same_thread": False} if DATABASE_PATH.startswith("sqlite") else {})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()