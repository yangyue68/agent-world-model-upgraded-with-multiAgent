from datetime import datetime
from typing import Optional
from fastapi import APIRouter, HTTPException, Query
from database import SessionLocal
from models import AuditLog
from schemas import AuditLogOut, AuditLogCreate, AuditLogListOut

router = APIRouter(prefix="/api/audit-log", tags=["AuditLog"])


@router.get("", response_model=AuditLogListOut, operation_id="list_audit_log", summary="List audit log entries with optional filters", description="Retrieve audit log entries, optionally filtered by user, entity, action, or date range")
async def list_audit_log(user_id: Optional[int] = Query(None), entity_type: Optional[str] = Query(None), entity_id: Optional[int] = Query(None), action: Optional[str] = Query(None), created_after: Optional[str] = Query(None), created_before: Optional[str] = Query(None), limit: int = Query(50), offset: int = Query(0)):
    session = SessionLocal()
    query = session.query(AuditLog)
    if user_id is not None:
        query = query.filter(AuditLog.user_id == user_id)
    if entity_type is not None:
        query = query.filter(AuditLog.entity_type == entity_type)
    if entity_id is not None:
        query = query.filter(AuditLog.entity_id == entity_id)
    if action is not None:
        query = query.filter(AuditLog.action == action)
    if created_after is not None:
        query = query.filter(AuditLog.created_at >= datetime.fromisoformat(created_after.replace("Z", "+00:00").replace("+00:00", "")))
    if created_before is not None:
        query = query.filter(AuditLog.created_at <= datetime.fromisoformat(created_before.replace("Z", "+00:00").replace("+00:00", "")))
    total = query.count()
    entries = query.offset(offset).limit(limit).all()
    result = AuditLogListOut(entries=[AuditLogOut.model_validate(e, from_attributes=True) for e in entries], total=total)
    session.close()
    return result


@router.post("", response_model=AuditLogOut, operation_id="create_audit_log_entry", summary="Create a new audit log entry", description="Record a new audit log entry for an action performed by the current user")
async def create_audit_log_entry(payload: AuditLogCreate):
    session = SessionLocal()
    entry = AuditLog(user_id=1, action=payload.action, entity_type=payload.entity_type, entity_id=payload.entity_id, details=payload.details, created_at=datetime.utcnow())
    session.add(entry)
    session.commit()
    session.refresh(entry)
    result = AuditLogOut.model_validate(entry, from_attributes=True)
    session.close()
    return result


@router.get("/{id}", response_model=AuditLogOut, operation_id="get_audit_log_entry", summary="Get a single audit log entry by ID", description="Retrieve a specific audit log entry using its unique identifier")
async def get_audit_log_entry(id: int):
    session = SessionLocal()
    entry = session.query(AuditLog).filter(AuditLog.id == id).first()
    if entry is None:
        session.close()
        raise HTTPException(status_code=404, detail="Audit log entry not found")
    result = AuditLogOut.model_validate(entry, from_attributes=True)
    session.close()
    return result


@router.delete("/{id}", response_model=dict, operation_id="delete_audit_log_entry", summary="Delete an audit log entry by ID", description="Permanently remove a specific audit log entry from the system")
async def delete_audit_log_entry(id: int):
    session = SessionLocal()
    entry = session.query(AuditLog).filter(AuditLog.id == id).first()
    if entry is None:
        session.close()
        raise HTTPException(status_code=404, detail="Audit log entry not found")
    session.delete(entry)
    session.commit()
    session.close()
    return {"success": True, "message": "Audit log entry deleted successfully"}