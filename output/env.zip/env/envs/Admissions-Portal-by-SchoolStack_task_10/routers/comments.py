from datetime import datetime
from fastapi import APIRouter, HTTPException
from database import SessionLocal
from models import Comment, CommentThread, Application
from schemas import CommentOut, CommentCreate, CommentUpdate, CommentListOut, CommentThreadOut, CommentThreadCreate, CommentThreadsForAppOut

router = APIRouter(tags=["Comments"])


@router.get("/api/applications/{application_id}/comment-threads", response_model=CommentThreadsForAppOut, operation_id="list_comment_threads_by_application", summary="List comment threads for an application", description="Retrieve all comment threads belonging to a specific application")
async def list_comment_threads_by_application(application_id: int):
    session = SessionLocal()
    app = session.query(Application).filter(Application.id == application_id).first()
    if app is None:
        session.close()
        raise HTTPException(status_code=404, detail="Application not found")
    threads = session.query(CommentThread).filter(CommentThread.application_id == application_id).all()
    result = CommentThreadsForAppOut(threads=[CommentThreadOut.model_validate(t, from_attributes=True) for t in threads])
    session.close()
    return result


@router.post("/api/applications/{application_id}/comment-threads", response_model=CommentThreadOut, operation_id="create_comment_thread", summary="Create a comment thread on an application", description="Create a new comment thread for the specified application")
async def create_comment_thread(application_id: int, payload: CommentThreadCreate):
    session = SessionLocal()
    app = session.query(Application).filter(Application.id == application_id).first()
    if app is None:
        session.close()
        raise HTTPException(status_code=404, detail="Application not found")
    now = datetime.utcnow()
    thread = CommentThread(application_id=application_id, created_by=payload.created_by if payload.created_by is not None else 1, created_at=now, updated_at=now)
    session.add(thread)
    session.commit()
    session.refresh(thread)
    result = CommentThreadOut.model_validate(thread, from_attributes=True)
    session.close()
    return result


@router.get("/api/comment-threads/{thread_id}", response_model=CommentThreadOut, operation_id="get_comment_thread", summary="Get a comment thread by ID", description="Retrieve a single comment thread with its metadata")
async def get_comment_thread(thread_id: int):
    session = SessionLocal()
    thread = session.query(CommentThread).filter(CommentThread.id == thread_id).first()
    if thread is None:
        session.close()
        raise HTTPException(status_code=404, detail="Comment thread not found")
    result = CommentThreadOut.model_validate(thread, from_attributes=True)
    session.close()
    return result


@router.delete("/api/comment-threads/{thread_id}", response_model=dict, operation_id="delete_comment_thread", summary="Delete a comment thread", description="Delete a comment thread and its comments by thread ID")
async def delete_comment_thread(thread_id: int):
    session = SessionLocal()
    thread = session.query(CommentThread).filter(CommentThread.id == thread_id).first()
    if thread is None:
        session.close()
        raise HTTPException(status_code=404, detail="Comment thread not found")
    session.query(Comment).filter(Comment.thread_id == thread_id).delete()
    session.delete(thread)
    session.commit()
    session.close()
    return {"deleted": True, "thread_id": thread_id}


@router.get("/api/comment-threads/{thread_id}/comments", response_model=CommentListOut, operation_id="list_comments_by_thread", summary="List comments in a thread", description="Retrieve all comments belonging to a specific comment thread")
async def list_comments_by_thread(thread_id: int):
    session = SessionLocal()
    thread = session.query(CommentThread).filter(CommentThread.id == thread_id).first()
    if thread is None:
        session.close()
        raise HTTPException(status_code=404, detail="Comment thread not found")
    comments = session.query(Comment).filter(Comment.thread_id == thread_id).all()
    result = CommentListOut(comments=[CommentOut.model_validate(c, from_attributes=True) for c in comments], total=len(comments))
    session.close()
    return result


@router.post("/api/comment-threads/{thread_id}/comments", response_model=CommentOut, operation_id="create_comment", summary="Add a comment to a thread", description="Create a new comment within the specified comment thread")
async def create_comment(thread_id: int, payload: CommentCreate):
    session = SessionLocal()
    thread = session.query(CommentThread).filter(CommentThread.id == thread_id).first()
    if thread is None:
        session.close()
        raise HTTPException(status_code=404, detail="Comment thread not found")
    now = datetime.utcnow()
    comment = Comment(thread_id=thread_id, author_id=payload.author_id if payload.author_id is not None else 1, body=payload.body, created_at=now, updated_at=now)
    session.add(comment)
    thread.updated_at = now
    session.commit()
    session.refresh(comment)
    result = CommentOut.model_validate(comment, from_attributes=True)
    session.close()
    return result


@router.get("/api/comments/{comment_id}", response_model=CommentOut, operation_id="get_comment", summary="Get a comment by ID", description="Retrieve a single comment with its metadata")
async def get_comment(comment_id: int):
    session = SessionLocal()
    comment = session.query(Comment).filter(Comment.id == comment_id).first()
    if comment is None:
        session.close()
        raise HTTPException(status_code=404, detail="Comment not found")
    result = CommentOut.model_validate(comment, from_attributes=True)
    session.close()
    return result


@router.patch("/api/comments/{comment_id}", response_model=CommentOut, operation_id="update_comment", summary="Update a comment body", description="Update the text body of an existing comment")
async def update_comment(comment_id: int, payload: CommentUpdate):
    session = SessionLocal()
    comment = session.query(Comment).filter(Comment.id == comment_id).first()
    if comment is None:
        session.close()
        raise HTTPException(status_code=404, detail="Comment not found")
    comment.body = payload.body
    comment.updated_at = datetime.utcnow()
    session.commit()
    session.refresh(comment)
    result = CommentOut.model_validate(comment, from_attributes=True)
    session.close()
    return result


@router.delete("/api/comments/{comment_id}", response_model=dict, operation_id="delete_comment", summary="Delete a comment", description="Delete a single comment by its ID")
async def delete_comment(comment_id: int):
    session = SessionLocal()
    comment = session.query(Comment).filter(Comment.id == comment_id).first()
    if comment is None:
        session.close()
        raise HTTPException(status_code=404, detail="Comment not found")
    session.delete(comment)
    session.commit()
    session.close()
    return {"deleted": True, "comment_id": comment_id}