from datetime import datetime
from typing import Optional
from fastapi import APIRouter, HTTPException, Query
from sqlalchemy.exc import IntegrityError
from database import SessionLocal
from models import ApplicationRubric, Application, Rubric
from schemas import ApplicationRubricOut, ApplicationRubricCreate, ApplicationRubricListOut, ApplicationRubricBulkRequest, ApplicationRubricBulkOut, ApplicationRubricsForAppOut, ApplicationRubricsForRubricOut

router = APIRouter(prefix="/api/application-rubrics", tags=["ApplicationRubrics"])


@router.get("", response_model=ApplicationRubricListOut, operation_id="list_application_rubrics", summary="List rubric attachments for applications", description="Retrieve application_rubrics records, optionally filtered by application_id or rubric_id")
async def list_application_rubrics(application_id: Optional[int] = Query(None), rubric_id: Optional[int] = Query(None), limit: int = Query(50), offset: int = Query(0)):
    session = SessionLocal()
    query = session.query(ApplicationRubric)
    if application_id is not None:
        query = query.filter(ApplicationRubric.application_id == application_id)
    if rubric_id is not None:
        query = query.filter(ApplicationRubric.rubric_id == rubric_id)
    total = query.count()
    records = query.offset(offset).limit(limit).all()
    result = ApplicationRubricListOut(application_rubrics=[ApplicationRubricOut.model_validate(r, from_attributes=True) for r in records], total=total)
    session.close()
    return result


@router.post("/bulk", response_model=ApplicationRubricBulkOut, operation_id="bulk_create_application_rubrics", summary="Bulk attach a rubric to multiple applications", description="Create application_rubrics records for many applications with one rubric")
async def bulk_create_application_rubrics(payload: ApplicationRubricBulkRequest):
    session = SessionLocal()
    now = datetime.utcnow()
    created = []
    skipped = 0
    for app_id in payload.application_ids:
        app = session.query(Application).filter(Application.id == app_id).first()
        if app is None:
            skipped += 1
            continue
        existing = session.query(ApplicationRubric).filter(ApplicationRubric.application_id == app_id, ApplicationRubric.rubric_id == payload.rubric_id).first()
        if existing is not None:
            skipped += 1
            continue
        record = ApplicationRubric(application_id=app_id, rubric_id=payload.rubric_id, attached_by=1, attached_at=now)
        session.add(record)
        session.flush()
        created.append(record)
    session.commit()
    result = ApplicationRubricBulkOut(attached_count=len(created), skipped_count=skipped, application_rubrics=[ApplicationRubricOut.model_validate(r, from_attributes=True) for r in created])
    session.close()
    return result


@router.get("/{id}", response_model=ApplicationRubricOut, operation_id="get_application_rubric", summary="Get a single application rubric attachment", description="Retrieve one application_rubrics record by its id")
async def get_application_rubric(id: int):
    session = SessionLocal()
    record = session.query(ApplicationRubric).filter(ApplicationRubric.id == id).first()
    if record is None:
        session.close()
        raise HTTPException(status_code=404, detail="Application rubric not found")
    result = ApplicationRubricOut.model_validate(record, from_attributes=True)
    session.close()
    return result


@router.post("", response_model=ApplicationRubricOut, operation_id="create_application_rubric", summary="Attach a rubric to an application", description="Create an application_rubrics record linking a rubric to an application")
async def create_application_rubric(payload: ApplicationRubricCreate):
    session = SessionLocal()
    app = session.query(Application).filter(Application.id == payload.application_id).first()
    if app is None:
        session.close()
        raise HTTPException(status_code=404, detail="Application not found")
    rubric = session.query(Rubric).filter(Rubric.id == payload.rubric_id).first()
    if rubric is None:
        session.close()
        raise HTTPException(status_code=404, detail="Rubric not found")
    record = ApplicationRubric(application_id=payload.application_id, rubric_id=payload.rubric_id, attached_by=1, attached_at=datetime.utcnow())
    session.add(record)
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Rubric already attached to this application")
    session.refresh(record)
    result = ApplicationRubricOut.model_validate(record, from_attributes=True)
    session.close()
    return result


@router.delete("/{id}", response_model=dict, operation_id="delete_application_rubric", summary="Detach a rubric from an application", description="Delete an application_rubrics record by its id")
async def delete_application_rubric(id: int):
    session = SessionLocal()
    record = session.query(ApplicationRubric).filter(ApplicationRubric.id == id).first()
    if record is None:
        session.close()
        raise HTTPException(status_code=404, detail="Application rubric not found")
    session.delete(record)
    session.commit()
    session.close()
    return {"deleted": True, "id": id}