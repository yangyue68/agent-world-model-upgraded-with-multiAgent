from datetime import datetime
from typing import Optional
from fastapi import APIRouter, HTTPException, Query
from database import SessionLocal
from models import Application, ApplicationRubric, CommentThread, Comment, AuditLog
from schemas import ApplicationOut, ApplicationListOut, ApplicationPatch, BulkAssignRequest, BulkAssignOut, BulkDeadlineRequest, BulkDeadlineOut, BulkAttachRubricRequest, BulkAttachRubricOut, BulkCommentRequest, BulkCommentOut

router = APIRouter(prefix="/api/applications", tags=["Applications"])


@router.get("", response_model=ApplicationListOut, operation_id="list_applications", summary="List applications with filters", description="Retrieve applications filtered by program, intake, status, reviewer, or financial aid completeness")
async def list_applications(program_id: Optional[int] = Query(None), intake_id: Optional[int] = Query(None), status: Optional[str] = Query(None), assigned_reviewer_id: Optional[int] = Query(None), unassigned: Optional[bool] = Query(None), financial_aid_documents_complete: Optional[bool] = Query(None), limit: int = Query(50), offset: int = Query(0)):
    session = SessionLocal()
    query = session.query(Application)
    if program_id is not None:
        query = query.filter(Application.program_id == program_id)
    if intake_id is not None:
        query = query.filter(Application.intake_id == intake_id)
    if status is not None:
        query = query.filter(Application.status == status)
    if assigned_reviewer_id is not None:
        query = query.filter(Application.assigned_reviewer_id == assigned_reviewer_id)
    if unassigned is True:
        query = query.filter(Application.assigned_reviewer_id.is_(None))
    if financial_aid_documents_complete is not None:
        query = query.filter(Application.financial_aid_documents_complete == (1 if financial_aid_documents_complete else 0))
    total = query.count()
    apps = query.offset(offset).limit(limit).all()
    result = ApplicationListOut(applications=[ApplicationOut.model_validate(a, from_attributes=True) for a in apps], total=total)
    session.close()
    return result


@router.post("/bulk-assign", response_model=BulkAssignOut, operation_id="bulk_assign_reviewer", summary="Bulk assign reviewer to applications", description="Assign a reviewer to multiple applications in one atomic operation")
async def bulk_assign_reviewer(payload: BulkAssignRequest):
    session = SessionLocal()
    now = datetime.utcnow()
    updated_ids = []
    for app_id in payload.application_ids:
        app = session.query(Application).filter(Application.id == app_id).first()
        if app is None:
            continue
        app.assigned_reviewer_id = payload.assigned_reviewer_id
        app.updated_at = now
        session.add(AuditLog(user_id=1, action="bulk_assign", entity_type="application", entity_id=app.id, details=f"Assigned reviewer {payload.assigned_reviewer_id}", created_at=now))
        updated_ids.append(app.id)
    session.commit()
    result = BulkAssignOut(updated_count=len(updated_ids), application_ids=updated_ids)
    session.close()
    return result


@router.post("/bulk-deadline", response_model=BulkDeadlineOut, operation_id="bulk_set_review_deadline", summary="Bulk set review deadline", description="Set the review deadline for multiple applications in one atomic operation")
async def bulk_set_review_deadline(payload: BulkDeadlineRequest):
    session = SessionLocal()
    now = datetime.utcnow()
    updated_ids = []
    for app_id in payload.application_ids:
        app = session.query(Application).filter(Application.id == app_id).first()
        if app is None:
            continue
        app.review_deadline = payload.review_deadline
        app.updated_at = now
        session.add(AuditLog(user_id=1, action="bulk_deadline", entity_type="application", entity_id=app.id, details=f"Set deadline {payload.review_deadline}", created_at=now))
        updated_ids.append(app.id)
    session.commit()
    result = BulkDeadlineOut(updated_count=len(updated_ids), application_ids=updated_ids)
    session.close()
    return result


@router.post("/bulk-attach-rubric", response_model=BulkAttachRubricOut, operation_id="bulk_attach_rubric", summary="Bulk attach rubric to applications", description="Attach a rubric to multiple applications in one atomic operation")
async def bulk_attach_rubric(payload: BulkAttachRubricRequest):
    session = SessionLocal()
    now = datetime.utcnow()
    attached_ids = []
    for app_id in payload.application_ids:
        app = session.query(Application).filter(Application.id == app_id).first()
        if app is None:
            continue
        existing = session.query(ApplicationRubric).filter(ApplicationRubric.application_id == app_id, ApplicationRubric.rubric_id == payload.rubric_id).first()
        if existing is not None:
            continue
        session.add(ApplicationRubric(application_id=app_id, rubric_id=payload.rubric_id, attached_by=1, attached_at=now))
        attached_ids.append(app_id)
    session.commit()
    result = BulkAttachRubricOut(attached_count=len(attached_ids), application_ids=attached_ids)
    session.close()
    return result


@router.post("/bulk-comment", response_model=BulkCommentOut, operation_id="bulk_add_comment", summary="Bulk add comment to application threads", description="Add a comment to the comment thread of multiple applications atomically")
async def bulk_add_comment(payload: BulkCommentRequest):
    session = SessionLocal()
    now = datetime.utcnow()
    comment_ids = []
    for app_id in payload.application_ids:
        app = session.query(Application).filter(Application.id == app_id).first()
        if app is None:
            continue
        thread = session.query(CommentThread).filter(CommentThread.application_id == app_id).first()
        if thread is None:
            thread = CommentThread(application_id=app_id, created_by=1, created_at=now, updated_at=now)
            session.add(thread)
            session.flush()
        comment = Comment(thread_id=thread.id, author_id=1, body=payload.body, created_at=now, updated_at=now)
        session.add(comment)
        session.flush()
        comment_ids.append(comment.id)
    session.commit()
    result = BulkCommentOut(created_count=len(comment_ids), comment_ids=comment_ids)
    session.close()
    return result


@router.get("/{application_id}", response_model=ApplicationOut, operation_id="get_application", summary="Get a single application", description="Retrieve full details for one application by id")
async def get_application(application_id: int):
    session = SessionLocal()
    app = session.query(Application).filter(Application.id == application_id).first()
    if app is None:
        session.close()
        raise HTTPException(status_code=404, detail="Application not found")
    result = ApplicationOut.model_validate(app, from_attributes=True)
    session.close()
    return result


@router.patch("/{application_id}", response_model=ApplicationOut, operation_id="update_application", summary="Update application fields", description="Update status, reviewer, deadline, or financial aid flag for an application")
async def update_application(application_id: int, payload: ApplicationPatch):
    session = SessionLocal()
    app = session.query(Application).filter(Application.id == application_id).first()
    if app is None:
        session.close()
        raise HTTPException(status_code=404, detail="Application not found")
    if payload.status is not None:
        app.status = payload.status
    if payload.assigned_reviewer_id is not None:
        app.assigned_reviewer_id = payload.assigned_reviewer_id
    if payload.review_deadline is not None:
        app.review_deadline = payload.review_deadline
    if payload.financial_aid_documents_complete is not None:
        app.financial_aid_documents_complete = payload.financial_aid_documents_complete
    app.updated_at = datetime.utcnow()
    session.add(AuditLog(user_id=1, action="update", entity_type="application", entity_id=app.id, details="Application updated", created_at=datetime.utcnow()))
    session.commit()
    session.refresh(app)
    result = ApplicationOut.model_validate(app, from_attributes=True)
    session.close()
    return result