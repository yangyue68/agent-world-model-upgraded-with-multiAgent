from typing import Optional
from fastapi import APIRouter, HTTPException, Query
from sqlalchemy.exc import IntegrityError
from database import SessionLocal
from models import User, Application
from schemas import UserOut, UserCreate, UserUpdate, UserListOut, ApplicationListOut

router = APIRouter(prefix="/api/users", tags=["Users"])


@router.get("", response_model=UserListOut, operation_id="list_users", summary="List users with optional role filter", description="Retrieve users, optionally filtered by role, email, or name")
async def list_users(role: Optional[str] = Query(None), email: Optional[str] = Query(None), full_name: Optional[str] = Query(None), limit: int = Query(50), offset: int = Query(0)):
    session = SessionLocal()
    query = session.query(User)
    if role is not None:
        query = query.filter(User.role == role)
    if email is not None:
        query = query.filter(User.email == email)
    if full_name is not None:
        query = query.filter(User.full_name.ilike(f"%{full_name}%"))
    total = query.count()
    users = query.offset(offset).limit(limit).all()
    result = UserListOut(users=[UserOut.model_validate(u, from_attributes=True) for u in users], total=total)
    session.close()
    return result


@router.get("/{id}", response_model=UserOut, operation_id="get_user", summary="Get a single user by ID", description="Retrieve details of a specific user by their unique ID")
async def get_user(id: int):
    session = SessionLocal()
    user = session.query(User).filter(User.id == id).first()
    if user is None:
        session.close()
        raise HTTPException(status_code=404, detail="User not found")
    result = UserOut.model_validate(user, from_attributes=True)
    session.close()
    return result


@router.post("", response_model=UserOut, operation_id="create_user", summary="Create a new user", description="Create a new user record with a unique email and valid role")
async def create_user(payload: UserCreate):
    session = SessionLocal()
    user = User(full_name=payload.full_name, email=payload.email, role=payload.role)
    session.add(user)
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Email already exists or invalid data")
    session.refresh(user)
    result = UserOut.model_validate(user, from_attributes=True)
    session.close()
    return result


@router.put("/{id}", response_model=UserOut, operation_id="replace_user", summary="Replace a user record", description="Fully update a user's full_name, email, and role by ID")
async def replace_user(id: int, payload: UserCreate):
    session = SessionLocal()
    user = session.query(User).filter(User.id == id).first()
    if user is None:
        session.close()
        raise HTTPException(status_code=404, detail="User not found")
    user.full_name = payload.full_name
    user.email = payload.email
    user.role = payload.role
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Email already exists or invalid data")
    session.refresh(user)
    result = UserOut.model_validate(user, from_attributes=True)
    session.close()
    return result


@router.patch("/{id}", response_model=UserOut, operation_id="update_user", summary="Partially update a user", description="Update one or more fields of a user record by ID")
async def update_user(id: int, payload: UserUpdate):
    session = SessionLocal()
    user = session.query(User).filter(User.id == id).first()
    if user is None:
        session.close()
        raise HTTPException(status_code=404, detail="User not found")
    if payload.full_name is not None:
        user.full_name = payload.full_name
    if payload.email is not None:
        user.email = payload.email
    if payload.role is not None:
        user.role = payload.role
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Email already exists or invalid data")
    session.refresh(user)
    result = UserOut.model_validate(user, from_attributes=True)
    session.close()
    return result


@router.delete("/{id}", response_model=dict, operation_id="delete_user", summary="Delete a user by ID", description="Remove a user record; related applications will have reviewer set to null")
async def delete_user(id: int):
    session = SessionLocal()
    user = session.query(User).filter(User.id == id).first()
    if user is None:
        session.close()
        raise HTTPException(status_code=404, detail="User not found")
    session.query(Application).filter(Application.assigned_reviewer_id == id).update({Application.assigned_reviewer_id: None})
    session.delete(user)
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Cannot delete user due to existing references")
    session.close()
    return {"deleted": True, "id": id}


@router.get("/{id}/applications", response_model=ApplicationListOut, operation_id="list_user_applications", summary="List applications assigned to a user", description="Retrieve applications where the given user is the assigned reviewer")
async def list_user_applications(id: int, status: Optional[str] = Query(None), program_id: Optional[int] = Query(None), intake_id: Optional[int] = Query(None), limit: int = Query(50), offset: int = Query(0)):
    session = SessionLocal()
    query = session.query(Application).filter(Application.assigned_reviewer_id == id)
    if status is not None:
        query = query.filter(Application.status == status)
    if program_id is not None:
        query = query.filter(Application.program_id == program_id)
    if intake_id is not None:
        query = query.filter(Application.intake_id == intake_id)
    total = query.count()
    apps = query.offset(offset).limit(limit).all()
    from schemas import ApplicationOut
    result = ApplicationListOut(applications=[ApplicationOut.model_validate(a, from_attributes=True) for a in apps], total=total)
    session.close()
    return result