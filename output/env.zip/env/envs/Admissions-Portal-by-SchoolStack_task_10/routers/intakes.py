from datetime import datetime
from typing import Optional
from fastapi import APIRouter, HTTPException, Query
from sqlalchemy.exc import IntegrityError
from database import SessionLocal
from models import Intake, Application, ApplicationRubric, CommentThread, Comment, AuditLog
from schemas import IntakeOut, IntakeCreate, IntakeUpdate, IntakeListOut, ApplicationListOut, ApplicationOut, IntakeBulkAssignRequest, IntakeBulkAssignOut, IntakeBulkAttachRubricRequest, IntakeBulkAttachRubricOut, IntakeBulkCommentRequest, IntakeBulkCommentOut

router = APIRouter(prefix="/api/intakes", tags=["Intakes"])


@router.get("", response_model=IntakeListOut, operation_id="list_intakes", summary="List all intakes", description="Retrieve all intakes, optionally filtered by term, year, or level")
async def list_intakes(term: Optional[str] = Query(None), year: Optional[int] = Query(None), level: Optional[str] = Query(None)):
    session = SessionLocal()
    query = session.query(Intake)
    if term is not None:
        query = query.filter(Intake.term == term)
    if year is not None:
        query = query.filter(Intake.year == year)
    if level is not None:
        query = query.filter(Intake.level == level)
    intakes = query.all()
    result = IntakeListOut(intakes=[IntakeOut.model_validate(i, from_attributes=True) for i in intakes])
    session.close()
    return result


@router.post("", response_model=IntakeOut, operation_id="create_intake", summary="Create a new intake", description="Create a new intake with term, year, and level")
async def create_intake(payload: IntakeCreate):
    session = SessionLocal()
    intake = Intake(term=payload.term, year=payload.year, level=payload.level)
    session.add(intake)
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Intake already exists or invalid data")
    session.refresh(intake)
    result = IntakeOut.model_validate(intake, from_attributes=True)
    session.close()
    return result


@router.get("/{intake_id}", response_model=IntakeOut, operation_id="get_intake", summary="Get an intake by ID", description="Retrieve a single intake by its ID")
async def get_intake(intake_id: int):
    session = SessionLocal()
    intake = session.query(Intake).filter(Intake.id == intake_id).first()
    if intake is None:
        session.close()
        raise HTTPException(status_code=404, detail="Intake not found")
    result = IntakeOut.model_validate(intake, from_attributes=True)
    session.close()
    return result


@router.put("/{intake_id}", response_model=IntakeOut, operation_id="update_intake", summary="Update an intake", description="Update term, year, or level of an existing intake")
async def update_intake(intake_id: int, payload: IntakeUpdate):
    session = SessionLocal()
    intake = session.query(Intake).filter(Intake.id == intake_id).first()
    if intake is None:
        session.close()
        raise HTTPException(status_code=404, detail="Intake not found")
    if payload.term is not None:
        intake.term = payload.term
    if payload.year is not None:
        intake.year = payload.year
    if payload.level is not None:
        intake.level = payload.level
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Intake already exists or invalid data")
    session.refresh(intake)
    result = IntakeOut.model_validate(intake, from_attributes=True)
    session.close()
    return result


@router.delete("/{intake_id}", response_model=dict, operation_id="delete_intake", summary="Delete an intake", description="Delete an intake by ID. Fails if applications reference it")
async def delete_intake(intake_id: int):
    session = SessionLocal()
    intake = session.query(Intake).filter(Intake.id == intake_id).first()
    if intake is None:
        session.close()
        raise HTTPException(status_code=404, detail="Intake not found")
    refs = session.query(Application).filter(Application.intake_id == intake_id).count()
    if refs > 0:
        session.close()
        raise HTTPException(status_code=400, detail="Cannot delete intake with existing applications")
    session.delete(intake)
    session.commit()
    session.close()
    return {"success": True}


@router.get("/{intake_id}/applications", response_model=ApplicationListOut, operation_id="list_intake_applications", summary="List applications for an intake", description="Retrieve applications for a given intake, optionally filtered by program, status, or reviewer")
async def list_intake_applications(intake_id: int, program_id: Optional[int] = Query(None), status: Optional[str] = Query(None), assigned_reviewer_id: Optional[int] = Query(None), financial_aid_documents_complete: Optional[int] = Query(None)):
    session = SessionLocal()
    intake = session.query(Intake).filter(Intake.id == intake_id).first()
    if intake is None:
        session.close()
        raise HTTPException(status_code=404, detail="Intake not found")
    query = session.query(Application).filter(Application.intake_id == intake_id)
    if program_id is not None:
        query = query.filter(Application.program_id == program_id)
    if status is not None:
        query = query.filter(Application.status == status)
    if assigned_reviewer_id is not None:
        query = query.filter(Application.assigned_reviewer_id == assigned_reviewer_id)
    if financial_aid_documents_complete is not None:
        query = query.filter(Application.financial_aid_documents_complete == financial_aid_documents_complete)
    apps = query.all()
    result = ApplicationListOut(applications=[ApplicationOut.model_validate(a, from_attributes=True) for a in apps], total=len(apps))
    session.close()
    return result


@router.post("/{intake_id}/applications/bulk-assign", response_model=IntakeBulkAssignOut, operation_id="bulk_assign_applications", summary="Bulk assign applications to a reviewer", description="Assign multiple applications in an intake to a reviewer and optionally set review deadline")
async def bulk_assign_applications(intake_id: int, payload: IntakeBulkAssignRequest):
    session = SessionLocal()
    intake = session.query(Intake).filter(Intake.id == intake_id).first()
    if intake is None:
        session.close()
        raise HTTPException(status_code=404, detail="Intake not found")
    now = datetime.utcnow()
    updated = []
    for app_id in payload.application_ids:
        app = session.query(Application).filter(Application.id == app_id, Application.intake_id == intake_id).first()
        if app is None:
            continue
        app.assigned_reviewer_id = payload.assigned_reviewer_id
        if payload.review_deadline is not None:
            app.review_deadline = payload.review_deadline
        app.updated_at = now
        session.add(AuditLog(user_id=1, action="bulk_assign", entity_type="application", entity_id=app.id, details=f"Assigned reviewer {payload.assigned_reviewer_id}", created_at=now))
        updated.append(app)
    session.commit()
    for app in updated:
        session.refresh(app)
    result = IntakeBulkAssignOut(updated_count=len(updated), applications=[ApplicationOut.model_validate(a, from_attributes=True) for a in updated])
    session.close()
    return result


@router.post("/{intake_id}/applications/bulk-attach-rubric", response_model=IntakeBulkAttachRubricOut, operation_id="bulk_attach_rubric", summary="Bulk attach a rubric to applications", description="Attach a rubric to multiple applications in an intake")
async def bulk_attach_rubric(intake_id: int, payload: IntakeBulkAttachRubricRequest):
    session = SessionLocal()
    intake = session.query(Intake).filter(Intake.id == intake_id).first()
    if intake is None:
        session.close()
        raise HTTPException(status_code=404, detail="Intake not found")
    now = datetime.utcnow()
    count = 0
    for app_id in payload.application_ids:
        app = session.query(Application).filter(Application.id == app_id, Application.intake_id == intake_id).first()
        if app is None:
            continue
        existing = session.query(ApplicationRubric).filter(ApplicationRubric.application_id == app_id, ApplicationRubric.rubric_id == payload.rubric_id).first()
        if existing is not None:
            continue
        session.add(ApplicationRubric(application_id=app_id, rubric_id=payload.rubric_id, attached_by=1, attached_at=now))
        count += 1
    session.commit()
    result = IntakeBulkAttachRubricOut(attached_count=count)
    session.close()
    return result


@router.post("/{intake_id}/applications/bulk-comment", response_model=IntakeBulkCommentOut, operation_id="bulk_add_comment", summary="Bulk add comment to applications", description="Add a comment to the comment thread of multiple applications in an intake")
async def bulk_add_comment(intake_id: int, payload: IntakeBulkCommentRequest):
    session = SessionLocal()
    intake = session.query(Intake).filter(Intake.id == intake_id).first()
    if intake is None:
        session.close()
        raise HTTPException(status_code=404, detail="Intake not found")
    now = datetime.utcnow()
    count = 0
    for app_id in payload.application_ids:
        app = session.query(Application).filter(Application.id == app_id, Application.intake_id == intake_id).first()
        if app is None:
            continue
        thread = session.query(CommentThread).filter(CommentThread.application_id == app_id).first()
        if thread is None:
            thread = CommentThread(application_id=app_id, created_by=1, created_at=now, updated_at=now)
            session.add(thread)
            session.flush()
        session.add(Comment(thread_id=thread.id, author_id=1, body=payload.body, created_at=now, updated_at=now))
        count += 1
    session.commit()
    result = IntakeBulkCommentOut(commented_count=count)
    session.close()
    return result