from datetime import datetime
from typing import Optional
from fastapi import APIRouter, HTTPException, Query
from sqlalchemy.exc import IntegrityError
from database import SessionLocal
from models import Program, Application, User, Rubric, ApplicationRubric, CommentThread, Comment, AuditLog
from schemas import ProgramOut, ProgramCreate, ProgramUpdate, ProgramListOut, ApplicationListOut, ApplicationOut, ProgramBulkAssignRequest, ProgramBulkAssignOut

router = APIRouter(prefix="/api/programs", tags=["Programs"])


@router.get("", response_model=ProgramListOut, operation_id="list_programs", summary="List all programs", description="Retrieve a list of all academic programs, optionally filtered by department or degree type")
async def list_programs(department: Optional[str] = Query(None), degree_type: Optional[str] = Query(None)):
    session = SessionLocal()
    query = session.query(Program)
    if department is not None:
        query = query.filter(Program.department == department)
    if degree_type is not None:
        query = query.filter(Program.degree_type == degree_type)
    programs = query.all()
    result = ProgramListOut(programs=[ProgramOut.model_validate(p, from_attributes=True) for p in programs])
    session.close()
    return result


@router.post("", response_model=ProgramOut, operation_id="create_program", summary="Create a new program", description="Create a new academic program with a unique name, department, and degree type")
async def create_program(payload: ProgramCreate):
    session = SessionLocal()
    program = Program(name=payload.name, department=payload.department, degree_type=payload.degree_type)
    session.add(program)
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Program name already exists or invalid data")
    session.refresh(program)
    result = ProgramOut.model_validate(program, from_attributes=True)
    session.close()
    return result


@router.get("/{program_id}", response_model=ProgramOut, operation_id="get_program", summary="Get a program by ID", description="Retrieve detailed information about a specific program by its unique identifier")
async def get_program(program_id: int):
    session = SessionLocal()
    program = session.query(Program).filter(Program.id == program_id).first()
    if program is None:
        session.close()
        raise HTTPException(status_code=404, detail="Program not found")
    result = ProgramOut.model_validate(program, from_attributes=True)
    session.close()
    return result


@router.put("/{program_id}", response_model=ProgramOut, operation_id="update_program", summary="Update a program", description="Update an existing program's details by its unique identifier")
async def update_program(program_id: int, payload: ProgramUpdate):
    session = SessionLocal()
    program = session.query(Program).filter(Program.id == program_id).first()
    if program is None:
        session.close()
        raise HTTPException(status_code=404, detail="Program not found")
    if payload.name is not None:
        program.name = payload.name
    if payload.department is not None:
        program.department = payload.department
    if payload.degree_type is not None:
        program.degree_type = payload.degree_type
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Program name already exists or invalid data")
    session.refresh(program)
    result = ProgramOut.model_validate(program, from_attributes=True)
    session.close()
    return result


@router.delete("/{program_id}", response_model=dict, operation_id="delete_program", summary="Delete a program", description="Delete a program by its unique identifier. Fails if applications reference it")
async def delete_program(program_id: int):
    session = SessionLocal()
    program = session.query(Program).filter(Program.id == program_id).first()
    if program is None:
        session.close()
        raise HTTPException(status_code=404, detail="Program not found")
    refs = session.query(Application).filter(Application.program_id == program_id).count()
    if refs > 0:
        session.close()
        raise HTTPException(status_code=400, detail="Cannot delete program with existing applications")
    session.delete(program)
    session.commit()
    session.close()
    return {"success": True, "message": "Program deleted successfully"}


@router.get("/{program_id}/applications", response_model=ApplicationListOut, operation_id="list_program_applications", summary="List applications for a program", description="Retrieve all applications associated with a specific program, optionally filtered by intake or status")
async def list_program_applications(program_id: int, intake_id: Optional[int] = Query(None), status: Optional[str] = Query(None)):
    session = SessionLocal()
    program = session.query(Program).filter(Program.id == program_id).first()
    if program is None:
        session.close()
        raise HTTPException(status_code=404, detail="Program not found")
    query = session.query(Application).filter(Application.program_id == program_id)
    if intake_id is not None:
        query = query.filter(Application.intake_id == intake_id)
    if status is not None:
        query = query.filter(Application.status == status)
    apps = query.all()
    result = ApplicationListOut(applications=[ApplicationOut.model_validate(a, from_attributes=True) for a in apps], total=len(apps))
    session.close()
    return result


@router.post("/{program_id}/applications/bulk-assign", response_model=ProgramBulkAssignOut, operation_id="bulk_assign_program_applications", summary="Bulk assign applications to a reviewer", description="Assign all unassigned applications for a program and intake to a reviewer, set deadline, attach rubric, and add comment")
async def bulk_assign_program_applications(program_id: int, payload: ProgramBulkAssignRequest):
    session = SessionLocal()
    program = session.query(Program).filter(Program.id == program_id).first()
    if program is None:
        session.close()
        raise HTTPException(status_code=404, detail="Program not found")
    reviewer = session.query(User).filter(User.id == payload.reviewer_id).first()
    if reviewer is None:
        session.close()
        raise HTTPException(status_code=404, detail="Reviewer not found")
    rubric = session.query(Rubric).filter(Rubric.id == payload.rubric_id).first()
    if rubric is None:
        session.close()
        raise HTTPException(status_code=404, detail="Rubric not found")
    apps = session.query(Application).filter(
        Application.program_id == program_id,
        Application.intake_id == payload.intake_id,
        Application.assigned_reviewer_id.is_(None)
    ).all()
    assigned_ids = []
    now = datetime.utcnow()
    for app in apps:
        app.assigned_reviewer_id = payload.reviewer_id
        app.review_deadline = payload.review_deadline
        app.updated_at = now
        existing = session.query(ApplicationRubric).filter(
            ApplicationRubric.application_id == app.id,
            ApplicationRubric.rubric_id == payload.rubric_id
        ).first()
        if existing is None:
            session.add(ApplicationRubric(application_id=app.id, rubric_id=payload.rubric_id, attached_by=1, attached_at=now))
        thread = session.query(CommentThread).filter(CommentThread.application_id == app.id).first()
        if thread is None:
            thread = CommentThread(application_id=app.id, created_by=1, created_at=now, updated_at=now)
            session.add(thread)
            session.flush()
        session.add(Comment(thread_id=thread.id, author_id=1, body=payload.comment_body, created_at=now, updated_at=now))
        session.add(AuditLog(user_id=1, action="bulk_assign", entity_type="application", entity_id=app.id, details=f"Assigned reviewer {payload.reviewer_id} with rubric {payload.rubric_id}", created_at=now))
        assigned_ids.append(app.id)
    session.commit()
    result = ProgramBulkAssignOut(assigned_count=len(assigned_ids), application_ids=assigned_ids, message=f"{len(assigned_ids)} applications assigned to reviewer {payload.reviewer_id}")
    session.close()
    return result