from datetime import datetime
from typing import Optional
from fastapi import APIRouter, HTTPException, Query
from sqlalchemy.exc import IntegrityError
from database import SessionLocal
from models import Rubric, Application, ApplicationRubric
from schemas import RubricOut, RubricCreate, RubricUpdate, RubricListOut, RubricAttachRequest, RubricAttachOut, ApplicationRubricOut, ApplicationRubricsForAppOut

router = APIRouter(prefix="/api/rubrics", tags=["Rubrics"])


@router.get("", response_model=RubricListOut, operation_id="list_rubrics", summary="List all rubrics", description="Retrieve all rubrics, optionally filtered by name or version")
async def list_rubrics(name: Optional[str] = Query(None), version: Optional[str] = Query(None)):
    session = SessionLocal()
    query = session.query(Rubric)
    if name is not None:
        query = query.filter(Rubric.name == name)
    if version is not None:
        query = query.filter(Rubric.version == version)
    rubrics = query.all()
    result = RubricListOut(rubrics=[RubricOut.model_validate(r, from_attributes=True) for r in rubrics])
    session.close()
    return result


@router.post("", response_model=RubricOut, operation_id="create_rubric", summary="Create a new rubric", description="Create a new rubric record with name, version, and optional description")
async def create_rubric(payload: RubricCreate):
    session = SessionLocal()
    rubric = Rubric(name=payload.name, version=payload.version, description=payload.description)
    session.add(rubric)
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Rubric name already exists or invalid data")
    session.refresh(rubric)
    result = RubricOut.model_validate(rubric, from_attributes=True)
    session.close()
    return result


@router.get("/{id}", response_model=RubricOut, operation_id="get_rubric", summary="Get a rubric by ID", description="Retrieve a single rubric record by its unique identifier")
async def get_rubric(id: int):
    session = SessionLocal()
    rubric = session.query(Rubric).filter(Rubric.id == id).first()
    if rubric is None:
        session.close()
        raise HTTPException(status_code=404, detail="Rubric not found")
    result = RubricOut.model_validate(rubric, from_attributes=True)
    session.close()
    return result


@router.put("/{id}", response_model=RubricOut, operation_id="update_rubric", summary="Update a rubric", description="Update an existing rubric's name, version, or description")
async def update_rubric(id: int, payload: RubricUpdate):
    session = SessionLocal()
    rubric = session.query(Rubric).filter(Rubric.id == id).first()
    if rubric is None:
        session.close()
        raise HTTPException(status_code=404, detail="Rubric not found")
    if payload.name is not None:
        rubric.name = payload.name
    if payload.version is not None:
        rubric.version = payload.version
    if payload.description is not None:
        rubric.description = payload.description
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Rubric name already exists or invalid data")
    session.refresh(rubric)
    result = RubricOut.model_validate(rubric, from_attributes=True)
    session.close()
    return result


@router.delete("/{id}", response_model=dict, operation_id="delete_rubric", summary="Delete a rubric", description="Delete a rubric by ID. Fails if the rubric is attached to any application")
async def delete_rubric(id: int):
    session = SessionLocal()
    rubric = session.query(Rubric).filter(Rubric.id == id).first()
    if rubric is None:
        session.close()
        raise HTTPException(status_code=404, detail="Rubric not found")
    refs = session.query(ApplicationRubric).filter(ApplicationRubric.rubric_id == id).count()
    if refs > 0:
        session.close()
        raise HTTPException(status_code=400, detail="Cannot delete rubric attached to applications")
    session.delete(rubric)
    session.commit()
    session.close()
    return {"deleted": True}


@router.get("/{rubric_id}/applications", response_model=dict, operation_id="list_applications_for_rubric", summary="List applications using a rubric", description="Retrieve all application_rubrics records for a given rubric")
async def list_applications_for_rubric(rubric_id: int):
    session = SessionLocal()
    rubric = session.query(Rubric).filter(Rubric.id == rubric_id).first()
    if rubric is None:
        session.close()
        raise HTTPException(status_code=404, detail="Rubric not found")
    records = session.query(ApplicationRubric).filter(ApplicationRubric.rubric_id == rubric_id).all()
    result = {"rubric_id": rubric_id, "applications": [ApplicationRubricOut.model_validate(r, from_attributes=True).model_dump() for r in records]}
    session.close()
    return result