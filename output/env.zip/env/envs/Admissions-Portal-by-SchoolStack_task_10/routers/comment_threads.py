from datetime import datetime
from typing import Optional
from fastapi import APIRouter, HTTPException, Query
from database import SessionLocal
from models import CommentThread, Comment, Application
from schemas import CommentThreadOut, CommentThreadCreate, CommentThreadListOut, CommentOut, CommentCreate, CommentListOut

router = APIRouter(prefix="/api/comment-threads", tags=["CommentThreads"])


@router.get("", response_model=CommentThreadListOut, operation_id="list_comment_threads", summary="List comment threads, optionally filtered by application", description="Retrieve comment threads with optional application_id filter")
async def list_comment_threads(application_id: Optional[int] = Query(None), limit: int = Query(50), offset: int = Query(0)):
    session = SessionLocal()
    query = session.query(CommentThread)
    if application_id is not None:
        query = query.filter(CommentThread.application_id == application_id)
    total = query.count()
    threads = query.offset(offset).limit(limit).all()
    result = CommentThreadListOut(threads=[CommentThreadOut.model_validate(t, from_attributes=True) for t in threads], total=total)
    session.close()
    return result


@router.post("", response_model=CommentThreadOut, operation_id="create_comment_thread", summary="Create a comment thread for an application", description="Create a new comment thread on an application using current user")
async def create_comment_thread(payload: CommentThreadCreate):
    session = SessionLocal()
    app = session.query(Application).filter(Application.id == payload.application_id).first()
    if app is None:
        session.close()
        raise HTTPException(status_code=404, detail="Application not found")
    now = datetime.utcnow()
    thread = CommentThread(application_id=payload.application_id, created_by=payload.created_by if payload.created_by is not None else 1, created_at=now, updated_at=now)
    session.add(thread)
    session.commit()
    session.refresh(thread)
    result = CommentThreadOut.model_validate(thread, from_attributes=True)
    session.close()
    return result


@router.get("/{thread_id}", response_model=CommentThreadOut, operation_id="get_comment_thread", summary="Get a comment thread by id", description="Retrieve a single comment thread by its id")
async def get_comment_thread(thread_id: int):
    session = SessionLocal()
    thread = session.query(CommentThread).filter(CommentThread.id == thread_id).first()
    if thread is None:
        session.close()
        raise HTTPException(status_code=404, detail="Comment thread not found")
    result = CommentThreadOut.model_validate(thread, from_attributes=True)
    session.close()
    return result


@router.delete("/{thread_id}", response_model=dict, operation_id="delete_comment_thread", summary="Delete a comment thread", description="Delete a comment thread and its comments by thread id")
async def delete_comment_thread(thread_id: int):
    session = SessionLocal()
    thread = session.query(CommentThread).filter(CommentThread.id == thread_id).first()
    if thread is None:
        session.close()
        raise HTTPException(status_code=404, detail="Comment thread not found")
    session.query(Comment).filter(Comment.thread_id == thread_id).delete()
    session.delete(thread)
    session.commit()
    session.close()
    return {"deleted": True}


@router.get("/{thread_id}/comments", response_model=CommentListOut, operation_id="list_comments", summary="List comments in a thread", description="Retrieve comments for a given comment thread")
async def list_comments(thread_id: int, limit: int = Query(50), offset: int = Query(0)):
    session = SessionLocal()
    thread = session.query(CommentThread).filter(CommentThread.id == thread_id).first()
    if thread is None:
        session.close()
        raise HTTPException(status_code=404, detail="Comment thread not found")
    query = session.query(Comment).filter(Comment.thread_id == thread_id)
    total = query.count()
    comments = query.offset(offset).limit(limit).all()
    result = CommentListOut(comments=[CommentOut.model_validate(c, from_attributes=True) for c in comments], total=total)
    session.close()
    return result


@router.post("/{thread_id}/comments", response_model=CommentOut, operation_id="create_comment", summary="Add a comment to a thread", description="Create a new comment in the specified thread using current user")
async def create_comment(thread_id: int, payload: CommentCreate):
    session = SessionLocal()
    thread = session.query(CommentThread).filter(CommentThread.id == thread_id).first()
    if thread is None:
        session.close()
        raise HTTPException(status_code=404, detail="Comment thread not found")
    now = datetime.utcnow()
    comment = Comment(thread_id=thread_id, author_id=payload.author_id if payload.author_id is not None else 1, body=payload.body, created_at=now, updated_at=now)
    session.add(comment)
    thread.updated_at = now
    session.commit()
    session.refresh(comment)
    result = CommentOut.model_validate(comment, from_attributes=True)
    session.close()
    return result