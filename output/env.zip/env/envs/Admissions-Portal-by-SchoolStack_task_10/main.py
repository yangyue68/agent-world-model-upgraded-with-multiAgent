import os
import uvicorn
from fastapi import FastAPI
from database import Base, engine
import models
from routers import users, programs, intakes, applications, rubrics, application_rubrics, comment_threads, comments, audit_log

Base.metadata.create_all(bind=engine)

app = FastAPI(title="Admissions Portal by SchoolStack", version="1.0.0")

app.include_router(users.router)
app.include_router(programs.router)
app.include_router(intakes.router)
app.include_router(applications.router)
app.include_router(rubrics.router)
app.include_router(application_rubrics.router)
app.include_router(comment_threads.router)
app.include_router(comments.router)
app.include_router(audit_log.router)


@app.get("/health", operation_id="health_check", summary="Health check", description="Return service health status", tags=["Health"])
async def health_check():
    return {"status": "ok"}


if __name__ == "__main__":
    host = os.getenv("HOST", "127.0.0.1")
    port = int(os.getenv("PORT", "8000"))
    uvicorn.run(app, host=host, port=port)