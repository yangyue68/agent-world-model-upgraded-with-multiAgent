from datetime import date, datetime
from typing import List, Optional
from pydantic import BaseModel, ConfigDict, Field

class UserOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    full_name: str
    email: str
    role: str
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class UserCreate(BaseModel):
    full_name: str
    email: str
    role: str

class UserUpdate(BaseModel):
    full_name: Optional[str] = None
    email: Optional[str] = None
    role: Optional[str] = None

class UserListOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    users: List[UserOut]
    total: int

class ProgramOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    name: str
    department: Optional[str] = None
    degree_type: Optional[str] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class ProgramCreate(BaseModel):
    name: str
    department: Optional[str] = None
    degree_type: Optional[str] = None

class ProgramUpdate(BaseModel):
    name: Optional[str] = None
    department: Optional[str] = None
    degree_type: Optional[str] = None

class ProgramListOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    programs: List[ProgramOut]

class IntakeOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    term: str
    year: int
    level: str
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class IntakeCreate(BaseModel):
    term: str
    year: int
    level: str

class IntakeUpdate(BaseModel):
    term: Optional[str] = None
    year: Optional[int] = None
    level: Optional[str] = None

class IntakeListOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    intakes: List[IntakeOut]

class ApplicationOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    applicant_name: str
    applicant_email: str
    program_id: int
    intake_id: int
    status: str
    assigned_reviewer_id: Optional[int] = None
    review_deadline: Optional[date] = None
    financial_aid_documents_complete: int
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class ApplicationListOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    applications: List[ApplicationOut]
    total: int

class ApplicationPatch(BaseModel):
    status: Optional[str] = None
    assigned_reviewer_id: Optional[int] = None
    review_deadline: Optional[date] = None
    financial_aid_documents_complete: Optional[int] = None

class BulkAssignRequest(BaseModel):
    application_ids: List[int]
    assigned_reviewer_id: int

class BulkAssignOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    updated_count: int
    application_ids: List[int]

class BulkDeadlineRequest(BaseModel):
    application_ids: List[int]
    review_deadline: date

class BulkDeadlineOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    updated_count: int
    application_ids: List[int]

class BulkAttachRubricRequest(BaseModel):
    application_ids: List[int]
    rubric_id: int

class BulkAttachRubricOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    attached_count: int
    application_ids: List[int]

class BulkCommentRequest(BaseModel):
    application_ids: List[int]
    body: str

class BulkCommentOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    created_count: int
    comment_ids: List[int]

class ProgramBulkAssignRequest(BaseModel):
    intake_id: int
    reviewer_id: int
    review_deadline: date
    rubric_id: int
    comment_body: str

class ProgramBulkAssignOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    assigned_count: int
    application_ids: List[int]
    message: str

class IntakeBulkAssignRequest(BaseModel):
    application_ids: List[int]
    assigned_reviewer_id: int
    review_deadline: Optional[date] = None

class IntakeBulkAssignOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    updated_count: int
    applications: List[ApplicationOut]

class IntakeBulkAttachRubricRequest(BaseModel):
    application_ids: List[int]
    rubric_id: int

class IntakeBulkAttachRubricOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    attached_count: int

class IntakeBulkCommentRequest(BaseModel):
    application_ids: List[int]
    body: str

class IntakeBulkCommentOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    commented_count: int

class RubricOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    name: str
    version: str
    description: Optional[str] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class RubricCreate(BaseModel):
    name: str
    version: str
    description: Optional[str] = None

class RubricUpdate(BaseModel):
    name: Optional[str] = None
    version: Optional[str] = None
    description: Optional[str] = None

class RubricListOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    rubrics: List[RubricOut]

class ApplicationRubricOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    application_id: int
    rubric_id: int
    attached_by: int
    attached_at: Optional[datetime] = None

class ApplicationRubricCreate(BaseModel):
    application_id: int
    rubric_id: int

class ApplicationRubricListOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    application_rubrics: List[ApplicationRubricOut]
    total: int

class ApplicationRubricBulkRequest(BaseModel):
    application_ids: List[int]
    rubric_id: int

class ApplicationRubricBulkOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    attached_count: int
    skipped_count: int
    application_rubrics: List[ApplicationRubricOut]

class RubricAttachRequest(BaseModel):
    rubric_id: int

class RubricAttachOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    application_id: int
    rubric_id: int
    attached_by: int
    attached_at: Optional[datetime] = None

class ApplicationRubricsForAppOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    application_id: int
    rubrics: List[ApplicationRubricOut]

class ApplicationRubricsForRubricOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    rubric_id: int
    applications: List[ApplicationRubricOut]

class CommentThreadOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    application_id: int
    created_by: int
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class CommentThreadCreate(BaseModel):
    application_id: int
    created_by: Optional[int] = None

class CommentThreadListOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    threads: List[CommentThreadOut]
    total: int

class CommentOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    thread_id: int
    author_id: int
    body: str
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class CommentCreate(BaseModel):
    body: str
    author_id: Optional[int] = None

class CommentUpdate(BaseModel):
    body: str

class CommentListOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    comments: List[CommentOut]
    total: int

class CommentThreadsForAppOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    threads: List[CommentThreadOut]

class CommentsForThreadOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    comments: List[CommentOut]

class AuditLogOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    user_id: int
    action: str
    entity_type: str
    entity_id: Optional[int] = None
    details: Optional[str] = None
    created_at: Optional[datetime] = None

class AuditLogCreate(BaseModel):
    action: str
    entity_type: str
    entity_id: Optional[int] = None
    details: Optional[str] = None

class AuditLogListOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    entries: List[AuditLogOut]
    total: int

class DeleteOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    success: bool
    message: str

class DeletedOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    deleted: bool
    id: int