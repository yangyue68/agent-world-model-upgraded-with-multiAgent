from datetime import date, datetime
from typing import Optional, List
from pydantic import BaseModel, ConfigDict, Field

class UserOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    username: str
    full_name: Optional[str] = None
    email: Optional[str] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class UserCreate(BaseModel):
    username: str
    full_name: Optional[str] = None
    email: Optional[str] = None

class UserUpdate(BaseModel):
    username: str
    full_name: Optional[str] = None
    email: Optional[str] = None

class UserListOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    users: List[UserOut]

class ProgramOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    name: str
    degree_type: str
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class ProgramCreate(BaseModel):
    name: str
    degree_type: str

class ProgramUpdate(BaseModel):
    name: Optional[str] = None
    degree_type: Optional[str] = None

class ProgramListOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    programs: List[ProgramOut]

class TermOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    name: str
    start_date: Optional[date] = None
    end_date: Optional[date] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class TermCreate(BaseModel):
    name: str
    start_date: Optional[date] = None
    end_date: Optional[date] = None

class TermUpdate(BaseModel):
    name: Optional[str] = None
    start_date: Optional[date] = None
    end_date: Optional[date] = None

class TermListOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    terms: List[TermOut]

class ProgramTermOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    program_id: int
    term_id: int
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class ProgramTermCreate(BaseModel):
    program_id: int
    term_id: int

class ProgramTermUpdate(BaseModel):
    program_id: int
    term_id: int

class ProgramTermListOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    program_terms: List[ProgramTermOut]

class ProgramTermDeleteOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    deleted: bool

class ReviewCommitteeOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    name: str
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class ReviewCommitteeCreate(BaseModel):
    name: str

class ReviewCommitteeUpdate(BaseModel):
    name: str

class ReviewCommitteeListOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    review_committees: List[ReviewCommitteeOut]

class ReviewStageOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    committee_id: int
    name: str
    stage_order: int
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class ReviewStageCreate(BaseModel):
    committee_id: int
    name: str
    stage_order: int

class ReviewStageUpdate(BaseModel):
    committee_id: Optional[int] = None
    name: Optional[str] = None
    stage_order: Optional[int] = None

class ReviewStageListOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    review_stages: List[ReviewStageOut]

class ReviewStageDeleteOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    deleted: bool
    id: int

class ApplicantOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    first_name: str
    last_name: str
    email: Optional[str] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class ApplicantCreate(BaseModel):
    first_name: str
    last_name: str
    email: Optional[str] = None

class ApplicantUpdate(BaseModel):
    first_name: str
    last_name: str
    email: Optional[str] = None

class ApplicantListOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    applicants: List[ApplicantOut]
    total: int

class ApplicantDeleteOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    deleted: bool

class ApplicationOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    applicant_id: int
    program_term_id: int
    submitted_at: Optional[datetime] = None
    final_decision: Optional[str] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class ApplicationCreate(BaseModel):
    applicant_id: int
    program_term_id: int
    submitted_at: Optional[datetime] = None
    final_decision: Optional[str] = None

class ApplicationUpdate(BaseModel):
    final_decision: Optional[str] = None
    submitted_at: Optional[datetime] = None

class ApplicationListOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    applications: List[ApplicationOut]
    total: int

class ApplicationDeleteOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    deleted: bool

class ReviewAssignmentOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    application_id: int
    reviewer_id: int
    stage_id: int
    assigned_at: Optional[datetime] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class ReviewAssignmentCreate(BaseModel):
    application_id: int
    reviewer_id: int
    stage_id: int

class ReviewAssignmentUpdate(BaseModel):
    application_id: Optional[int] = None
    reviewer_id: Optional[int] = None
    stage_id: Optional[int] = None

class ReviewAssignmentListOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    review_assignments: List[ReviewAssignmentOut]

class ReviewAssignmentDeleteOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    deleted: bool

class WorkloadEntryOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    reviewer_id: int
    reviewer_name: Optional[str] = None
    stage_id: int
    stage_name: Optional[str] = None
    assigned_count: int
    admit_count: int
    waitlist_count: int
    deny_count: int
    admit_percentage: float
    waitlist_percentage: float
    deny_percentage: float

class WorkloadListOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    workload: List[WorkloadEntryOut]

class StageReviewerWorkloadEntryOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    reviewer_id: int
    reviewer_name: Optional[str] = None
    assigned_count: int
    admit_count: int
    waitlist_count: int
    deny_count: int
    decided_count: int
    admit_percentage: float
    waitlist_percentage: float
    deny_percentage: float
    decided_percentage: float

class StageReviewerWorkloadOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    stage_id: int
    stage_name: Optional[str] = None
    reviewers: List[StageReviewerWorkloadEntryOut]