import os
import uvicorn
from fastapi import FastAPI
from database import Base, engine
import models
from routers import programs, terms, program_terms, review_committees, review_stages, applicants, applications, review_assignments, users

Base.metadata.create_all(engine)

app = FastAPI(title="Admissions Portal by SchoolStack", version="1.0.0")

app.include_router(programs.router)
app.include_router(terms.router)
app.include_router(program_terms.router)
app.include_router(review_committees.router)
app.include_router(review_stages.router)
app.include_router(applicants.router)
app.include_router(applications.router)
app.include_router(review_assignments.router)
app.include_router(users.router)


@app.get("/", summary="Root endpoint", description="Returns a welcome message for the Admissions Portal API.", operation_id="root")
async def root():
    return {"message": "Admissions Portal by SchoolStack API"}


if __name__ == "__main__":
    host = os.getenv("HOST", "127.0.0.1")
    port = int(os.getenv("PORT", "8000"))
    uvicorn.run(app, host=host, port=port)