from fastapi import APIRouter, HTTPException, Query
from typing import Optional
from database import SessionLocal
from models import Program, ProgramTerm, Term
from schemas import (
    ProgramOut, ProgramCreate, ProgramUpdate, ProgramListOut,
    TermOut, TermListOut, ProgramTermOut, ProgramTermCreate,
)

router = APIRouter(prefix="/api/programs", tags=["Programs"])


@router.get("", response_model=ProgramListOut, summary="List all programs", description="Retrieve a list of all academic programs with optional filtering by name and degree type.", operation_id="list_programs")
async def list_programs(name: Optional[str] = Query(None), degree_type: Optional[str] = Query(None)):
    session = SessionLocal()
    query = session.query(Program)
    if name:
        query = query.filter(Program.name.like(f"%{name}%"))
    if degree_type:
        query = query.filter(Program.degree_type == degree_type)
    programs = query.all()
    result = ProgramListOut(programs=[ProgramOut.model_validate(p, from_attributes=True) for p in programs])
    session.close()
    return result


@router.post("", response_model=ProgramOut, summary="Create a new program", description="Create a new academic program with the provided name and degree type.", operation_id="create_program")
async def create_program(payload: ProgramCreate):
    session = SessionLocal()
    program = Program(name=payload.name, degree_type=payload.degree_type)
    session.add(program)
    session.commit()
    session.refresh(program)
    result = ProgramOut.model_validate(program, from_attributes=True)
    session.close()
    return result


@router.get("/{program_id}", response_model=ProgramOut, summary="Get a program by ID", description="Retrieve detailed information for a single program identified by its ID.", operation_id="get_program")
async def get_program(program_id: int):
    session = SessionLocal()
    program = session.query(Program).filter(Program.id == program_id).first()
    if not program:
        session.close()
        raise HTTPException(status_code=404, detail="Program not found")
    result = ProgramOut.model_validate(program, from_attributes=True)
    session.close()
    return result


@router.put("/{program_id}", response_model=ProgramOut, summary="Update a program", description="Update the name and/or degree type of an existing program.", operation_id="update_program")
async def update_program(program_id: int, payload: ProgramUpdate):
    session = SessionLocal()
    program = session.query(Program).filter(Program.id == program_id).first()
    if not program:
        session.close()
        raise HTTPException(status_code=404, detail="Program not found")
    if payload.name is not None:
        program.name = payload.name
    if payload.degree_type is not None:
        program.degree_type = payload.degree_type
    session.commit()
    session.refresh(program)
    result = ProgramOut.model_validate(program, from_attributes=True)
    session.close()
    return result


@router.delete("/{program_id}", summary="Delete a program", description="Delete a program and all associated program-term links by its ID.", operation_id="delete_program")
async def delete_program(program_id: int):
    session = SessionLocal()
    program = session.query(Program).filter(Program.id == program_id).first()
    if not program:
        session.close()
        raise HTTPException(status_code=404, detail="Program not found")
    session.query(ProgramTerm).filter(ProgramTerm.program_id == program_id).delete()
    session.delete(program)
    session.commit()
    session.close()
    return {"message": "Program deleted successfully"}


@router.get("/{program_id}/terms", response_model=TermListOut, summary="List terms for a program", description="Retrieve all terms associated with a specific program via program_terms.", operation_id="list_program_terms")
async def list_program_terms(program_id: int):
    session = SessionLocal()
    program = session.query(Program).filter(Program.id == program_id).first()
    if not program:
        session.close()
        raise HTTPException(status_code=404, detail="Program not found")
    terms = session.query(Term).join(ProgramTerm, ProgramTerm.term_id == Term.id).filter(ProgramTerm.program_id == program_id).all()
    result = TermListOut(terms=[TermOut.model_validate(t, from_attributes=True) for t in terms])
    session.close()
    return result


@router.post("/{program_id}/terms", response_model=ProgramTermOut, summary="Associate a term with a program", description="Create a program_terms link between a program and a term.", operation_id="create_program_term")
async def create_program_term(program_id: int, payload: ProgramTermCreate):
    session = SessionLocal()
    program = session.query(Program).filter(Program.id == program_id).first()
    if not program:
        session.close()
        raise HTTPException(status_code=404, detail="Program not found")
    term = session.query(Term).filter(Term.id == payload.term_id).first()
    if not term:
        session.close()
        raise HTTPException(status_code=404, detail="Term not found")
    existing = session.query(ProgramTerm).filter(ProgramTerm.program_id == program_id, ProgramTerm.term_id == payload.term_id).first()
    if existing:
        session.close()
        raise HTTPException(status_code=400, detail="Program-term association already exists")
    pt = ProgramTerm(program_id=program_id, term_id=payload.term_id)
    session.add(pt)
    session.commit()
    session.refresh(pt)
    result = ProgramTermOut.model_validate(pt, from_attributes=True)
    session.close()
    return result


@router.delete("/{program_id}/terms/{term_id}", summary="Remove a term from a program", description="Delete the program_terms link between a program and a term.", operation_id="delete_program_term")
async def delete_program_term(program_id: int, term_id: int):
    session = SessionLocal()
    pt = session.query(ProgramTerm).filter(ProgramTerm.program_id == program_id, ProgramTerm.term_id == term_id).first()
    if not pt:
        session.close()
        raise HTTPException(status_code=404, detail="Program-term association not found")
    session.delete(pt)
    session.commit()
    session.close()
    return {"message": "Program-term association removed successfully"}