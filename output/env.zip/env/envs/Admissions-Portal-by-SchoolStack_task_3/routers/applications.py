from fastapi import APIRouter, HTTPException, Query
from typing import Optional
from database import SessionLocal
from models import Application, Applicant, ProgramTerm, ReviewAssignment, ReviewStage, User
from schemas import (
    ApplicationOut, ApplicationCreate, ApplicationUpdate, ApplicationListOut, ApplicationDeleteOut,
    ReviewAssignmentOut, ReviewAssignmentCreate, ReviewAssignmentListOut, ReviewAssignmentDeleteOut,
    WorkloadEntryOut, WorkloadListOut,
)

router = APIRouter(prefix="/api/applications", tags=["Applications"])


@router.get("", response_model=ApplicationListOut, summary="List applications with optional filters", description="Retrieve applications filtered by program term, decision, or applicant.", operation_id="list_applications")
async def list_applications(program_term_id: Optional[int] = Query(None), final_decision: Optional[str] = Query(None), applicant_id: Optional[int] = Query(None), limit: int = Query(50), offset: int = Query(0)):
    session = SessionLocal()
    query = session.query(Application)
    if program_term_id is not None:
        query = query.filter(Application.program_term_id == program_term_id)
    if final_decision:
        query = query.filter(Application.final_decision == final_decision)
    if applicant_id is not None:
        query = query.filter(Application.applicant_id == applicant_id)
    total = query.count()
    applications = query.offset(offset).limit(limit).all()
    result = ApplicationListOut(applications=[ApplicationOut.model_validate(a, from_attributes=True) for a in applications], total=total)
    session.close()
    return result


@router.post("", response_model=ApplicationOut, summary="Create a new application", description="Create an application linking an applicant to a program term.", operation_id="create_application")
async def create_application(payload: ApplicationCreate):
    session = SessionLocal()
    applicant = session.query(Applicant).filter(Applicant.id == payload.applicant_id).first()
    if not applicant:
        session.close()
        raise HTTPException(status_code=404, detail="Applicant not found")
    pt = session.query(ProgramTerm).filter(ProgramTerm.id == payload.program_term_id).first()
    if not pt:
        session.close()
        raise HTTPException(status_code=404, detail="Program term not found")
    if payload.final_decision is not None and payload.final_decision not in ("admit", "waitlist", "deny"):
        session.close()
        raise HTTPException(status_code=400, detail="final_decision must be one of admit, waitlist, deny")
    application = Application(applicant_id=payload.applicant_id, program_term_id=payload.program_term_id, submitted_at=payload.submitted_at, final_decision=payload.final_decision)
    session.add(application)
    session.commit()
    session.refresh(application)
    result = ApplicationOut.model_validate(application, from_attributes=True)
    session.close()
    return result


@router.get("/{id}", response_model=ApplicationOut, summary="Get a single application by ID", description="Retrieve detailed information for one application.", operation_id="get_application")
async def get_application(id: int):
    session = SessionLocal()
    application = session.query(Application).filter(Application.id == id).first()
    if not application:
        session.close()
        raise HTTPException(status_code=404, detail="Application not found")
    result = ApplicationOut.model_validate(application, from_attributes=True)
    session.close()
    return result


@router.patch("/{id}", response_model=ApplicationOut, summary="Update an application's decision or submission", description="Partially update an application's final_decision or submitted_at.", operation_id="update_application")
async def update_application(id: int, payload: ApplicationUpdate):
    session = SessionLocal()
    application = session.query(Application).filter(Application.id == id).first()
    if not application:
        session.close()
        raise HTTPException(status_code=404, detail="Application not found")
    if payload.final_decision is not None:
        if payload.final_decision not in ("admit", "waitlist", "deny"):
            session.close()
            raise HTTPException(status_code=400, detail="final_decision must be one of admit, waitlist, deny")
        application.final_decision = payload.final_decision
    if payload.submitted_at is not None:
        application.submitted_at = payload.submitted_at
    session.commit()
    session.refresh(application)
    result = ApplicationOut.model_validate(application, from_attributes=True)
    session.close()
    return result


@router.delete("/{id}", response_model=ApplicationDeleteOut, summary="Delete an application", description="Delete an application and its related review assignments.", operation_id="delete_application")
async def delete_application(id: int):
    session = SessionLocal()
    application = session.query(Application).filter(Application.id == id).first()
    if not application:
        session.close()
        raise HTTPException(status_code=404, detail="Application not found")
    session.query(ReviewAssignment).filter(ReviewAssignment.application_id == id).delete(synchronize_session=False)
    session.delete(application)
    session.commit()
    session.close()
    return ApplicationDeleteOut(deleted=True)


@router.get("/{id}/review_assignments", response_model=ReviewAssignmentListOut, summary="List review assignments for an application", description="Retrieve all review assignments for a given application.", operation_id="list_application_review_assignments")
async def list_application_review_assignments(id: int):
    session = SessionLocal()
    application = session.query(Application).filter(Application.id == id).first()
    if not application:
        session.close()
        raise HTTPException(status_code=404, detail="Application not found")
    assignments = session.query(ReviewAssignment).filter(ReviewAssignment.application_id == id).all()
    result = ReviewAssignmentListOut(review_assignments=[ReviewAssignmentOut.model_validate(a, from_attributes=True) for a in assignments])
    session.close()
    return result


@router.post("/{id}/review_assignments", response_model=ReviewAssignmentOut, summary="Assign a reviewer to an application stage", description="Create a review assignment for an application, reviewer, and stage.", operation_id="create_application_review_assignment")
async def create_application_review_assignment(id: int, payload: ReviewAssignmentCreate):
    session = SessionLocal()
    application = session.query(Application).filter(Application.id == id).first()
    if not application:
        session.close()
        raise HTTPException(status_code=404, detail="Application not found")
    reviewer = session.query(User).filter(User.id == payload.reviewer_id).first()
    if not reviewer:
        session.close()
        raise HTTPException(status_code=404, detail="Reviewer not found")
    stage = session.query(ReviewStage).filter(ReviewStage.id == payload.stage_id).first()
    if not stage:
        session.close()
        raise HTTPException(status_code=404, detail="Review stage not found")
    existing = session.query(ReviewAssignment).filter(ReviewAssignment.application_id == id, ReviewAssignment.reviewer_id == payload.reviewer_id, ReviewAssignment.stage_id == payload.stage_id).first()
    if existing:
        session.close()
        raise HTTPException(status_code=400, detail="Review assignment already exists")
    assignment = ReviewAssignment(application_id=id, reviewer_id=payload.reviewer_id, stage_id=payload.stage_id)
    session.add(assignment)
    session.commit()
    session.refresh(assignment)
    result = ReviewAssignmentOut.model_validate(assignment, from_attributes=True)
    session.close()
    return result


@router.get("/reviewer_workload", response_model=WorkloadListOut, summary="Get reviewer workload grouped by stage", description="Count applications per reviewer and decision percentages by stage for a program term.", operation_id="get_application_reviewer_workload")
async def get_application_reviewer_workload(program_term_id: int = Query(...)):
    session = SessionLocal()
    pt = session.query(ProgramTerm).filter(ProgramTerm.id == program_term_id).first()
    if not pt:
        session.close()
        raise HTTPException(status_code=404, detail="Program term not found")
    assignments = session.query(ReviewAssignment).join(Application, Application.id == ReviewAssignment.application_id).filter(Application.program_term_id == program_term_id).all()
    stage_ids = list({a.stage_id for a in assignments})
    stages = session.query(ReviewStage).filter(ReviewStage.id.in_(stage_ids)).all() if stage_ids else []
    stage_map = {s.id: s for s in stages}
    reviewer_ids = list({a.reviewer_id for a in assignments})
    users = session.query(User).filter(User.id.in_(reviewer_ids)).all() if reviewer_ids else []
    user_map = {u.id: u for u in users}
    app_ids = list({a.application_id for a in assignments})
    apps = session.query(Application).filter(Application.id.in_(app_ids)).all() if app_ids else []
    app_map = {a.id: a for a in apps}
    buckets = {}
    for a in assignments:
        key = (a.reviewer_id, a.stage_id)
        if key not in buckets:
            buckets[key] = {"assigned": 0, "admit": 0, "waitlist": 0, "deny": 0}
        buckets[key]["assigned"] += 1
        app = app_map.get(a.application_id)
        if app and app.final_decision in ("admit", "waitlist", "deny"):
            buckets[key][app.final_decision] += 1
    entries = []
    for (reviewer_id, stage_id), counts in buckets.items():
        assigned = counts["assigned"]
        admit = counts["admit"]
        waitlist = counts["waitlist"]
        deny = counts["deny"]
        user = user_map.get(reviewer_id)
        stage = stage_map.get(stage_id)
        entries.append(WorkloadEntryOut(
            reviewer_id=reviewer_id,
            reviewer_name=user.full_name if user else None,
            stage_id=stage_id,
            stage_name=stage.name if stage else None,
            assigned_count=assigned,
            admit_count=admit,
            waitlist_count=waitlist,
            deny_count=deny,
            admit_percentage=round(admit / assigned * 100, 2) if assigned else 0.0,
            waitlist_percentage=round(waitlist / assigned * 100, 2) if assigned else 0.0,
            deny_percentage=round(deny / assigned * 100, 2) if assigned else 0.0,
        ))
    entries.sort(key=lambda e: (e.stage_id, e.reviewer_id))
    result = WorkloadListOut(workload=entries)
    session.close()
    return result