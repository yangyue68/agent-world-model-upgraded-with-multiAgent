from fastapi import APIRouter, HTTPException, Query
from typing import Optional
from database import SessionLocal
from models import ReviewAssignment, Application, ProgramTerm, ReviewStage, User
from schemas import (
    ReviewAssignmentOut, ReviewAssignmentCreate, ReviewAssignmentUpdate, ReviewAssignmentListOut, ReviewAssignmentDeleteOut,
    WorkloadEntryOut, WorkloadListOut,
)

router = APIRouter(prefix="/api/review_assignments", tags=["ReviewAssignments"])


@router.get("", response_model=ReviewAssignmentListOut, summary="List review assignments with optional filters", description="Retrieve review assignments, optionally filtered by application, reviewer, or stage.", operation_id="list_review_assignments")
async def list_review_assignments(application_id: Optional[int] = Query(None), reviewer_id: Optional[int] = Query(None), stage_id: Optional[int] = Query(None)):
    session = SessionLocal()
    query = session.query(ReviewAssignment)
    if application_id is not None:
        query = query.filter(ReviewAssignment.application_id == application_id)
    if reviewer_id is not None:
        query = query.filter(ReviewAssignment.reviewer_id == reviewer_id)
    if stage_id is not None:
        query = query.filter(ReviewAssignment.stage_id == stage_id)
    assignments = query.all()
    result = ReviewAssignmentListOut(review_assignments=[ReviewAssignmentOut.model_validate(a, from_attributes=True) for a in assignments])
    session.close()
    return result


@router.post("", response_model=ReviewAssignmentOut, summary="Create a new review assignment", description="Assign a reviewer to an application at a specific review stage.", operation_id="create_review_assignment")
async def create_review_assignment(payload: ReviewAssignmentCreate):
    session = SessionLocal()
    application = session.query(Application).filter(Application.id == payload.application_id).first()
    if not application:
        session.close()
        raise HTTPException(status_code=404, detail="Application not found")
    reviewer = session.query(User).filter(User.id == payload.reviewer_id).first()
    if not reviewer:
        session.close()
        raise HTTPException(status_code=404, detail="Reviewer not found")
    stage = session.query(ReviewStage).filter(ReviewStage.id == payload.stage_id).first()
    if not stage:
        session.close()
        raise HTTPException(status_code=404, detail="Review stage not found")
    existing = session.query(ReviewAssignment).filter(ReviewAssignment.application_id == payload.application_id, ReviewAssignment.reviewer_id == payload.reviewer_id, ReviewAssignment.stage_id == payload.stage_id).first()
    if existing:
        session.close()
        raise HTTPException(status_code=400, detail="Review assignment already exists")
    assignment = ReviewAssignment(application_id=payload.application_id, reviewer_id=payload.reviewer_id, stage_id=payload.stage_id)
    session.add(assignment)
    session.commit()
    session.refresh(assignment)
    result = ReviewAssignmentOut.model_validate(assignment, from_attributes=True)
    session.close()
    return result


@router.get("/workload", response_model=WorkloadListOut, summary="Get reviewer workload grouped by stage", description="Count assignments per reviewer and decision percentages for a program and term.", operation_id="get_review_assignment_workload")
async def get_review_assignment_workload(program_id: int = Query(...), term_id: int = Query(...)):
    session = SessionLocal()
    assignments = session.query(ReviewAssignment).join(Application, Application.id == ReviewAssignment.application_id).join(ProgramTerm, ProgramTerm.id == Application.program_term_id).filter(ProgramTerm.program_id == program_id, ProgramTerm.term_id == term_id).all()
    stage_ids = list({a.stage_id for a in assignments})
    stages = session.query(ReviewStage).filter(ReviewStage.id.in_(stage_ids)).all() if stage_ids else []
    stage_map = {s.id: s for s in stages}
    reviewer_ids = list({a.reviewer_id for a in assignments})
    users = session.query(User).filter(User.id.in_(reviewer_ids)).all() if reviewer_ids else []
    user_map = {u.id: u for u in users}
    app_ids = list({a.application_id for a in assignments})
    apps = session.query(Application).filter(Application.id.in_(app_ids)).all() if app_ids else []
    app_map = {a.id: a for a in apps}
    buckets = {}
    for a in assignments:
        key = (a.reviewer_id, a.stage_id)
        if key not in buckets:
            buckets[key] = {"assigned": 0, "admit": 0, "waitlist": 0, "deny": 0}
        buckets[key]["assigned"] += 1
        app = app_map.get(a.application_id)
        if app and app.final_decision in ("admit", "waitlist", "deny"):
            buckets[key][app.final_decision] += 1
    entries = []
    for (reviewer_id, stage_id), counts in buckets.items():
        assigned = counts["assigned"]
        admit = counts["admit"]
        waitlist = counts["waitlist"]
        deny = counts["deny"]
        user = user_map.get(reviewer_id)
        stage = stage_map.get(stage_id)
        entries.append(WorkloadEntryOut(
            reviewer_id=reviewer_id,
            reviewer_name=user.full_name if user else None,
            stage_id=stage_id,
            stage_name=stage.name if stage else None,
            assigned_count=assigned,
            admit_count=admit,
            waitlist_count=waitlist,
            deny_count=deny,
            admit_percentage=round(admit / assigned * 100, 2) if assigned else 0.0,
            waitlist_percentage=round(waitlist / assigned * 100, 2) if assigned else 0.0,
            deny_percentage=round(deny / assigned * 100, 2) if assigned else 0.0,
        ))
    entries.sort(key=lambda e: (e.stage_id, e.reviewer_id))
    result = WorkloadListOut(workload=entries)
    session.close()
    return result


@router.get("/{id}", response_model=ReviewAssignmentOut, summary="Get a single review assignment by ID", description="Retrieve details of a specific review assignment.", operation_id="get_review_assignment")
async def get_review_assignment(id: int):
    session = SessionLocal()
    assignment = session.query(ReviewAssignment).filter(ReviewAssignment.id == id).first()
    if not assignment:
        session.close()
        raise HTTPException(status_code=404, detail="Review assignment not found")
    result = ReviewAssignmentOut.model_validate(assignment, from_attributes=True)
    session.close()
    return result


@router.put("/{id}", response_model=ReviewAssignmentOut, summary="Replace a review assignment", description="Update all fields of an existing review assignment.", operation_id="replace_review_assignment")
async def replace_review_assignment(id: int, payload: ReviewAssignmentCreate):
    session = SessionLocal()
    assignment = session.query(ReviewAssignment).filter(ReviewAssignment.id == id).first()
    if not assignment:
        session.close()
        raise HTTPException(status_code=404, detail="Review assignment not found")
    application = session.query(Application).filter(Application.id == payload.application_id).first()
    if not application:
        session.close()
        raise HTTPException(status_code=404, detail="Application not found")
    reviewer = session.query(User).filter(User.id == payload.reviewer_id).first()
    if not reviewer:
        session.close()
        raise HTTPException(status_code=404, detail="Reviewer not found")
    stage = session.query(ReviewStage).filter(ReviewStage.id == payload.stage_id).first()
    if not stage:
        session.close()
        raise HTTPException(status_code=404, detail="Review stage not found")
    duplicate = session.query(ReviewAssignment).filter(ReviewAssignment.application_id == payload.application_id, ReviewAssignment.reviewer_id == payload.reviewer_id, ReviewAssignment.stage_id == payload.stage_id, ReviewAssignment.id != id).first()
    if duplicate:
        session.close()
        raise HTTPException(status_code=400, detail="Review assignment already exists")
    assignment.application_id = payload.application_id
    assignment.reviewer_id = payload.reviewer_id
    assignment.stage_id = payload.stage_id
    session.commit()
    session.refresh(assignment)
    result = ReviewAssignmentOut.model_validate(assignment, from_attributes=True)
    session.close()
    return result


@router.patch("/{id}", response_model=ReviewAssignmentOut, summary="Partially update a review assignment", description="Update one or more fields of an existing review assignment.", operation_id="update_review_assignment")
async def update_review_assignment(id: int, payload: ReviewAssignmentUpdate):
    session = SessionLocal()
    assignment = session.query(ReviewAssignment).filter(ReviewAssignment.id == id).first()
    if not assignment:
        session.close()
        raise HTTPException(status_code=404, detail="Review assignment not found")
    new_application_id = payload.application_id if payload.application_id is not None else assignment.application_id
    new_reviewer_id = payload.reviewer_id if payload.reviewer_id is not None else assignment.reviewer_id
    new_stage_id = payload.stage_id if payload.stage_id is not None else assignment.stage_id
    if payload.application_id is not None:
        application = session.query(Application).filter(Application.id == payload.application_id).first()
        if not application:
            session.close()
            raise HTTPException(status_code=404, detail="Application not found")
    if payload.reviewer_id is not None:
        reviewer = session.query(User).filter(User.id == payload.reviewer_id).first()
        if not reviewer:
            session.close()
            raise HTTPException(status_code=404, detail="Reviewer not found")
    if payload.stage_id is not None:
        stage = session.query(ReviewStage).filter(ReviewStage.id == payload.stage_id).first()
        if not stage:
            session.close()
            raise HTTPException(status_code=404, detail="Review stage not found")
    duplicate = session.query(ReviewAssignment).filter(ReviewAssignment.application_id == new_application_id, ReviewAssignment.reviewer_id == new_reviewer_id, ReviewAssignment.stage_id == new_stage_id, ReviewAssignment.id != id).first()
    if duplicate:
        session.close()
        raise HTTPException(status_code=400, detail="Review assignment already exists")
    assignment.application_id = new_application_id
    assignment.reviewer_id = new_reviewer_id
    assignment.stage_id = new_stage_id
    session.commit()
    session.refresh(assignment)
    result = ReviewAssignmentOut.model_validate(assignment, from_attributes=True)
    session.close()
    return result


@router.delete("/{id}", response_model=ReviewAssignmentDeleteOut, summary="Delete a review assignment", description="Remove a review assignment by ID.", operation_id="delete_review_assignment")
async def delete_review_assignment(id: int):
    session = SessionLocal()
    assignment = session.query(ReviewAssignment).filter(ReviewAssignment.id == id).first()
    if not assignment:
        session.close()
        raise HTTPException(status_code=404, detail="Review assignment not found")
    session.delete(assignment)
    session.commit()
    session.close()
    return ReviewAssignmentDeleteOut(deleted=True)