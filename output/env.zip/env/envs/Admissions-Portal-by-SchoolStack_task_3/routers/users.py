from fastapi import APIRouter, HTTPException, Query
from typing import Optional
from database import SessionLocal
from models import User
from schemas import UserOut, UserCreate, UserUpdate, UserListOut

router = APIRouter(prefix="/api/users", tags=["Users"])


@router.get("", response_model=UserListOut, summary="List all users", description="Retrieve a list of all users in the system.", operation_id="list_users")
async def list_users(username: Optional[str] = Query(None), email: Optional[str] = Query(None), full_name: Optional[str] = Query(None)):
    session = SessionLocal()
    query = session.query(User)
    if username:
        query = query.filter(User.username == username)
    if email:
        query = query.filter(User.email == email)
    if full_name:
        query = query.filter(User.full_name.like(f"%{full_name}%"))
    users = query.all()
    result = UserListOut(users=[UserOut.model_validate(u, from_attributes=True) for u in users])
    session.close()
    return result


@router.post("", response_model=UserOut, summary="Create a new user", description="Create a new user with the provided details.", operation_id="create_user")
async def create_user(payload: UserCreate):
    session = SessionLocal()
    existing = session.query(User).filter(User.username == payload.username).first()
    if existing:
        session.close()
        raise HTTPException(status_code=400, detail="Username already exists")
    if payload.email:
        existing_email = session.query(User).filter(User.email == payload.email).first()
        if existing_email:
            session.close()
            raise HTTPException(status_code=400, detail="Email already exists")
    user = User(username=payload.username, full_name=payload.full_name, email=payload.email)
    session.add(user)
    session.commit()
    session.refresh(user)
    result = UserOut.model_validate(user, from_attributes=True)
    session.close()
    return result


@router.get("/me", response_model=UserOut, summary="Get current user profile", description="Retrieve the profile of the current user (user_id=1).", operation_id="get_current_user")
async def get_current_user():
    session = SessionLocal()
    user = session.query(User).filter(User.id == 1).first()
    if not user:
        session.close()
        raise HTTPException(status_code=404, detail="Current user not found")
    result = UserOut.model_validate(user, from_attributes=True)
    session.close()
    return result


@router.put("/me", response_model=UserOut, summary="Update current user profile", description="Update the profile of the current user (user_id=1).", operation_id="update_current_user")
async def update_current_user(payload: UserUpdate):
    session = SessionLocal()
    user = session.query(User).filter(User.id == 1).first()
    if not user:
        session.close()
        raise HTTPException(status_code=404, detail="Current user not found")
    existing = session.query(User).filter(User.username == payload.username, User.id != 1).first()
    if existing:
        session.close()
        raise HTTPException(status_code=400, detail="Username already exists")
    if payload.email:
        existing_email = session.query(User).filter(User.email == payload.email, User.id != 1).first()
        if existing_email:
            session.close()
            raise HTTPException(status_code=400, detail="Email already exists")
    user.username = payload.username
    user.full_name = payload.full_name
    user.email = payload.email
    session.commit()
    session.refresh(user)
    result = UserOut.model_validate(user, from_attributes=True)
    session.close()
    return result


@router.get("/{user_id}", response_model=UserOut, summary="Get a user by ID", description="Retrieve a single user by their unique ID.", operation_id="get_user")
async def get_user(user_id: int):
    session = SessionLocal()
    user = session.query(User).filter(User.id == user_id).first()
    if not user:
        session.close()
        raise HTTPException(status_code=404, detail="User not found")
    result = UserOut.model_validate(user, from_attributes=True)
    session.close()
    return result


@router.put("/{user_id}", response_model=UserOut, summary="Update a user", description="Update an existing user's details by ID.", operation_id="update_user")
async def update_user(user_id: int, payload: UserUpdate):
    session = SessionLocal()
    user = session.query(User).filter(User.id == user_id).first()
    if not user:
        session.close()
        raise HTTPException(status_code=404, detail="User not found")
    existing = session.query(User).filter(User.username == payload.username, User.id != user_id).first()
    if existing:
        session.close()
        raise HTTPException(status_code=400, detail="Username already exists")
    if payload.email:
        existing_email = session.query(User).filter(User.email == payload.email, User.id != user_id).first()
        if existing_email:
            session.close()
            raise HTTPException(status_code=400, detail="Email already exists")
    user.username = payload.username
    user.full_name = payload.full_name
    user.email = payload.email
    session.commit()
    session.refresh(user)
    result = UserOut.model_validate(user, from_attributes=True)
    session.close()
    return result


@router.delete("/{user_id}", summary="Delete a user", description="Delete a user by their unique ID.", operation_id="delete_user")
async def delete_user(user_id: int):
    session = SessionLocal()
    user = session.query(User).filter(User.id == user_id).first()
    if not user:
        session.close()
        raise HTTPException(status_code=404, detail="User not found")
    session.delete(user)
    session.commit()
    session.close()
    return {"success": True}