from fastapi import APIRouter, HTTPException, Query
from typing import Optional
from datetime import date
from database import SessionLocal
from models import Term, Program, ProgramTerm
from schemas import (
    TermOut, TermCreate, TermUpdate, TermListOut,
    ProgramOut, ProgramListOut, ProgramTermOut,
)

router = APIRouter(prefix="/api/terms", tags=["Terms"])


@router.get("", response_model=TermListOut, summary="List all terms", description="Retrieve a list of all terms with optional filtering by name and date range.", operation_id="list_terms")
async def list_terms(name: Optional[str] = Query(None), start_date_from: Optional[str] = Query(None), start_date_to: Optional[str] = Query(None)):
    session = SessionLocal()
    query = session.query(Term)
    if name:
        query = query.filter(Term.name == name)
    if start_date_from:
        query = query.filter(Term.start_date >= date.fromisoformat(start_date_from))
    if start_date_to:
        query = query.filter(Term.start_date <= date.fromisoformat(start_date_to))
    terms = query.all()
    result = TermListOut(terms=[TermOut.model_validate(t, from_attributes=True) for t in terms])
    session.close()
    return result


@router.post("", response_model=TermOut, summary="Create a new term", description="Create a new term with a unique name and optional start and end dates.", operation_id="create_term")
async def create_term(payload: TermCreate):
    session = SessionLocal()
    existing = session.query(Term).filter(Term.name == payload.name).first()
    if existing:
        session.close()
        raise HTTPException(status_code=400, detail="Term name already exists")
    term = Term(name=payload.name, start_date=payload.start_date, end_date=payload.end_date)
    session.add(term)
    session.commit()
    session.refresh(term)
    result = TermOut.model_validate(term, from_attributes=True)
    session.close()
    return result


@router.get("/{term_id}", response_model=TermOut, summary="Get a term by ID", description="Retrieve a single term by its unique identifier.", operation_id="get_term")
async def get_term(term_id: int):
    session = SessionLocal()
    term = session.query(Term).filter(Term.id == term_id).first()
    if not term:
        session.close()
        raise HTTPException(status_code=404, detail="Term not found")
    result = TermOut.model_validate(term, from_attributes=True)
    session.close()
    return result


@router.put("/{term_id}", response_model=TermOut, summary="Update a term", description="Update an existing term's name, start date, or end date.", operation_id="update_term")
async def update_term(term_id: int, payload: TermUpdate):
    session = SessionLocal()
    term = session.query(Term).filter(Term.id == term_id).first()
    if not term:
        session.close()
        raise HTTPException(status_code=404, detail="Term not found")
    if payload.name is not None:
        existing = session.query(Term).filter(Term.name == payload.name, Term.id != term_id).first()
        if existing:
            session.close()
            raise HTTPException(status_code=400, detail="Term name already exists")
        term.name = payload.name
    if payload.start_date is not None:
        term.start_date = payload.start_date
    if payload.end_date is not None:
        term.end_date = payload.end_date
    session.commit()
    session.refresh(term)
    result = TermOut.model_validate(term, from_attributes=True)
    session.close()
    return result


@router.delete("/{term_id}", summary="Delete a term", description="Delete a term by its unique identifier. Associated program_terms will be cascade deleted.", operation_id="delete_term")
async def delete_term(term_id: int):
    session = SessionLocal()
    term = session.query(Term).filter(Term.id == term_id).first()
    if not term:
        session.close()
        raise HTTPException(status_code=404, detail="Term not found")
    session.query(ProgramTerm).filter(ProgramTerm.term_id == term_id).delete()
    session.delete(term)
    session.commit()
    session.close()
    return {"message": "Term deleted successfully."}


@router.get("/{term_id}/programs", response_model=ProgramListOut, summary="List programs associated with a term", description="Retrieve all programs linked to the specified term via program_terms.", operation_id="list_term_programs")
async def list_term_programs(term_id: int):
    session = SessionLocal()
    term = session.query(Term).filter(Term.id == term_id).first()
    if not term:
        session.close()
        raise HTTPException(status_code=404, detail="Term not found")
    programs = session.query(Program).join(ProgramTerm, ProgramTerm.program_id == Program.id).filter(ProgramTerm.term_id == term_id).all()
    result = ProgramListOut(programs=[ProgramOut.model_validate(p, from_attributes=True) for p in programs])
    session.close()
    return result


@router.post("/{term_id}/programs/{program_id}", response_model=ProgramTermOut, summary="Associate a program with a term", description="Create a program_terms link between a program and a term.", operation_id="associate_program_with_term")
async def associate_program_with_term(term_id: int, program_id: int):
    session = SessionLocal()
    term = session.query(Term).filter(Term.id == term_id).first()
    if not term:
        session.close()
        raise HTTPException(status_code=404, detail="Term not found")
    program = session.query(Program).filter(Program.id == program_id).first()
    if not program:
        session.close()
        raise HTTPException(status_code=404, detail="Program not found")
    existing = session.query(ProgramTerm).filter(ProgramTerm.program_id == program_id, ProgramTerm.term_id == term_id).first()
    if existing:
        session.close()
        raise HTTPException(status_code=400, detail="Program-term association already exists")
    pt = ProgramTerm(program_id=program_id, term_id=term_id)
    session.add(pt)
    session.commit()
    session.refresh(pt)
    result = ProgramTermOut.model_validate(pt, from_attributes=True)
    session.close()
    return result


@router.delete("/{term_id}/programs/{program_id}", summary="Remove a program from a term", description="Delete the program_terms link between a program and a term.", operation_id="dissociate_program_from_term")
async def dissociate_program_from_term(term_id: int, program_id: int):
    session = SessionLocal()
    pt = session.query(ProgramTerm).filter(ProgramTerm.program_id == program_id, ProgramTerm.term_id == term_id).first()
    if not pt:
        session.close()
        raise HTTPException(status_code=404, detail="Program-term association not found")
    session.delete(pt)
    session.commit()
    session.close()
    return {"message": "Program dissociated from term successfully."}