from fastapi import APIRouter, HTTPException, Query
from typing import Optional
from database import SessionLocal
from models import ReviewCommittee, ReviewStage, ReviewAssignment, Application, ProgramTerm, User
from schemas import (
    ReviewCommitteeOut, ReviewCommitteeCreate, ReviewCommitteeUpdate, ReviewCommitteeListOut,
    ReviewStageOut, ReviewStageCreate, ReviewStageListOut, WorkloadEntryOut, WorkloadListOut,
)

router = APIRouter(prefix="/api/review-committees", tags=["ReviewCommittees"])


def _compute_workload(session, committee_id, program_id, term_id):
    stage_query = session.query(ReviewStage).filter(ReviewStage.committee_id == committee_id)
    stages = stage_query.all()
    stage_ids = [s.id for s in stages]
    if not stage_ids:
        return []
    q = session.query(ReviewAssignment).filter(ReviewAssignment.stage_id.in_(stage_ids))
    if program_id is not None or term_id is not None:
        q = q.join(Application, Application.id == ReviewAssignment.application_id)
        if program_id is not None or term_id is not None:
            q = q.join(ProgramTerm, ProgramTerm.id == Application.program_term_id)
        if program_id is not None:
            q = q.filter(ProgramTerm.program_id == program_id)
        if term_id is not None:
            q = q.filter(ProgramTerm.term_id == term_id)
    assignments = q.all()
    stage_map = {s.id: s for s in stages}
    reviewer_ids = list({a.reviewer_id for a in assignments})
    users = session.query(User).filter(User.id.in_(reviewer_ids)).all() if reviewer_ids else []
    user_map = {u.id: u for u in users}
    app_ids = list({a.application_id for a in assignments})
    apps = session.query(Application).filter(Application.id.in_(app_ids)).all() if app_ids else []
    app_map = {a.id: a for a in apps}
    buckets = {}
    for a in assignments:
        key = (a.reviewer_id, a.stage_id)
        if key not in buckets:
            buckets[key] = {"assigned": 0, "admit": 0, "waitlist": 0, "deny": 0}
        buckets[key]["assigned"] += 1
        app = app_map.get(a.application_id)
        if app and app.final_decision in ("admit", "waitlist", "deny"):
            buckets[key][app.final_decision] += 1
    entries = []
    for (reviewer_id, stage_id), counts in buckets.items():
        assigned = counts["assigned"]
        admit = counts["admit"]
        waitlist = counts["waitlist"]
        deny = counts["deny"]
        user = user_map.get(reviewer_id)
        stage = stage_map.get(stage_id)
        entries.append(WorkloadEntryOut(
            reviewer_id=reviewer_id,
            reviewer_name=user.full_name if user else None,
            stage_id=stage_id,
            stage_name=stage.name if stage else None,
            assigned_count=assigned,
            admit_count=admit,
            waitlist_count=waitlist,
            deny_count=deny,
            admit_percentage=round(admit / assigned * 100, 2) if assigned else 0.0,
            waitlist_percentage=round(waitlist / assigned * 100, 2) if assigned else 0.0,
            deny_percentage=round(deny / assigned * 100, 2) if assigned else 0.0,
        ))
    entries.sort(key=lambda e: (e.stage_id, e.reviewer_id))
    return entries


@router.get("", response_model=ReviewCommitteeListOut, summary="List all review committees", description="Retrieve a list of all review committees.", operation_id="list_review_committees")
async def list_review_committees():
    session = SessionLocal()
    committees = session.query(ReviewCommittee).all()
    result = ReviewCommitteeListOut(review_committees=[ReviewCommitteeOut.model_validate(c, from_attributes=True) for c in committees])
    session.close()
    return result


@router.post("", response_model=ReviewCommitteeOut, summary="Create a new review committee", description="Create a new review committee with the given name.", operation_id="create_review_committee")
async def create_review_committee(payload: ReviewCommitteeCreate):
    session = SessionLocal()
    committee = ReviewCommittee(name=payload.name)
    session.add(committee)
    session.commit()
    session.refresh(committee)
    result = ReviewCommitteeOut.model_validate(committee, from_attributes=True)
    session.close()
    return result


@router.get("/{committee_id}", response_model=ReviewCommitteeOut, summary="Get a review committee by ID", description="Retrieve a single review committee by its ID.", operation_id="get_review_committee")
async def get_review_committee(committee_id: int):
    session = SessionLocal()
    committee = session.query(ReviewCommittee).filter(ReviewCommittee.id == committee_id).first()
    if not committee:
        session.close()
        raise HTTPException(status_code=404, detail="Review committee not found")
    result = ReviewCommitteeOut.model_validate(committee, from_attributes=True)
    session.close()
    return result


@router.put("/{committee_id}", response_model=ReviewCommitteeOut, summary="Update a review committee", description="Update the name of an existing review committee.", operation_id="update_review_committee")
async def update_review_committee(committee_id: int, payload: ReviewCommitteeUpdate):
    session = SessionLocal()
    committee = session.query(ReviewCommittee).filter(ReviewCommittee.id == committee_id).first()
    if not committee:
        session.close()
        raise HTTPException(status_code=404, detail="Review committee not found")
    committee.name = payload.name
    session.commit()
    session.refresh(committee)
    result = ReviewCommitteeOut.model_validate(committee, from_attributes=True)
    session.close()
    return result


@router.delete("/{committee_id}", summary="Delete a review committee", description="Delete a review committee by its ID.", operation_id="delete_review_committee")
async def delete_review_committee(committee_id: int):
    session = SessionLocal()
    committee = session.query(ReviewCommittee).filter(ReviewCommittee.id == committee_id).first()
    if not committee:
        session.close()
        raise HTTPException(status_code=404, detail="Review committee not found")
    stage_ids = [s.id for s in session.query(ReviewStage).filter(ReviewStage.committee_id == committee_id).all()]
    if stage_ids:
        session.query(ReviewAssignment).filter(ReviewAssignment.stage_id.in_(stage_ids)).delete(synchronize_session=False)
        session.query(ReviewStage).filter(ReviewStage.committee_id == committee_id).delete(synchronize_session=False)
    session.delete(committee)
    session.commit()
    session.close()
    return {"message": "Review committee deleted successfully"}


@router.get("/{committee_id}/stages", response_model=ReviewStageListOut, summary="List stages for a review committee", description="Retrieve all review stages belonging to a specific committee.", operation_id="list_committee_review_stages")
async def list_committee_review_stages(committee_id: int):
    session = SessionLocal()
    committee = session.query(ReviewCommittee).filter(ReviewCommittee.id == committee_id).first()
    if not committee:
        session.close()
        raise HTTPException(status_code=404, detail="Review committee not found")
    stages = session.query(ReviewStage).filter(ReviewStage.committee_id == committee_id).order_by(ReviewStage.stage_order).all()
    result = ReviewStageListOut(review_stages=[ReviewStageOut.model_validate(s, from_attributes=True) for s in stages])
    session.close()
    return result


@router.post("/{committee_id}/stages", response_model=ReviewStageOut, summary="Create a review stage", description="Create a new review stage for a specific committee.", operation_id="create_committee_review_stage")
async def create_committee_review_stage(committee_id: int, payload: ReviewStageCreate):
    session = SessionLocal()
    committee = session.query(ReviewCommittee).filter(ReviewCommittee.id == committee_id).first()
    if not committee:
        session.close()
        raise HTTPException(status_code=404, detail="Review committee not found")
    existing = session.query(ReviewStage).filter(ReviewStage.committee_id == committee_id, ReviewStage.name == payload.name).first()
    if existing:
        session.close()
        raise HTTPException(status_code=400, detail="Stage name already exists for this committee")
    stage = ReviewStage(committee_id=committee_id, name=payload.name, stage_order=payload.stage_order)
    session.add(stage)
    session.commit()
    session.refresh(stage)
    result = ReviewStageOut.model_validate(stage, from_attributes=True)
    session.close()
    return result


@router.get("/{committee_id}/workload", response_model=WorkloadListOut, summary="Get reviewer workload for a committee", description="Retrieve reviewer workload counts and decision percentages grouped by stage for a committee.", operation_id="get_committee_reviewer_workload")
async def get_committee_reviewer_workload(committee_id: int, program_id: Optional[int] = Query(None), term_id: Optional[int] = Query(None)):
    session = SessionLocal()
    committee = session.query(ReviewCommittee).filter(ReviewCommittee.id == committee_id).first()
    if not committee:
        session.close()
        raise HTTPException(status_code=404, detail="Review committee not found")
    entries = _compute_workload(session, committee_id, program_id, term_id)
    result = WorkloadListOut(workload=entries)
    session.close()
    return result