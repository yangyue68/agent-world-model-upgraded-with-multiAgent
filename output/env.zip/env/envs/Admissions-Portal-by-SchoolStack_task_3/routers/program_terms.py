from fastapi import APIRouter, HTTPException, Query
from typing import Optional
from database import SessionLocal
from models import ProgramTerm, Program, Term
from schemas import ProgramTermOut, ProgramTermCreate, ProgramTermUpdate, ProgramTermListOut, ProgramTermDeleteOut

router = APIRouter(prefix="/api/program-terms", tags=["ProgramTerms"])


@router.get("", response_model=ProgramTermListOut, summary="List all program-term associations", description="Retrieve all program-term links with optional filtering by program_id or term_id.", operation_id="list_program_terms_all")
async def list_program_terms_all(program_id: Optional[int] = Query(None), term_id: Optional[int] = Query(None)):
    session = SessionLocal()
    query = session.query(ProgramTerm)
    if program_id is not None:
        query = query.filter(ProgramTerm.program_id == program_id)
    if term_id is not None:
        query = query.filter(ProgramTerm.term_id == term_id)
    pts = query.all()
    result = ProgramTermListOut(program_terms=[ProgramTermOut.model_validate(p, from_attributes=True) for p in pts])
    session.close()
    return result


@router.post("", response_model=ProgramTermOut, summary="Create a new program-term association", description="Link a program to a term by creating a new program_terms record.", operation_id="create_program_term_link")
async def create_program_term_link(payload: ProgramTermCreate):
    session = SessionLocal()
    program = session.query(Program).filter(Program.id == payload.program_id).first()
    if not program:
        session.close()
        raise HTTPException(status_code=404, detail="Program not found")
    term = session.query(Term).filter(Term.id == payload.term_id).first()
    if not term:
        session.close()
        raise HTTPException(status_code=404, detail="Term not found")
    existing = session.query(ProgramTerm).filter(ProgramTerm.program_id == payload.program_id, ProgramTerm.term_id == payload.term_id).first()
    if existing:
        session.close()
        raise HTTPException(status_code=400, detail="Program-term association already exists")
    pt = ProgramTerm(program_id=payload.program_id, term_id=payload.term_id)
    session.add(pt)
    session.commit()
    session.refresh(pt)
    result = ProgramTermOut.model_validate(pt, from_attributes=True)
    session.close()
    return result


@router.get("/{id}", response_model=ProgramTermOut, summary="Get a program-term association by ID", description="Retrieve a single program-term link using its unique ID.", operation_id="get_program_term_link")
async def get_program_term_link(id: int):
    session = SessionLocal()
    pt = session.query(ProgramTerm).filter(ProgramTerm.id == id).first()
    if not pt:
        session.close()
        raise HTTPException(status_code=404, detail="Program-term association not found")
    result = ProgramTermOut.model_validate(pt, from_attributes=True)
    session.close()
    return result


@router.put("/{id}", response_model=ProgramTermOut, summary="Update a program-term association", description="Replace the program_id and term_id of an existing program-term link.", operation_id="update_program_term_link")
async def update_program_term_link(id: int, payload: ProgramTermUpdate):
    session = SessionLocal()
    pt = session.query(ProgramTerm).filter(ProgramTerm.id == id).first()
    if not pt:
        session.close()
        raise HTTPException(status_code=404, detail="Program-term association not found")
    program = session.query(Program).filter(Program.id == payload.program_id).first()
    if not program:
        session.close()
        raise HTTPException(status_code=404, detail="Program not found")
    term = session.query(Term).filter(Term.id == payload.term_id).first()
    if not term:
        session.close()
        raise HTTPException(status_code=404, detail="Term not found")
    duplicate = session.query(ProgramTerm).filter(ProgramTerm.program_id == payload.program_id, ProgramTerm.term_id == payload.term_id, ProgramTerm.id != id).first()
    if duplicate:
        session.close()
        raise HTTPException(status_code=400, detail="Program-term association already exists")
    pt.program_id = payload.program_id
    pt.term_id = payload.term_id
    session.commit()
    session.refresh(pt)
    result = ProgramTermOut.model_validate(pt, from_attributes=True)
    session.close()
    return result


@router.delete("/{id}", response_model=ProgramTermDeleteOut, summary="Delete a program-term association", description="Remove a program-term link by its ID.", operation_id="delete_program_term_link")
async def delete_program_term_link(id: int):
    session = SessionLocal()
    pt = session.query(ProgramTerm).filter(ProgramTerm.id == id).first()
    if not pt:
        session.close()
        raise HTTPException(status_code=404, detail="Program-term association not found")
    session.delete(pt)
    session.commit()
    session.close()
    return ProgramTermDeleteOut(deleted=True)