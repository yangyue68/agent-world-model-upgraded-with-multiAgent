from fastapi import APIRouter, HTTPException, Query
from typing import Optional
from database import SessionLocal
from models import ReviewStage, ReviewCommittee, ReviewAssignment, Application, ProgramTerm, User
from schemas import (
    ReviewStageOut, ReviewStageCreate, ReviewStageUpdate, ReviewStageListOut, ReviewStageDeleteOut,
    ReviewAssignmentOut, ReviewAssignmentListOut,
    StageReviewerWorkloadEntryOut, StageReviewerWorkloadOut,
)

router = APIRouter(prefix="/api/review-stages", tags=["ReviewStages"])


@router.get("", response_model=ReviewStageListOut, summary="List review stages with optional committee filter", description="Retrieve review stages, optionally filtered by committee_id, ordered by stage_order.", operation_id="list_review_stages")
async def list_review_stages(committee_id: Optional[int] = Query(None), name: Optional[str] = Query(None)):
    session = SessionLocal()
    query = session.query(ReviewStage)
    if committee_id is not None:
        query = query.filter(ReviewStage.committee_id == committee_id)
    if name:
        query = query.filter(ReviewStage.name == name)
    stages = query.order_by(ReviewStage.stage_order).all()
    result = ReviewStageListOut(review_stages=[ReviewStageOut.model_validate(s, from_attributes=True) for s in stages])
    session.close()
    return result


@router.post("", response_model=ReviewStageOut, summary="Create a new review stage", description="Create a review stage under a committee with a unique name and order.", operation_id="create_review_stage")
async def create_review_stage(payload: ReviewStageCreate):
    session = SessionLocal()
    committee = session.query(ReviewCommittee).filter(ReviewCommittee.id == payload.committee_id).first()
    if not committee:
        session.close()
        raise HTTPException(status_code=404, detail="Review committee not found")
    existing = session.query(ReviewStage).filter(ReviewStage.committee_id == payload.committee_id, ReviewStage.name == payload.name).first()
    if existing:
        session.close()
        raise HTTPException(status_code=400, detail="Stage name already exists for this committee")
    stage = ReviewStage(committee_id=payload.committee_id, name=payload.name, stage_order=payload.stage_order)
    session.add(stage)
    session.commit()
    session.refresh(stage)
    result = ReviewStageOut.model_validate(stage, from_attributes=True)
    session.close()
    return result


@router.get("/{id}", response_model=ReviewStageOut, summary="Get a single review stage by id", description="Retrieve one review stage including its committee and order.", operation_id="get_review_stage")
async def get_review_stage(id: int):
    session = SessionLocal()
    stage = session.query(ReviewStage).filter(ReviewStage.id == id).first()
    if not stage:
        session.close()
        raise HTTPException(status_code=404, detail="Review stage not found")
    result = ReviewStageOut.model_validate(stage, from_attributes=True)
    session.close()
    return result


@router.put("/{id}", response_model=ReviewStageOut, summary="Replace a review stage", description="Fully update a review stage's committee, name, and order.", operation_id="replace_review_stage")
async def replace_review_stage(id: int, payload: ReviewStageCreate):
    session = SessionLocal()
    stage = session.query(ReviewStage).filter(ReviewStage.id == id).first()
    if not stage:
        session.close()
        raise HTTPException(status_code=404, detail="Review stage not found")
    committee = session.query(ReviewCommittee).filter(ReviewCommittee.id == payload.committee_id).first()
    if not committee:
        session.close()
        raise HTTPException(status_code=404, detail="Review committee not found")
    duplicate = session.query(ReviewStage).filter(ReviewStage.committee_id == payload.committee_id, ReviewStage.name == payload.name, ReviewStage.id != id).first()
    if duplicate:
        session.close()
        raise HTTPException(status_code=400, detail="Stage name already exists for this committee")
    stage.committee_id = payload.committee_id
    stage.name = payload.name
    stage.stage_order = payload.stage_order
    session.commit()
    session.refresh(stage)
    result = ReviewStageOut.model_validate(stage, from_attributes=True)
    session.close()
    return result


@router.patch("/{id}", response_model=ReviewStageOut, summary="Partially update a review stage", description="Update one or more fields of a review stage.", operation_id="update_review_stage")
async def update_review_stage(id: int, payload: ReviewStageUpdate):
    session = SessionLocal()
    stage = session.query(ReviewStage).filter(ReviewStage.id == id).first()
    if not stage:
        session.close()
        raise HTTPException(status_code=404, detail="Review stage not found")
    new_committee_id = payload.committee_id if payload.committee_id is not None else stage.committee_id
    new_name = payload.name if payload.name is not None else stage.name
    if payload.committee_id is not None:
        committee = session.query(ReviewCommittee).filter(ReviewCommittee.id == payload.committee_id).first()
        if not committee:
            session.close()
            raise HTTPException(status_code=404, detail="Review committee not found")
    duplicate = session.query(ReviewStage).filter(ReviewStage.committee_id == new_committee_id, ReviewStage.name == new_name, ReviewStage.id != id).first()
    if duplicate:
        session.close()
        raise HTTPException(status_code=400, detail="Stage name already exists for this committee")
    stage.committee_id = new_committee_id
    stage.name = new_name
    if payload.stage_order is not None:
        stage.stage_order = payload.stage_order
    session.commit()
    session.refresh(stage)
    result = ReviewStageOut.model_validate(stage, from_attributes=True)
    session.close()
    return result


@router.delete("/{id}", response_model=ReviewStageDeleteOut, summary="Delete a review stage", description="Delete a review stage and cascade its review assignments.", operation_id="delete_review_stage")
async def delete_review_stage(id: int):
    session = SessionLocal()
    stage = session.query(ReviewStage).filter(ReviewStage.id == id).first()
    if not stage:
        session.close()
        raise HTTPException(status_code=404, detail="Review stage not found")
    session.query(ReviewAssignment).filter(ReviewAssignment.stage_id == id).delete(synchronize_session=False)
    session.delete(stage)
    session.commit()
    session.close()
    return ReviewStageDeleteOut(deleted=True, id=id)


@router.get("/{id}/review-assignments", response_model=ReviewAssignmentListOut, summary="List review assignments for a stage", description="Retrieve review assignments belonging to a specific review stage.", operation_id="list_stage_review_assignments")
async def list_stage_review_assignments(id: int, reviewer_id: Optional[int] = Query(None)):
    session = SessionLocal()
    stage = session.query(ReviewStage).filter(ReviewStage.id == id).first()
    if not stage:
        session.close()
        raise HTTPException(status_code=404, detail="Review stage not found")
    query = session.query(ReviewAssignment).filter(ReviewAssignment.stage_id == id)
    if reviewer_id is not None:
        query = query.filter(ReviewAssignment.reviewer_id == reviewer_id)
    assignments = query.all()
    result = ReviewAssignmentListOut(review_assignments=[ReviewAssignmentOut.model_validate(a, from_attributes=True) for a in assignments])
    session.close()
    return result


@router.get("/{id}/reviewer-workload", response_model=StageReviewerWorkloadOut, summary="Reviewer workload stats for a stage", description="Count assigned applications per reviewer and decision percentages for a stage.", operation_id="get_stage_reviewer_workload")
async def get_stage_reviewer_workload(id: int, program_id: Optional[int] = Query(None), term_id: Optional[int] = Query(None)):
    session = SessionLocal()
    stage = session.query(ReviewStage).filter(ReviewStage.id == id).first()
    if not stage:
        session.close()
        raise HTTPException(status_code=404, detail="Review stage not found")
    q = session.query(ReviewAssignment).filter(ReviewAssignment.stage_id == id)
    if program_id is not None or term_id is not None:
        q = q.join(Application, Application.id == ReviewAssignment.application_id)
        q = q.join(ProgramTerm, ProgramTerm.id == Application.program_term_id)
        if program_id is not None:
            q = q.filter(ProgramTerm.program_id == program_id)
        if term_id is not None:
            q = q.filter(ProgramTerm.term_id == term_id)
    assignments = q.all()
    reviewer_ids = list({a.reviewer_id for a in assignments})
    users = session.query(User).filter(User.id.in_(reviewer_ids)).all() if reviewer_ids else []
    user_map = {u.id: u for u in users}
    app_ids = list({a.application_id for a in assignments})
    apps = session.query(Application).filter(Application.id.in_(app_ids)).all() if app_ids else []
    app_map = {a.id: a for a in apps}
    buckets = {}
    for a in assignments:
        if a.reviewer_id not in buckets:
            buckets[a.reviewer_id] = {"assigned": 0, "admit": 0, "waitlist": 0, "deny": 0}
        buckets[a.reviewer_id]["assigned"] += 1
        app = app_map.get(a.application_id)
        if app and app.final_decision in ("admit", "waitlist", "deny"):
            buckets[a.reviewer_id][app.final_decision] += 1
    reviewers = []
    for reviewer_id, counts in buckets.items():
        assigned = counts["assigned"]
        admit = counts["admit"]
        waitlist = counts["waitlist"]
        deny = counts["deny"]
        decided = admit + waitlist + deny
        user = user_map.get(reviewer_id)
        reviewers.append(StageReviewerWorkloadEntryOut(
            reviewer_id=reviewer_id,
            reviewer_name=user.full_name if user else None,
            assigned_count=assigned,
            admit_count=admit,
            waitlist_count=waitlist,
            deny_count=deny,
            decided_count=decided,
            admit_percentage=round(admit / assigned * 100, 2) if assigned else 0.0,
            waitlist_percentage=round(waitlist / assigned * 100, 2) if assigned else 0.0,
            deny_percentage=round(deny / assigned * 100, 2) if assigned else 0.0,
            decided_percentage=round(decided / assigned * 100, 2) if assigned else 0.0,
        ))
    reviewers.sort(key=lambda r: r.reviewer_id)
    result = StageReviewerWorkloadOut(stage_id=stage.id, stage_name=stage.name, reviewers=reviewers)
    session.close()
    return result