from fastapi import APIRouter, HTTPException, Query
from typing import Optional
from database import SessionLocal
from models import Applicant, Application, ProgramTerm
from schemas import (
    ApplicantOut, ApplicantCreate, ApplicantUpdate, ApplicantListOut, ApplicantDeleteOut,
    ApplicationOut, ApplicationCreate, ApplicationListOut,
)

router = APIRouter(prefix="/api/applicants", tags=["Applicants"])


@router.get("", response_model=ApplicantListOut, summary="List applicants with optional filters", description="Retrieve a paginated list of applicants, optionally filtered by name or email.", operation_id="list_applicants")
async def list_applicants(first_name: Optional[str] = Query(None), last_name: Optional[str] = Query(None), email: Optional[str] = Query(None), limit: int = Query(50), offset: int = Query(0)):
    session = SessionLocal()
    query = session.query(Applicant)
    if first_name:
        query = query.filter(Applicant.first_name.like(f"%{first_name}%"))
    if last_name:
        query = query.filter(Applicant.last_name.like(f"%{last_name}%"))
    if email:
        query = query.filter(Applicant.email == email)
    total = query.count()
    applicants = query.offset(offset).limit(limit).all()
    result = ApplicantListOut(applicants=[ApplicantOut.model_validate(a, from_attributes=True) for a in applicants], total=total)
    session.close()
    return result


@router.post("", response_model=ApplicantOut, summary="Create a new applicant", description="Create a new applicant record with first name, last name, and optional email.", operation_id="create_applicant")
async def create_applicant(payload: ApplicantCreate):
    session = SessionLocal()
    if payload.email:
        existing = session.query(Applicant).filter(Applicant.email == payload.email).first()
        if existing:
            session.close()
            raise HTTPException(status_code=400, detail="Applicant email already exists")
    applicant = Applicant(first_name=payload.first_name, last_name=payload.last_name, email=payload.email)
    session.add(applicant)
    session.commit()
    session.refresh(applicant)
    result = ApplicantOut.model_validate(applicant, from_attributes=True)
    session.close()
    return result


@router.get("/{applicant_id}", response_model=ApplicantOut, summary="Get an applicant by ID", description="Retrieve a single applicant record by its unique identifier.", operation_id="get_applicant")
async def get_applicant(applicant_id: int):
    session = SessionLocal()
    applicant = session.query(Applicant).filter(Applicant.id == applicant_id).first()
    if not applicant:
        session.close()
        raise HTTPException(status_code=404, detail="Applicant not found")
    result = ApplicantOut.model_validate(applicant, from_attributes=True)
    session.close()
    return result


@router.put("/{applicant_id}", response_model=ApplicantOut, summary="Update an applicant by ID", description="Replace an existing applicant record with new data.", operation_id="update_applicant")
async def update_applicant(applicant_id: int, payload: ApplicantUpdate):
    session = SessionLocal()
    applicant = session.query(Applicant).filter(Applicant.id == applicant_id).first()
    if not applicant:
        session.close()
        raise HTTPException(status_code=404, detail="Applicant not found")
    if payload.email:
        existing = session.query(Applicant).filter(Applicant.email == payload.email, Applicant.id != applicant_id).first()
        if existing:
            session.close()
            raise HTTPException(status_code=400, detail="Applicant email already exists")
    applicant.first_name = payload.first_name
    applicant.last_name = payload.last_name
    applicant.email = payload.email
    session.commit()
    session.refresh(applicant)
    result = ApplicantOut.model_validate(applicant, from_attributes=True)
    session.close()
    return result


@router.delete("/{applicant_id}", response_model=ApplicantDeleteOut, summary="Delete an applicant by ID", description="Delete an applicant record and all associated applications.", operation_id="delete_applicant")
async def delete_applicant(applicant_id: int):
    session = SessionLocal()
    applicant = session.query(Applicant).filter(Applicant.id == applicant_id).first()
    if not applicant:
        session.close()
        raise HTTPException(status_code=404, detail="Applicant not found")
    session.query(Application).filter(Application.applicant_id == applicant_id).delete(synchronize_session=False)
    session.delete(applicant)
    session.commit()
    session.close()
    return ApplicantDeleteOut(deleted=True)


@router.get("/{applicant_id}/applications", response_model=ApplicationListOut, summary="List applications for an applicant", description="Retrieve all applications submitted by a specific applicant.", operation_id="list_applicant_applications")
async def list_applicant_applications(applicant_id: int):
    session = SessionLocal()
    applicant = session.query(Applicant).filter(Applicant.id == applicant_id).first()
    if not applicant:
        session.close()
        raise HTTPException(status_code=404, detail="Applicant not found")
    applications = session.query(Application).filter(Application.applicant_id == applicant_id).all()
    result = ApplicationListOut(applications=[ApplicationOut.model_validate(a, from_attributes=True) for a in applications], total=len(applications))
    session.close()
    return result


@router.post("/{applicant_id}/applications", response_model=ApplicationOut, summary="Create an application for an applicant", description="Create a new application for a specific applicant and program term.", operation_id="create_applicant_application")
async def create_applicant_application(applicant_id: int, payload: ApplicationCreate):
    session = SessionLocal()
    applicant = session.query(Applicant).filter(Applicant.id == applicant_id).first()
    if not applicant:
        session.close()
        raise HTTPException(status_code=404, detail="Applicant not found")
    pt = session.query(ProgramTerm).filter(ProgramTerm.id == payload.program_term_id).first()
    if not pt:
        session.close()
        raise HTTPException(status_code=404, detail="Program term not found")
    if payload.final_decision is not None and payload.final_decision not in ("admit", "waitlist", "deny"):
        session.close()
        raise HTTPException(status_code=400, detail="final_decision must be one of admit, waitlist, deny")
    application = Application(applicant_id=applicant_id, program_term_id=payload.program_term_id, submitted_at=payload.submitted_at, final_decision=payload.final_decision)
    session.add(application)
    session.commit()
    session.refresh(application)
    result = ApplicationOut.model_validate(application, from_attributes=True)
    session.close()
    return result