from datetime import datetime, date
from typing import Optional, List
from pydantic import BaseModel, ConfigDict, Field

class UserOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    username: str
    full_name: Optional[str] = None
    email: Optional[str] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class UserCreate(BaseModel):
    username: str
    full_name: Optional[str] = None
    email: Optional[str] = None

class UserUpdate(BaseModel):
    username: Optional[str] = None
    full_name: Optional[str] = None
    email: Optional[str] = None

class FormOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    name: str
    description: Optional[str] = None
    created_by: int
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class FormCreate(BaseModel):
    name: str
    description: Optional[str] = None
    created_by: Optional[int] = 1

class FormUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None

class FormListOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    forms: List[FormOut]

class FormSectionOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    form_id: int
    name: str
    description: Optional[str] = None
    is_optional: int
    max_entries: Optional[int] = None
    display_order: int
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class FormSectionCreate(BaseModel):
    name: str
    description: Optional[str] = None
    is_optional: Optional[int] = 0
    max_entries: Optional[int] = None
    display_order: Optional[int] = 0

class FormSectionUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    is_optional: Optional[int] = None
    max_entries: Optional[int] = None
    display_order: Optional[int] = None

class FormSectionListOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    sections: List[FormSectionOut]

class SectionFieldOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    section_id: int
    field_name: str
    field_label: str
    field_type: str
    is_required: int
    display_order: int
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class SectionFieldCreate(BaseModel):
    field_name: str
    field_label: str
    field_type: str
    is_required: Optional[int] = 0
    display_order: Optional[int] = 0

class SectionFieldUpdate(BaseModel):
    field_name: Optional[str] = None
    field_label: Optional[str] = None
    field_type: Optional[str] = None
    is_required: Optional[int] = None
    display_order: Optional[int] = None

class SectionFieldListOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    fields: List[SectionFieldOut]

class FormQuestionOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    form_id: int
    question_text: str
    question_type: str
    is_required: int
    display_order: int
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class FormQuestionCreate(BaseModel):
    question_text: str
    question_type: str
    is_required: Optional[int] = 0
    display_order: Optional[int] = 0

class FormQuestionUpdate(BaseModel):
    question_text: Optional[str] = None
    question_type: Optional[str] = None
    is_required: Optional[int] = None
    display_order: Optional[int] = None

class FormQuestionListOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    questions: List[FormQuestionOut]

class FormDocumentOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    form_id: int
    name: str
    description: Optional[str] = None
    is_required: int
    condition_question_id: Optional[int] = None
    condition_value: Optional[str] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class FormDocumentCreate(BaseModel):
    name: str
    description: Optional[str] = None
    is_required: Optional[int] = 0
    condition_question_id: Optional[int] = None
    condition_value: Optional[str] = None

class FormDocumentUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    is_required: Optional[int] = None
    condition_question_id: Optional[int] = None
    condition_value: Optional[str] = None

class FormDocumentListOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    documents: List[FormDocumentOut]

class FormDeadlineOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    form_id: int
    deadline_type: str
    deadline_date: date
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class FormDeadlineCreate(BaseModel):
    deadline_type: str
    deadline_date: date

class FormDeadlineUpdate(BaseModel):
    deadline_type: Optional[str] = None
    deadline_date: Optional[date] = None

class FormDeadlineListOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    deadlines: List[FormDeadlineOut]

class ApplicationOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    form_id: int
    applicant_id: int
    status: str
    submitted_at: Optional[datetime] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class ApplicationCreate(BaseModel):
    form_id: int
    applicant_id: Optional[int] = 1

class ApplicationUpdate(BaseModel):
    status: Optional[str] = None
    submitted_at: Optional[datetime] = None

class ApplicationListOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    applications: List[ApplicationOut]

class ApplicationAnswerOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    application_id: int
    question_id: int
    answer_value: Optional[str] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class ApplicationAnswerCreate(BaseModel):
    question_id: int
    answer_value: Optional[str] = None

class ApplicationAnswerUpdate(BaseModel):
    question_id: Optional[int] = None
    answer_value: Optional[str] = None

class ApplicationAnswerListOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    answers: List[ApplicationAnswerOut]

class ApplicationSectionEntryOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    application_id: int
    section_id: int
    entry_index: int
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class ApplicationSectionEntryCreate(BaseModel):
    section_id: int
    entry_index: int

class ApplicationSectionEntryUpdate(BaseModel):
    entry_index: Optional[int] = None

class ApplicationSectionEntryListOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    section_entries: List[ApplicationSectionEntryOut]

class ApplicationSectionEntryValueOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    entry_id: int
    field_id: int
    value: Optional[str] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class ApplicationSectionEntryValueCreate(BaseModel):
    field_id: int
    value: Optional[str] = None

class ApplicationSectionEntryValueUpdate(BaseModel):
    field_id: Optional[int] = None
    value: Optional[str] = None

class ApplicationSectionEntryValueListOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    values: List[ApplicationSectionEntryValueOut]

class ApplicationDocumentOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    application_id: int
    document_id: int
    file_path: str
    uploaded_at: Optional[datetime] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class ApplicationDocumentCreate(BaseModel):
    document_id: int
    file_path: str

class ApplicationDocumentUpdate(BaseModel):
    document_id: Optional[int] = None
    file_path: Optional[str] = None

class ApplicationDocumentListOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    documents: List[ApplicationDocumentOut]

class DeleteResponse(BaseModel):
    message: str

class DeletedResponse(BaseModel):
    deleted: bool
    id: Optional[int] = None