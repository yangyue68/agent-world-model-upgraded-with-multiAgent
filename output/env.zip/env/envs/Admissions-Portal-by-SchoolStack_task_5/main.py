import os
import uvicorn
from fastapi import FastAPI
from database import Base, engine
from routers import forms, sections, section_fields, questions, documents, deadlines, applications, users

Base.metadata.create_all(bind=engine)

app = FastAPI(title="Admissions Portal by SchoolStack", version="1.0.0")

app.include_router(forms.router)
app.include_router(sections.router)
app.include_router(section_fields.router)
app.include_router(questions.router)
app.include_router(documents.router)
app.include_router(deadlines.router)
app.include_router(applications.router)
app.include_router(users.router)


@app.get("/health", operation_id="health_check", summary="Health check", description="Return service health status", tags=["Health"])
async def health_check():
    return {"status": "ok"}


if __name__ == "__main__":
    host = os.getenv("HOST", "127.0.0.1")
    port = int(os.getenv("PORT", "8000"))
    uvicorn.run(app, host=host, port=port)