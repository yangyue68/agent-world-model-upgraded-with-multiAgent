from datetime import datetime
from fastapi import APIRouter, Body, HTTPException
from sqlalchemy.exc import IntegrityError
from database import SessionLocal
from models import Form, FormSection, SectionField, ApplicationSectionEntry, ApplicationSectionEntryValue
from schemas import FormSectionOut, FormSectionCreate, FormSectionUpdate, FormSectionListOut, DeleteResponse

router = APIRouter(prefix="/api/forms", tags=["FormSections"])


@router.get("/{form_id}/sections", response_model=FormSectionListOut, operation_id="list_form_sections", summary="List all sections for a form", description="Retrieve all form sections for the given form, ordered by display_order.")
async def list_form_sections(form_id: int):
    session = SessionLocal()
    form = session.query(Form).filter(Form.id == form_id).first()
    if not form:
        session.close()
        raise HTTPException(status_code=404, detail="Form not found")
    sections = session.query(FormSection).filter(FormSection.form_id == form_id).order_by(FormSection.display_order, FormSection.id).all()
    result = FormSectionListOut(sections=[FormSectionOut.model_validate(s, from_attributes=True) for s in sections])
    session.close()
    return result


@router.post("/{form_id}/sections", response_model=FormSectionOut, operation_id="create_form_section", summary="Create a new form section", description="Add a new section to the specified form.")
async def create_form_section(form_id: int, payload: FormSectionCreate = Body(...)):
    session = SessionLocal()
    form = session.query(Form).filter(Form.id == form_id).first()
    if not form:
        session.close()
        raise HTTPException(status_code=404, detail="Form not found")
    section = FormSection(
        form_id=form_id,
        name=payload.name,
        description=payload.description,
        is_optional=payload.is_optional if payload.is_optional is not None else 0,
        max_entries=payload.max_entries,
        display_order=payload.display_order if payload.display_order is not None else 0,
        created_at=datetime.utcnow(),
        updated_at=datetime.utcnow(),
    )
    session.add(section)
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Section name must be unique per form")
    session.refresh(section)
    result = FormSectionOut.model_validate(section, from_attributes=True)
    session.close()
    return result


@router.get("/{form_id}/sections/{section_id}", response_model=FormSectionOut, operation_id="get_form_section", summary="Get a specific form section", description="Retrieve details of a single form section by ID.")
async def get_form_section(form_id: int, section_id: int):
    session = SessionLocal()
    section = session.query(FormSection).filter(FormSection.id == section_id, FormSection.form_id == form_id).first()
    if not section:
        session.close()
        raise HTTPException(status_code=404, detail="Section not found")
    result = FormSectionOut.model_validate(section, from_attributes=True)
    session.close()
    return result


@router.put("/{form_id}/sections/{section_id}", response_model=FormSectionOut, operation_id="update_form_section", summary="Update a form section", description="Replace all fields of an existing form section.")
async def update_form_section(form_id: int, section_id: int, payload: FormSectionUpdate = Body(...)):
    session = SessionLocal()
    section = session.query(FormSection).filter(FormSection.id == section_id, FormSection.form_id == form_id).first()
    if not section:
        session.close()
        raise HTTPException(status_code=404, detail="Section not found")
    if payload.name is not None:
        section.name = payload.name
    if payload.description is not None:
        section.description = payload.description
    if payload.is_optional is not None:
        section.is_optional = payload.is_optional
    if payload.max_entries is not None:
        section.max_entries = payload.max_entries
    if payload.display_order is not None:
        section.display_order = payload.display_order
    section.updated_at = datetime.utcnow()
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Section name must be unique per form")
    session.refresh(section)
    result = FormSectionOut.model_validate(section, from_attributes=True)
    session.close()
    return result


@router.delete("/{form_id}/sections/{section_id}", response_model=DeleteResponse, operation_id="delete_form_section", summary="Delete a form section", description="Remove a form section and all its associated fields and entries.")
async def delete_form_section(form_id: int, section_id: int):
    session = SessionLocal()
    section = session.query(FormSection).filter(FormSection.id == section_id, FormSection.form_id == form_id).first()
    if not section:
        session.close()
        raise HTTPException(status_code=404, detail="Section not found")
    session.delete(section)
    session.commit()
    session.close()
    return DeleteResponse(message="Section deleted successfully")