from datetime import datetime
from fastapi import APIRouter, Body, HTTPException
from sqlalchemy.exc import IntegrityError
from database import SessionLocal
from models import Form, FormDocument, FormQuestion, Application, ApplicationDocument
from schemas import FormDocumentOut, FormDocumentCreate, FormDocumentUpdate, FormDocumentListOut, DeleteResponse

router = APIRouter(tags=["FormDocuments"])


@router.get("/api/forms/{form_id}/documents", response_model=FormDocumentListOut, operation_id="list_form_documents", summary="List documents for a form", description="Retrieve all form_documents for the given form, including conditional document metadata.")
async def list_form_documents(form_id: int):
    session = SessionLocal()
    form = session.query(Form).filter(Form.id == form_id).first()
    if not form:
        session.close()
        raise HTTPException(status_code=404, detail="Form not found")
    documents = session.query(FormDocument).filter(FormDocument.form_id == form_id).order_by(FormDocument.id).all()
    result = FormDocumentListOut(documents=[FormDocumentOut.model_validate(d, from_attributes=True) for d in documents])
    session.close()
    return result


@router.post("/api/forms/{form_id}/documents", response_model=FormDocumentOut, operation_id="create_form_document", summary="Create a document requirement for a form", description="Insert a new form_documents row, optionally with a conditional question and value.")
async def create_form_document(form_id: int, payload: FormDocumentCreate = Body(...)):
    session = SessionLocal()
    form = session.query(Form).filter(Form.id == form_id).first()
    if not form:
        session.close()
        raise HTTPException(status_code=404, detail="Form not found")
    if payload.condition_question_id is not None:
        question = session.query(FormQuestion).filter(FormQuestion.id == payload.condition_question_id, FormQuestion.form_id == form_id).first()
        if not question:
            session.close()
            raise HTTPException(status_code=400, detail="Condition question not found on this form")
    document = FormDocument(
        form_id=form_id,
        name=payload.name,
        description=payload.description,
        is_required=payload.is_required if payload.is_required is not None else 0,
        condition_question_id=payload.condition_question_id,
        condition_value=payload.condition_value,
        created_at=datetime.utcnow(),
        updated_at=datetime.utcnow(),
    )
    session.add(document)
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Document name must be unique per form")
    session.refresh(document)
    result = FormDocumentOut.model_validate(document, from_attributes=True)
    session.close()
    return result


@router.get("/api/forms/{form_id}/documents/{document_id}", response_model=FormDocumentOut, operation_id="get_form_document", summary="Get a single form document", description="Retrieve one form_documents row by ID, scoped to the given form.")
async def get_form_document(form_id: int, document_id: int):
    session = SessionLocal()
    document = session.query(FormDocument).filter(FormDocument.id == document_id, FormDocument.form_id == form_id).first()
    if not document:
        session.close()
        raise HTTPException(status_code=404, detail="Document not found")
    result = FormDocumentOut.model_validate(document, from_attributes=True)
    session.close()
    return result


@router.put("/api/forms/{form_id}/documents/{document_id}", response_model=FormDocumentOut, operation_id="update_form_document", summary="Replace a form document requirement", description="Update all mutable fields of a form_documents row, including conditional gating.")
async def update_form_document(form_id: int, document_id: int, payload: FormDocumentUpdate = Body(...)):
    session = SessionLocal()
    document = session.query(FormDocument).filter(FormDocument.id == document_id, FormDocument.form_id == form_id).first()
    if not document:
        session.close()
        raise HTTPException(status_code=404, detail="Document not found")
    if payload.name is not None:
        document.name = payload.name
    if payload.description is not None:
        document.description = payload.description
    if payload.is_required is not None:
        document.is_required = payload.is_required
    if payload.condition_question_id is not None:
        document.condition_question_id = payload.condition_question_id
    if payload.condition_value is not None:
        document.condition_value = payload.condition_value
    document.updated_at = datetime.utcnow()
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Document name must be unique per form")
    session.refresh(document)
    result = FormDocumentOut.model_validate(document, from_attributes=True)
    session.close()
    return result


@router.patch("/api/forms/{form_id}/documents/{document_id}", response_model=FormDocumentOut, operation_id="patch_form_document", summary="Partially update a form document", description="Update selected fields of a form_documents row, e.g. toggle is_required or gating.")
async def patch_form_document(form_id: int, document_id: int, payload: FormDocumentUpdate = Body(...)):
    session = SessionLocal()
    document = session.query(FormDocument).filter(FormDocument.id == document_id, FormDocument.form_id == form_id).first()
    if not document:
        session.close()
        raise HTTPException(status_code=404, detail="Document not found")
    if payload.name is not None:
        document.name = payload.name
    if payload.description is not None:
        document.description = payload.description
    if payload.is_required is not None:
        document.is_required = payload.is_required
    if payload.condition_question_id is not None:
        document.condition_question_id = payload.condition_question_id
    if payload.condition_value is not None:
        document.condition_value = payload.condition_value
    document.updated_at = datetime.utcnow()
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Document name must be unique per form")
    session.refresh(document)
    result = FormDocumentOut.model_validate(document, from_attributes=True)
    session.close()
    return result


@router.delete("/api/forms/{form_id}/documents/{document_id}", response_model=DeleteResponse, operation_id="delete_form_document", summary="Delete a form document requirement", description="Remove a form_documents row; cascades to application_documents for that document.")
async def delete_form_document(form_id: int, document_id: int):
    session = SessionLocal()
    document = session.query(FormDocument).filter(FormDocument.id == document_id, FormDocument.form_id == form_id).first()
    if not document:
        session.close()
        raise HTTPException(status_code=404, detail="Document not found")
    session.delete(document)
    session.commit()
    session.close()
    return DeleteResponse(message="Document deleted successfully")


@router.get("/api/applications/{application_id}/documents", response_model=FormDocumentListOut, operation_id="list_application_documents", summary="List uploaded documents for an application", description="Retrieve application_documents rows for the given application, joined with form_documents metadata.")
async def list_application_documents(application_id: int):
    session = SessionLocal()
    application = session.query(Application).filter(Application.id == application_id).first()
    if not application:
        session.close()
        raise HTTPException(status_code=404, detail="Application not found")
    docs = session.query(ApplicationDocument).filter(ApplicationDocument.application_id == application_id).order_by(ApplicationDocument.id).all()
    result = FormDocumentListOut(documents=[FormDocumentOut.model_validate(d, from_attributes=True) for d in docs])
    session.close()
    return result


@router.post("/api/applications/{application_id}/documents", response_model=FormDocumentOut, operation_id="create_application_document", summary="Upload a document for an application", description="Insert an application_documents row linking an uploaded file to a form_documents requirement.")
async def create_application_document(application_id: int, payload: FormDocumentCreate = Body(...)):
    session = SessionLocal()
    application = session.query(Application).filter(Application.id == application_id).first()
    if not application:
        session.close()
        raise HTTPException(status_code=404, detail="Application not found")
    document = FormDocument(
        form_id=application.form_id,
        name=payload.name,
        description=payload.description,
        is_required=payload.is_required if payload.is_required is not None else 0,
        condition_question_id=payload.condition_question_id,
        condition_value=payload.condition_value,
        created_at=datetime.utcnow(),
        updated_at=datetime.utcnow(),
    )
    session.add(document)
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Document name must be unique per form")
    session.refresh(document)
    result = FormDocumentOut.model_validate(document, from_attributes=True)
    session.close()
    return result


@router.get("/api/applications/{application_id}/documents/{application_document_id}", response_model=FormDocumentOut, operation_id="get_application_document", summary="Get an uploaded application document", description="Retrieve one application_documents row by ID, scoped to the given application.")
async def get_application_document(application_id: int, application_document_id: int):
    session = SessionLocal()
    document = session.query(FormDocument).filter(FormDocument.id == application_document_id).first()
    if not document:
        session.close()
        raise HTTPException(status_code=404, detail="Document not found")
    result = FormDocumentOut.model_validate(document, from_attributes=True)
    session.close()
    return result


@router.put("/api/applications/{application_id}/documents/{application_document_id}", response_model=FormDocumentOut, operation_id="update_application_document", summary="Replace an uploaded application document", description="Update the file_path and/or document_id of an application_documents row.")
async def update_application_document(application_id: int, application_document_id: int, payload: FormDocumentUpdate = Body(...)):
    session = SessionLocal()
    document = session.query(FormDocument).filter(FormDocument.id == application_document_id).first()
    if not document:
        session.close()
        raise HTTPException(status_code=404, detail="Document not found")
    if payload.name is not None:
        document.name = payload.name
    if payload.description is not None:
        document.description = payload.description
    if payload.is_required is not None:
        document.is_required = payload.is_required
    if payload.condition_question_id is not None:
        document.condition_question_id = payload.condition_question_id
    if payload.condition_value is not None:
        document.condition_value = payload.condition_value
    document.updated_at = datetime.utcnow()
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Document name must be unique per form")
    session.refresh(document)
    result = FormDocumentOut.model_validate(document, from_attributes=True)
    session.close()
    return result


@router.patch("/api/applications/{application_id}/documents/{application_document_id}", response_model=FormDocumentOut, operation_id="patch_application_document", summary="Partially update an uploaded application document", description="Update selected fields of an application_documents row, e.g. replace only the file_path.")
async def patch_application_document(application_id: int, application_document_id: int, payload: FormDocumentUpdate = Body(...)):
    session = SessionLocal()
    document = session.query(FormDocument).filter(FormDocument.id == application_document_id).first()
    if not document:
        session.close()
        raise HTTPException(status_code=404, detail="Document not found")
    if payload.name is not None:
        document.name = payload.name
    if payload.description is not None:
        document.description = payload.description
    if payload.is_required is not None:
        document.is_required = payload.is_required
    if payload.condition_question_id is not None:
        document.condition_question_id = payload.condition_question_id
    if payload.condition_value is not None:
        document.condition_value = payload.condition_value
    document.updated_at = datetime.utcnow()
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Document name must be unique per form")
    session.refresh(document)
    result = FormDocumentOut.model_validate(document, from_attributes=True)
    session.close()
    return result


@router.delete("/api/applications/{application_id}/documents/{application_document_id}", response_model=DeleteResponse, operation_id="delete_application_document", summary="Delete an uploaded application document", description="Remove an application_documents row, unlinking the uploaded file from the application.")
async def delete_application_document(application_id: int, application_document_id: int):
    session = SessionLocal()
    document = session.query(FormDocument).filter(FormDocument.id == application_document_id).first()
    if not document:
        session.close()
        raise HTTPException(status_code=404, detail="Document not found")
    session.delete(document)
    session.commit()
    session.close()
    return DeleteResponse(message="Document deleted successfully")