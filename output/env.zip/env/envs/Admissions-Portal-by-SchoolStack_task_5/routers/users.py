from datetime import datetime
from fastapi import APIRouter, Body, HTTPException
from sqlalchemy.exc import IntegrityError
from database import SessionLocal
from models import User
from schemas import UserOut, UserCreate, UserUpdate, DeleteResponse

router = APIRouter(prefix="/api/users", tags=["Users"])


@router.get("", response_model=list[UserOut], operation_id="list_users", summary="List all users", description="Retrieve all users in the system.")
async def list_users():
    session = SessionLocal()
    users = session.query(User).order_by(User.id).all()
    result = [UserOut.model_validate(u, from_attributes=True) for u in users]
    session.close()
    return result


@router.post("", response_model=UserOut, operation_id="create_user", summary="Create a new user", description="Create a new user with username, full name, and email.")
async def create_user(payload: UserCreate = Body(...)):
    session = SessionLocal()
    user = User(
        username=payload.username,
        full_name=payload.full_name,
        email=payload.email,
        created_at=datetime.utcnow(),
        updated_at=datetime.utcnow(),
    )
    session.add(user)
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Username or email already exists")
    session.refresh(user)
    result = UserOut.model_validate(user, from_attributes=True)
    session.close()
    return result


@router.get("/{user_id}", response_model=UserOut, operation_id="get_user", summary="Get a user by ID", description="Retrieve a single user by their ID.")
async def get_user(user_id: int):
    session = SessionLocal()
    user = session.query(User).filter(User.id == user_id).first()
    if not user:
        session.close()
        raise HTTPException(status_code=404, detail="User not found")
    result = UserOut.model_validate(user, from_attributes=True)
    session.close()
    return result


@router.put("/{user_id}", response_model=UserOut, operation_id="update_user", summary="Update a user", description="Update the details of an existing user.")
async def update_user(user_id: int, payload: UserUpdate = Body(...)):
    session = SessionLocal()
    user = session.query(User).filter(User.id == user_id).first()
    if not user:
        session.close()
        raise HTTPException(status_code=404, detail="User not found")
    if payload.username is not None:
        user.username = payload.username
    if payload.full_name is not None:
        user.full_name = payload.full_name
    if payload.email is not None:
        user.email = payload.email
    user.updated_at = datetime.utcnow()
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Username or email already exists")
    session.refresh(user)
    result = UserOut.model_validate(user, from_attributes=True)
    session.close()
    return result


@router.delete("/{user_id}", response_model=DeleteResponse, operation_id="delete_user", summary="Delete a user", description="Delete a user and all associated data.")
async def delete_user(user_id: int):
    session = SessionLocal()
    user = session.query(User).filter(User.id == user_id).first()
    if not user:
        session.close()
        raise HTTPException(status_code=404, detail="User not found")
    session.delete(user)
    session.commit()
    session.close()
    return DeleteResponse(message="User deleted successfully")