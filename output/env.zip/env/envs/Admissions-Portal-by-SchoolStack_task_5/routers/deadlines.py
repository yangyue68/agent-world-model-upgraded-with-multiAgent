from datetime import datetime
from fastapi import APIRouter, Body, HTTPException
from sqlalchemy.exc import IntegrityError
from database import SessionLocal
from models import Form, FormDeadline
from schemas import FormDeadlineOut, FormDeadlineCreate, FormDeadlineUpdate, FormDeadlineListOut, DeleteResponse

router = APIRouter(prefix="/api/forms", tags=["FormDeadlines"])


@router.get("/{form_id}/deadlines", response_model=FormDeadlineListOut, operation_id="list_form_deadlines", summary="List all deadlines for a form", description="Retrieve all deadline records associated with the specified form.")
async def list_form_deadlines(form_id: int):
    session = SessionLocal()
    form = session.query(Form).filter(Form.id == form_id).first()
    if not form:
        session.close()
        raise HTTPException(status_code=404, detail="Form not found")
    deadlines = session.query(FormDeadline).filter(FormDeadline.form_id == form_id).order_by(FormDeadline.id).all()
    result = FormDeadlineListOut(deadlines=[FormDeadlineOut.model_validate(d, from_attributes=True) for d in deadlines])
    session.close()
    return result


@router.post("/{form_id}/deadlines", response_model=FormDeadlineOut, operation_id="create_form_deadline", summary="Create a new deadline for a form", description="Add a new deadline record to the specified form.")
async def create_form_deadline(form_id: int, payload: FormDeadlineCreate = Body(...)):
    session = SessionLocal()
    form = session.query(Form).filter(Form.id == form_id).first()
    if not form:
        session.close()
        raise HTTPException(status_code=404, detail="Form not found")
    deadline = FormDeadline(
        form_id=form_id,
        deadline_type=payload.deadline_type,
        deadline_date=payload.deadline_date,
        created_at=datetime.utcnow(),
        updated_at=datetime.utcnow(),
    )
    session.add(deadline)
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Deadline type must be unique per form")
    session.refresh(deadline)
    result = FormDeadlineOut.model_validate(deadline, from_attributes=True)
    session.close()
    return result


@router.get("/{form_id}/deadlines/{deadline_type}", response_model=FormDeadlineOut, operation_id="get_form_deadline_by_type", summary="Get a specific deadline by type for a form", description="Retrieve a single deadline record identified by form ID and deadline type.")
async def get_form_deadline_by_type(form_id: int, deadline_type: str):
    session = SessionLocal()
    deadline = session.query(FormDeadline).filter(FormDeadline.form_id == form_id, FormDeadline.deadline_type == deadline_type).first()
    if not deadline:
        session.close()
        raise HTTPException(status_code=404, detail="Deadline not found")
    result = FormDeadlineOut.model_validate(deadline, from_attributes=True)
    session.close()
    return result


@router.put("/{form_id}/deadlines/{deadline_type}", response_model=FormDeadlineOut, operation_id="update_form_deadline", summary="Update a deadline for a form", description="Replace the deadline date for a specific deadline type of a form.")
async def update_form_deadline(form_id: int, deadline_type: str, payload: FormDeadlineUpdate = Body(...)):
    session = SessionLocal()
    deadline = session.query(FormDeadline).filter(FormDeadline.form_id == form_id, FormDeadline.deadline_type == deadline_type).first()
    if not deadline:
        session.close()
        raise HTTPException(status_code=404, detail="Deadline not found")
    if payload.deadline_type is not None:
        deadline.deadline_type = payload.deadline_type
    if payload.deadline_date is not None:
        deadline.deadline_date = payload.deadline_date
    deadline.updated_at = datetime.utcnow()
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Deadline type must be unique per form")
    session.refresh(deadline)
    result = FormDeadlineOut.model_validate(deadline, from_attributes=True)
    session.close()
    return result


@router.delete("/{form_id}/deadlines/{deadline_type}", response_model=DeleteResponse, operation_id="delete_form_deadline", summary="Delete a deadline for a form", description="Remove a specific deadline record from a form.")
async def delete_form_deadline(form_id: int, deadline_type: str):
    session = SessionLocal()
    deadline = session.query(FormDeadline).filter(FormDeadline.form_id == form_id, FormDeadline.deadline_type == deadline_type).first()
    if not deadline:
        session.close()
        raise HTTPException(status_code=404, detail="Deadline not found")
    session.delete(deadline)
    session.commit()
    session.close()
    return DeleteResponse(message="Deadline deleted successfully")