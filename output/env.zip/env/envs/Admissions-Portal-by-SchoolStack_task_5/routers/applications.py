from datetime import datetime
from typing import Optional
from fastapi import APIRouter, Body, HTTPException, Query
from sqlalchemy.exc import IntegrityError
from database import SessionLocal
from models import Application, ApplicationAnswer, ApplicationSectionEntry, ApplicationSectionEntryValue, ApplicationDocument, Form, FormQuestion, FormSection, SectionField, FormDocument
from schemas import (
    ApplicationOut, ApplicationCreate, ApplicationUpdate, ApplicationListOut,
    ApplicationAnswerOut, ApplicationAnswerCreate, ApplicationAnswerUpdate, ApplicationAnswerListOut,
    ApplicationSectionEntryOut, ApplicationSectionEntryCreate, ApplicationSectionEntryUpdate, ApplicationSectionEntryListOut,
    ApplicationSectionEntryValueOut, ApplicationSectionEntryValueCreate, ApplicationSectionEntryValueUpdate, ApplicationSectionEntryValueListOut,
    ApplicationDocumentOut, ApplicationDocumentCreate, ApplicationDocumentUpdate, ApplicationDocumentListOut,
    DeleteResponse,
)

router = APIRouter(prefix="/api/applications", tags=["Applications"])


@router.get("", response_model=ApplicationListOut, operation_id="list_applications", summary="List applications for the current user", description="Retrieve all applications belonging to the current user (applicant_id=1).")
async def list_applications(status: Optional[str] = Query(None), form_id: Optional[int] = Query(None)):
    session = SessionLocal()
    query = session.query(Application).filter(Application.applicant_id == 1)
    if status is not None:
        query = query.filter(Application.status == status)
    if form_id is not None:
        query = query.filter(Application.form_id == form_id)
    applications = query.order_by(Application.id).all()
    result = ApplicationListOut(applications=[ApplicationOut.model_validate(a, from_attributes=True) for a in applications])
    session.close()
    return result


@router.post("", response_model=ApplicationOut, operation_id="create_application", summary="Create a new application", description="Create a new application for the current user (applicant_id=1) for a given form.")
async def create_application(payload: ApplicationCreate = Body(...)):
    session = SessionLocal()
    form = session.query(Form).filter(Form.id == payload.form_id).first()
    if not form:
        session.close()
        raise HTTPException(status_code=404, detail="Form not found")
    application = Application(
        form_id=payload.form_id,
        applicant_id=payload.applicant_id or 1,
        status="draft",
        created_at=datetime.utcnow(),
        updated_at=datetime.utcnow(),
    )
    session.add(application)
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Invalid application data")
    session.refresh(application)
    result = ApplicationOut.model_validate(application, from_attributes=True)
    session.close()
    return result


@router.get("/{application_id}", response_model=ApplicationOut, operation_id="get_application", summary="Get a single application", description="Retrieve details of an application owned by the current user (applicant_id=1).")
async def get_application(application_id: int):
    session = SessionLocal()
    application = session.query(Application).filter(Application.id == application_id, Application.applicant_id == 1).first()
    if not application:
        session.close()
        raise HTTPException(status_code=404, detail="Application not found")
    result = ApplicationOut.model_validate(application, from_attributes=True)
    session.close()
    return result


@router.put("/{application_id}", response_model=ApplicationOut, operation_id="update_application", summary="Update an application", description="Update status or submitted_at of an application owned by the current user (applicant_id=1).")
async def update_application(application_id: int, payload: ApplicationUpdate = Body(...)):
    session = SessionLocal()
    application = session.query(Application).filter(Application.id == application_id, Application.applicant_id == 1).first()
    if not application:
        session.close()
        raise HTTPException(status_code=404, detail="Application not found")
    if payload.status is not None:
        application.status = payload.status
    if payload.submitted_at is not None:
        application.submitted_at = payload.submitted_at
    application.updated_at = datetime.utcnow()
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Invalid application data")
    session.refresh(application)
    result = ApplicationOut.model_validate(application, from_attributes=True)
    session.close()
    return result


@router.delete("/{application_id}", response_model=DeleteResponse, operation_id="delete_application", summary="Delete an application", description="Delete an application owned by the current user (applicant_id=1).")
async def delete_application(application_id: int):
    session = SessionLocal()
    application = session.query(Application).filter(Application.id == application_id, Application.applicant_id == 1).first()
    if not application:
        session.close()
        raise HTTPException(status_code=404, detail="Application not found")
    session.delete(application)
    session.commit()
    session.close()
    return DeleteResponse(message="Application deleted successfully")


@router.get("/{application_id}/answers", response_model=ApplicationAnswerListOut, operation_id="list_application_answers", summary="List answers for an application", description="Retrieve all answers for an application owned by the current user (applicant_id=1).")
async def list_application_answers(application_id: int):
    session = SessionLocal()
    application = session.query(Application).filter(Application.id == application_id, Application.applicant_id == 1).first()
    if not application:
        session.close()
        raise HTTPException(status_code=404, detail="Application not found")
    answers = session.query(ApplicationAnswer).filter(ApplicationAnswer.application_id == application_id).order_by(ApplicationAnswer.id).all()
    result = ApplicationAnswerListOut(answers=[ApplicationAnswerOut.model_validate(a, from_attributes=True) for a in answers])
    session.close()
    return result


@router.post("/{application_id}/answers", response_model=ApplicationAnswerOut, operation_id="upsert_application_answer", summary="Create or update an answer", description="Upsert an answer for a question in an application owned by the current user (applicant_id=1).")
async def upsert_application_answer(application_id: int, payload: ApplicationAnswerCreate = Body(...)):
    session = SessionLocal()
    application = session.query(Application).filter(Application.id == application_id, Application.applicant_id == 1).first()
    if not application:
        session.close()
        raise HTTPException(status_code=404, detail="Application not found")
    question = session.query(FormQuestion).filter(FormQuestion.id == payload.question_id).first()
    if not question:
        session.close()
        raise HTTPException(status_code=404, detail="Question not found")
    answer = session.query(ApplicationAnswer).filter(ApplicationAnswer.application_id == application_id, ApplicationAnswer.question_id == payload.question_id).first()
    if answer:
        answer.answer_value = payload.answer_value
        answer.updated_at = datetime.utcnow()
    else:
        answer = ApplicationAnswer(
            application_id=application_id,
            question_id=payload.question_id,
            answer_value=payload.answer_value,
            created_at=datetime.utcnow(),
            updated_at=datetime.utcnow(),
        )
        session.add(answer)
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Invalid answer data")
    session.refresh(answer)
    result = ApplicationAnswerOut.model_validate(answer, from_attributes=True)
    session.close()
    return result


@router.put("/{application_id}/answers/{answer_id}", response_model=ApplicationAnswerOut, operation_id="update_application_answer", summary="Update an answer", description="Update an existing answer for an application owned by the current user (applicant_id=1).")
async def update_application_answer(application_id: int, answer_id: int, payload: ApplicationAnswerUpdate = Body(...)):
    session = SessionLocal()
    application = session.query(Application).filter(Application.id == application_id, Application.applicant_id == 1).first()
    if not application:
        session.close()
        raise HTTPException(status_code=404, detail="Application not found")
    answer = session.query(ApplicationAnswer).filter(ApplicationAnswer.id == answer_id, ApplicationAnswer.application_id == application_id).first()
    if not answer:
        session.close()
        raise HTTPException(status_code=404, detail="Answer not found")
    if payload.question_id is not None:
        answer.question_id = payload.question_id
    if payload.answer_value is not None:
        answer.answer_value = payload.answer_value
    answer.updated_at = datetime.utcnow()
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Invalid answer data")
    session.refresh(answer)
    result = ApplicationAnswerOut.model_validate(answer, from_attributes=True)
    session.close()
    return result


@router.delete("/{application_id}/answers/{answer_id}", response_model=DeleteResponse, operation_id="delete_application_answer", summary="Delete an answer", description="Delete an answer from an application owned by the current user (applicant_id=1).")
async def delete_application_answer(application_id: int, answer_id: int):
    session = SessionLocal()
    application = session.query(Application).filter(Application.id == application_id, Application.applicant_id == 1).first()
    if not application:
        session.close()
        raise HTTPException(status_code=404, detail="Application not found")
    answer = session.query(ApplicationAnswer).filter(ApplicationAnswer.id == answer_id, ApplicationAnswer.application_id == application_id).first()
    if not answer:
        session.close()
        raise HTTPException(status_code=404, detail="Answer not found")
    session.delete(answer)
    session.commit()
    session.close()
    return DeleteResponse(message="Answer deleted successfully")


@router.get("/{application_id}/section-entries", response_model=ApplicationSectionEntryListOut, operation_id="list_application_section_entries", summary="List section entries for an application", description="Retrieve all section entries for an application owned by the current user (applicant_id=1).")
async def list_application_section_entries(application_id: int, section_id: Optional[int] = Query(None)):
    session = SessionLocal()
    application = session.query(Application).filter(Application.id == application_id, Application.applicant_id == 1).first()
    if not application:
        session.close()
        raise HTTPException(status_code=404, detail="Application not found")
    query = session.query(ApplicationSectionEntry).filter(ApplicationSectionEntry.application_id == application_id)
    if section_id is not None:
        query = query.filter(ApplicationSectionEntry.section_id == section_id)
    entries = query.order_by(ApplicationSectionEntry.entry_index).all()
    result = ApplicationSectionEntryListOut(section_entries=[ApplicationSectionEntryOut.model_validate(e, from_attributes=True) for e in entries])
    session.close()
    return result


@router.post("/{application_id}/section-entries", response_model=ApplicationSectionEntryOut, operation_id="create_application_section_entry", summary="Create a section entry", description="Create a new section entry for an application owned by the current user (applicant_id=1).")
async def create_application_section_entry(application_id: int, payload: ApplicationSectionEntryCreate = Body(...)):
    session = SessionLocal()
    application = session.query(Application).filter(Application.id == application_id, Application.applicant_id == 1).first()
    if not application:
        session.close()
        raise HTTPException(status_code=404, detail="Application not found")
    section = session.query(FormSection).filter(FormSection.id == payload.section_id).first()
    if not section:
        session.close()
        raise HTTPException(status_code=404, detail="Section not found")
    entry = ApplicationSectionEntry(
        application_id=application_id,
        section_id=payload.section_id,
        entry_index=payload.entry_index,
        created_at=datetime.utcnow(),
        updated_at=datetime.utcnow(),
    )
    session.add(entry)
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Entry index must be unique per section and between 1 and 5")
    session.refresh(entry)
    result = ApplicationSectionEntryOut.model_validate(entry, from_attributes=True)
    session.close()
    return result


@router.put("/{application_id}/section-entries/{entry_id}", response_model=ApplicationSectionEntryOut, operation_id="update_application_section_entry", summary="Update a section entry", description="Update a section entry for an application owned by the current user (applicant_id=1).")
async def update_application_section_entry(application_id: int, entry_id: int, payload: ApplicationSectionEntryUpdate = Body(...)):
    session = SessionLocal()
    application = session.query(Application).filter(Application.id == application_id, Application.applicant_id == 1).first()
    if not application:
        session.close()
        raise HTTPException(status_code=404, detail="Application not found")
    entry = session.query(ApplicationSectionEntry).filter(ApplicationSectionEntry.id == entry_id, ApplicationSectionEntry.application_id == application_id).first()
    if not entry:
        session.close()
        raise HTTPException(status_code=404, detail="Section entry not found")
    if payload.entry_index is not None:
        entry.entry_index = payload.entry_index
    entry.updated_at = datetime.utcnow()
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Entry index must be unique per section and between 1 and 5")
    session.refresh(entry)
    result = ApplicationSectionEntryOut.model_validate(entry, from_attributes=True)
    session.close()
    return result


@router.delete("/{application_id}/section-entries/{entry_id}", response_model=DeleteResponse, operation_id="delete_application_section_entry", summary="Delete a section entry", description="Delete a section entry from an application owned by the current user (applicant_id=1).")
async def delete_application_section_entry(application_id: int, entry_id: int):
    session = SessionLocal()
    application = session.query(Application).filter(Application.id == application_id, Application.applicant_id == 1).first()
    if not application:
        session.close()
        raise HTTPException(status_code=404, detail="Application not found")
    entry = session.query(ApplicationSectionEntry).filter(ApplicationSectionEntry.id == entry_id, ApplicationSectionEntry.application_id == application_id).first()
    if not entry:
        session.close()
        raise HTTPException(status_code=404, detail="Section entry not found")
    session.delete(entry)
    session.commit()
    session.close()
    return DeleteResponse(message="Section entry deleted successfully")


@router.get("/{application_id}/section-entries/{entry_id}/values", response_model=ApplicationSectionEntryValueListOut, operation_id="list_application_section_entry_values", summary="List values for a section entry", description="Retrieve all field values for a section entry owned by the current user (applicant_id=1).")
async def list_application_section_entry_values(application_id: int, entry_id: int):
    session = SessionLocal()
    application = session.query(Application).filter(Application.id == application_id, Application.applicant_id == 1).first()
    if not application:
        session.close()
        raise HTTPException(status_code=404, detail="Application not found")
    entry = session.query(ApplicationSectionEntry).filter(ApplicationSectionEntry.id == entry_id, ApplicationSectionEntry.application_id == application_id).first()
    if not entry:
        session.close()
        raise HTTPException(status_code=404, detail="Section entry not found")
    values = session.query(ApplicationSectionEntryValue).filter(ApplicationSectionEntryValue.entry_id == entry_id).order_by(ApplicationSectionEntryValue.id).all()
    result = ApplicationSectionEntryValueListOut(values=[ApplicationSectionEntryValueOut.model_validate(v, from_attributes=True) for v in values])
    session.close()
    return result


@router.post("/{application_id}/section-entries/{entry_id}/values", response_model=ApplicationSectionEntryValueOut, operation_id="upsert_application_section_entry_value", summary="Create or update a section entry value", description="Upsert a field value for a section entry owned by the current user (applicant_id=1).")
async def upsert_application_section_entry_value(application_id: int, entry_id: int, payload: ApplicationSectionEntryValueCreate = Body(...)):
    session = SessionLocal()
    application = session.query(Application).filter(Application.id == application_id, Application.applicant_id == 1).first()
    if not application:
        session.close()
        raise HTTPException(status_code=404, detail="Application not found")
    entry = session.query(ApplicationSectionEntry).filter(ApplicationSectionEntry.id == entry_id, ApplicationSectionEntry.application_id == application_id).first()
    if not entry:
        session.close()
        raise HTTPException(status_code=404, detail="Section entry not found")
    field = session.query(SectionField).filter(SectionField.id == payload.field_id).first()
    if not field:
        session.close()
        raise HTTPException(status_code=404, detail="Field not found")
    value = session.query(ApplicationSectionEntryValue).filter(ApplicationSectionEntryValue.entry_id == entry_id, ApplicationSectionEntryValue.field_id == payload.field_id).first()
    if value:
        value.value = payload.value
        value.updated_at = datetime.utcnow()
    else:
        value = ApplicationSectionEntryValue(
            entry_id=entry_id,
            field_id=payload.field_id,
            value=payload.value,
            created_at=datetime.utcnow(),
            updated_at=datetime.utcnow(),
        )
        session.add(value)
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Invalid entry value data")
    session.refresh(value)
    result = ApplicationSectionEntryValueOut.model_validate(value, from_attributes=True)
    session.close()
    return result


@router.put("/{application_id}/section-entries/{entry_id}/values/{value_id}", response_model=ApplicationSectionEntryValueOut, operation_id="update_application_section_entry_value", summary="Update a section entry value", description="Update a field value for a section entry owned by the current user (applicant_id=1).")
async def update_application_section_entry_value(application_id: int, entry_id: int, value_id: int, payload: ApplicationSectionEntryValueUpdate = Body(...)):
    session = SessionLocal()
    application = session.query(Application).filter(Application.id == application_id, Application.applicant_id == 1).first()
    if not application:
        session.close()
        raise HTTPException(status_code=404, detail="Application not found")
    entry = session.query(ApplicationSectionEntry).filter(ApplicationSectionEntry.id == entry_id, ApplicationSectionEntry.application_id == application_id).first()
    if not entry:
        session.close()
        raise HTTPException(status_code=404, detail="Section entry not found")
    value = session.query(ApplicationSectionEntryValue).filter(ApplicationSectionEntryValue.id == value_id, ApplicationSectionEntryValue.entry_id == entry_id).first()
    if not value:
        session.close()
        raise HTTPException(status_code=404, detail="Entry value not found")
    if payload.field_id is not None:
        value.field_id = payload.field_id
    if payload.value is not None:
        value.value = payload.value
    value.updated_at = datetime.utcnow()
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Invalid entry value data")
    session.refresh(value)
    result = ApplicationSectionEntryValueOut.model_validate(value, from_attributes=True)
    session.close()
    return result


@router.delete("/{application_id}/section-entries/{entry_id}/values/{value_id}", response_model=DeleteResponse, operation_id="delete_application_section_entry_value", summary="Delete a section entry value", description="Delete a field value from a section entry owned by the current user (applicant_id=1).")
async def delete_application_section_entry_value(application_id: int, entry_id: int, value_id: int):
    session = SessionLocal()
    application = session.query(Application).filter(Application.id == application_id, Application.applicant_id == 1).first()
    if not application:
        session.close()
        raise HTTPException(status_code=404, detail="Application not found")
    entry = session.query(ApplicationSectionEntry).filter(ApplicationSectionEntry.id == entry_id, ApplicationSectionEntry.application_id == application_id).first()
    if not entry:
        session.close()
        raise HTTPException(status_code=404, detail="Section entry not found")
    value = session.query(ApplicationSectionEntryValue).filter(ApplicationSectionEntryValue.id == value_id, ApplicationSectionEntryValue.entry_id == entry_id).first()
    if not value:
        session.close()
        raise HTTPException(status_code=404, detail="Entry value not found")
    session.delete(value)
    session.commit()
    session.close()
    return DeleteResponse(message="Entry value deleted successfully")


@router.get("/{application_id}/documents", response_model=ApplicationDocumentListOut, operation_id="list_application_documents_by_app", summary="List documents for an application", description="Retrieve all uploaded documents for an application owned by the current user (applicant_id=1).")
async def list_application_documents_by_app(application_id: int):
    session = SessionLocal()
    application = session.query(Application).filter(Application.id == application_id, Application.applicant_id == 1).first()
    if not application:
        session.close()
        raise HTTPException(status_code=404, detail="Application not found")
    documents = session.query(ApplicationDocument).filter(ApplicationDocument.application_id == application_id).order_by(ApplicationDocument.id).all()
    result = ApplicationDocumentListOut(documents=[ApplicationDocumentOut.model_validate(d, from_attributes=True) for d in documents])
    session.close()
    return result


@router.post("/{application_id}/documents", response_model=ApplicationDocumentOut, operation_id="upload_application_document", summary="Upload a document for an application", description="Upload a document for an application owned by the current user (applicant_id=1).")
async def upload_application_document(application_id: int, payload: ApplicationDocumentCreate = Body(...)):
    session = SessionLocal()
    application = session.query(Application).filter(Application.id == application_id, Application.applicant_id == 1).first()
    if not application:
        session.close()
        raise HTTPException(status_code=404, detail="Application not found")
    document = session.query(FormDocument).filter(FormDocument.id == payload.document_id).first()
    if not document:
        session.close()
        raise HTTPException(status_code=404, detail="Form document not found")
    app_doc = ApplicationDocument(
        application_id=application_id,
        document_id=payload.document_id,
        file_path=payload.file_path,
        uploaded_at=datetime.utcnow(),
        created_at=datetime.utcnow(),
        updated_at=datetime.utcnow(),
    )
    session.add(app_doc)
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Document already uploaded for this application")
    session.refresh(app_doc)
    result = ApplicationDocumentOut.model_validate(app_doc, from_attributes=True)
    session.close()
    return result


@router.put("/{application_id}/documents/{document_id}", response_model=ApplicationDocumentOut, operation_id="update_application_document_by_app", summary="Update an application document", description="Update file path of a document for an application owned by the current user (applicant_id=1).")
async def update_application_document_by_app(application_id: int, document_id: int, payload: ApplicationDocumentUpdate = Body(...)):
    session = SessionLocal()
    application = session.query(Application).filter(Application.id == application_id, Application.applicant_id == 1).first()
    if not application:
        session.close()
        raise HTTPException(status_code=404, detail="Application not found")
    app_doc = session.query(ApplicationDocument).filter(ApplicationDocument.id == document_id, ApplicationDocument.application_id == application_id).first()
    if not app_doc:
        session.close()
        raise HTTPException(status_code=404, detail="Application document not found")
    if payload.document_id is not None:
        app_doc.document_id = payload.document_id
    if payload.file_path is not None:
        app_doc.file_path = payload.file_path
    app_doc.updated_at = datetime.utcnow()
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Invalid application document data")
    session.refresh(app_doc)
    result = ApplicationDocumentOut.model_validate(app_doc, from_attributes=True)
    session.close()
    return result


@router.delete("/{application_id}/documents/{document_id}", response_model=DeleteResponse, operation_id="delete_application_document_by_app", summary="Delete an application document", description="Delete a document from an application owned by the current user (applicant_id=1).")
async def delete_application_document_by_app(application_id: int, document_id: int):
    session = SessionLocal()
    application = session.query(Application).filter(Application.id == application_id, Application.applicant_id == 1).first()
    if not application:
        session.close()
        raise HTTPException(status_code=404, detail="Application not found")
    app_doc = session.query(ApplicationDocument).filter(ApplicationDocument.id == document_id, ApplicationDocument.application_id == application_id).first()
    if not app_doc:
        session.close()
        raise HTTPException(status_code=404, detail="Application document not found")
    session.delete(app_doc)
    session.commit()
    session.close()
    return DeleteResponse(message="Application document deleted successfully")