from datetime import datetime
from fastapi import APIRouter, Body, HTTPException
from sqlalchemy.exc import IntegrityError
from database import SessionLocal
from models import Form, FormSection, SectionField, ApplicationSectionEntryValue
from schemas import SectionFieldOut, SectionFieldCreate, SectionFieldUpdate, SectionFieldListOut, DeleteResponse

router = APIRouter(tags=["SectionFields"])


@router.get("/api/forms/{form_id}/sections/{section_id}/fields", response_model=SectionFieldListOut, operation_id="list_section_fields", summary="List fields for a section", description="Retrieve all fields belonging to a specific form section.")
async def list_section_fields(form_id: int, section_id: int):
    session = SessionLocal()
    section = session.query(FormSection).filter(FormSection.id == section_id, FormSection.form_id == form_id).first()
    if not section:
        session.close()
        raise HTTPException(status_code=404, detail="Section not found")
    fields = session.query(SectionField).filter(SectionField.section_id == section_id).order_by(SectionField.display_order, SectionField.id).all()
    result = SectionFieldListOut(fields=[SectionFieldOut.model_validate(f, from_attributes=True) for f in fields])
    session.close()
    return result


@router.post("/api/forms/{form_id}/sections/{section_id}/fields", response_model=SectionFieldOut, operation_id="create_section_field", summary="Create a new field for a section", description="Add a new field to the specified form section.")
async def create_section_field(form_id: int, section_id: int, payload: SectionFieldCreate = Body(...)):
    session = SessionLocal()
    section = session.query(FormSection).filter(FormSection.id == section_id, FormSection.form_id == form_id).first()
    if not section:
        session.close()
        raise HTTPException(status_code=404, detail="Section not found")
    field = SectionField(
        section_id=section_id,
        field_name=payload.field_name,
        field_label=payload.field_label,
        field_type=payload.field_type,
        is_required=payload.is_required if payload.is_required is not None else 0,
        display_order=payload.display_order if payload.display_order is not None else 0,
        created_at=datetime.utcnow(),
        updated_at=datetime.utcnow(),
    )
    session.add(field)
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Field name must be unique per section")
    session.refresh(field)
    result = SectionFieldOut.model_validate(field, from_attributes=True)
    session.close()
    return result


@router.get("/api/forms/{form_id}/sections/{section_id}/fields/{field_id}", response_model=SectionFieldOut, operation_id="get_section_field", summary="Get a specific section field", description="Retrieve details of a single field within a section.")
async def get_section_field(form_id: int, section_id: int, field_id: int):
    session = SessionLocal()
    field = session.query(SectionField).filter(SectionField.id == field_id, SectionField.section_id == section_id).first()
    if not field:
        session.close()
        raise HTTPException(status_code=404, detail="Field not found")
    result = SectionFieldOut.model_validate(field, from_attributes=True)
    session.close()
    return result


@router.put("/api/forms/{form_id}/sections/{section_id}/fields/{field_id}", response_model=SectionFieldOut, operation_id="update_section_field", summary="Update a section field", description="Replace all fields of an existing section field.")
async def update_section_field(form_id: int, section_id: int, field_id: int, payload: SectionFieldUpdate = Body(...)):
    session = SessionLocal()
    field = session.query(SectionField).filter(SectionField.id == field_id, SectionField.section_id == section_id).first()
    if not field:
        session.close()
        raise HTTPException(status_code=404, detail="Field not found")
    if payload.field_name is not None:
        field.field_name = payload.field_name
    if payload.field_label is not None:
        field.field_label = payload.field_label
    if payload.field_type is not None:
        field.field_type = payload.field_type
    if payload.is_required is not None:
        field.is_required = payload.is_required
    if payload.display_order is not None:
        field.display_order = payload.display_order
    field.updated_at = datetime.utcnow()
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Field name must be unique per section")
    session.refresh(field)
    result = SectionFieldOut.model_validate(field, from_attributes=True)
    session.close()
    return result


@router.delete("/api/forms/{form_id}/sections/{section_id}/fields/{field_id}", response_model=DeleteResponse, operation_id="delete_section_field", summary="Delete a section field", description="Remove a field from a section and all associated entry values.")
async def delete_section_field(form_id: int, section_id: int, field_id: int):
    session = SessionLocal()
    field = session.query(SectionField).filter(SectionField.id == field_id, SectionField.section_id == section_id).first()
    if not field:
        session.close()
        raise HTTPException(status_code=404, detail="Field not found")
    session.delete(field)
    session.commit()
    session.close()
    return DeleteResponse(message="Field deleted successfully")


@router.get("/api/sections/{section_id}/fields", response_model=SectionFieldListOut, operation_id="list_section_fields_by_section", summary="List all fields in a section", description="Retrieve all section_fields for the given section ordered by display_order.")
async def list_section_fields_by_section(section_id: int):
    session = SessionLocal()
    section = session.query(FormSection).filter(FormSection.id == section_id).first()
    if not section:
        session.close()
        raise HTTPException(status_code=404, detail="Section not found")
    fields = session.query(SectionField).filter(SectionField.section_id == section_id).order_by(SectionField.display_order, SectionField.id).all()
    result = SectionFieldListOut(fields=[SectionFieldOut.model_validate(f, from_attributes=True) for f in fields])
    session.close()
    return result


@router.post("/api/sections/{section_id}/fields", response_model=SectionFieldOut, operation_id="create_section_field_by_section", summary="Create a new field in a section", description="Insert a new section_field into the given section with the provided attributes.")
async def create_section_field_by_section(section_id: int, payload: SectionFieldCreate = Body(...)):
    session = SessionLocal()
    section = session.query(FormSection).filter(FormSection.id == section_id).first()
    if not section:
        session.close()
        raise HTTPException(status_code=404, detail="Section not found")
    field = SectionField(
        section_id=section_id,
        field_name=payload.field_name,
        field_label=payload.field_label,
        field_type=payload.field_type,
        is_required=payload.is_required if payload.is_required is not None else 0,
        display_order=payload.display_order if payload.display_order is not None else 0,
        created_at=datetime.utcnow(),
        updated_at=datetime.utcnow(),
    )
    session.add(field)
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Field name must be unique per section")
    session.refresh(field)
    result = SectionFieldOut.model_validate(field, from_attributes=True)
    session.close()
    return result


@router.get("/api/sections/{section_id}/fields/{field_id}", response_model=SectionFieldOut, operation_id="get_section_field_by_section", summary="Get a single section field", description="Retrieve one section_field by its ID within the given section.")
async def get_section_field_by_section(section_id: int, field_id: int):
    session = SessionLocal()
    field = session.query(SectionField).filter(SectionField.id == field_id, SectionField.section_id == section_id).first()
    if not field:
        session.close()
        raise HTTPException(status_code=404, detail="Field not found")
    result = SectionFieldOut.model_validate(field, from_attributes=True)
    session.close()
    return result


@router.put("/api/sections/{section_id}/fields/{field_id}", response_model=SectionFieldOut, operation_id="replace_section_field", summary="Replace a section field", description="Fully update a section_field with the provided attributes.")
async def replace_section_field(section_id: int, field_id: int, payload: SectionFieldUpdate = Body(...)):
    session = SessionLocal()
    field = session.query(SectionField).filter(SectionField.id == field_id, SectionField.section_id == section_id).first()
    if not field:
        session.close()
        raise HTTPException(status_code=404, detail="Field not found")
    if payload.field_name is not None:
        field.field_name = payload.field_name
    if payload.field_label is not None:
        field.field_label = payload.field_label
    if payload.field_type is not None:
        field.field_type = payload.field_type
    if payload.is_required is not None:
        field.is_required = payload.is_required
    if payload.display_order is not None:
        field.display_order = payload.display_order
    field.updated_at = datetime.utcnow()
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Field name must be unique per section")
    session.refresh(field)
    result = SectionFieldOut.model_validate(field, from_attributes=True)
    session.close()
    return result


@router.patch("/api/sections/{section_id}/fields/{field_id}", response_model=SectionFieldOut, operation_id="patch_section_field", summary="Partially update a section field", description="Update one or more attributes of an existing section_field.")
async def patch_section_field(section_id: int, field_id: int, payload: SectionFieldUpdate = Body(...)):
    session = SessionLocal()
    field = session.query(SectionField).filter(SectionField.id == field_id, SectionField.section_id == section_id).first()
    if not field:
        session.close()
        raise HTTPException(status_code=404, detail="Field not found")
    if payload.field_name is not None:
        field.field_name = payload.field_name
    if payload.field_label is not None:
        field.field_label = payload.field_label
    if payload.field_type is not None:
        field.field_type = payload.field_type
    if payload.is_required is not None:
        field.is_required = payload.is_required
    if payload.display_order is not None:
        field.display_order = payload.display_order
    field.updated_at = datetime.utcnow()
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Field name must be unique per section")
    session.refresh(field)
    result = SectionFieldOut.model_validate(field, from_attributes=True)
    session.close()
    return result


@router.delete("/api/sections/{section_id}/fields/{field_id}", response_model=DeleteResponse, operation_id="delete_section_field_by_section", summary="Delete a section field", description="Remove a section_field and its associated entry values via cascade.")
async def delete_section_field_by_section(section_id: int, field_id: int):
    session = SessionLocal()
    field = session.query(SectionField).filter(SectionField.id == field_id, SectionField.section_id == section_id).first()
    if not field:
        session.close()
        raise HTTPException(status_code=404, detail="Field not found")
    session.delete(field)
    session.commit()
    session.close()
    return DeleteResponse(message="Field deleted successfully")