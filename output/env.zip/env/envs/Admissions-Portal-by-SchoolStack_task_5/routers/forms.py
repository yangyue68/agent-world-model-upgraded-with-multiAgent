from datetime import datetime
from typing import Optional
from fastapi import APIRouter, Body, HTTPException, Query
from sqlalchemy.exc import IntegrityError
from database import SessionLocal
from models import Form, FormSection, SectionField, FormQuestion, FormDocument, FormDeadline, Application, ApplicationAnswer, ApplicationSectionEntry, ApplicationSectionEntryValue, ApplicationDocument
from schemas import FormOut, FormCreate, FormUpdate, FormListOut, DeleteResponse

router = APIRouter(prefix="/api/forms", tags=["Forms"])


@router.get("", response_model=FormListOut, operation_id="list_forms", summary="List all forms", description="Retrieve all forms created by the current user.")
async def list_forms():
    session = SessionLocal()
    forms = session.query(Form).order_by(Form.id).all()
    result = FormListOut(forms=[FormOut.model_validate(f, from_attributes=True) for f in forms])
    session.close()
    return result


@router.post("", response_model=FormOut, operation_id="create_form", summary="Create a new form", description="Create a new form with the given name and description.")
async def create_form(payload: FormCreate = Body(...)):
    session = SessionLocal()
    form = Form(name=payload.name, description=payload.description, created_by=payload.created_by or 1, created_at=datetime.utcnow(), updated_at=datetime.utcnow())
    session.add(form)
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Invalid form data")
    session.refresh(form)
    result = FormOut.model_validate(form, from_attributes=True)
    session.close()
    return result


@router.get("/{form_id}", response_model=FormOut, operation_id="get_form", summary="Get a form by ID", description="Retrieve a single form by its ID.")
async def get_form(form_id: int):
    session = SessionLocal()
    form = session.query(Form).filter(Form.id == form_id).first()
    if not form:
        session.close()
        raise HTTPException(status_code=404, detail="Form not found")
    result = FormOut.model_validate(form, from_attributes=True)
    session.close()
    return result


@router.put("/{form_id}", response_model=FormOut, operation_id="update_form", summary="Update a form", description="Update the name and description of an existing form.")
async def update_form(form_id: int, payload: FormUpdate = Body(...)):
    session = SessionLocal()
    form = session.query(Form).filter(Form.id == form_id).first()
    if not form:
        session.close()
        raise HTTPException(status_code=404, detail="Form not found")
    if payload.name is not None:
        form.name = payload.name
    if payload.description is not None:
        form.description = payload.description
    form.updated_at = datetime.utcnow()
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Invalid form data")
    session.refresh(form)
    result = FormOut.model_validate(form, from_attributes=True)
    session.close()
    return result


@router.delete("/{form_id}", response_model=DeleteResponse, operation_id="delete_form", summary="Delete a form", description="Delete a form and all associated data.")
async def delete_form(form_id: int):
    session = SessionLocal()
    form = session.query(Form).filter(Form.id == form_id).first()
    if not form:
        session.close()
        raise HTTPException(status_code=404, detail="Form not found")
    session.delete(form)
    session.commit()
    session.close()
    return DeleteResponse(message="Form deleted successfully")