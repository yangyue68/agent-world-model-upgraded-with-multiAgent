from datetime import datetime
from fastapi import APIRouter, Body, HTTPException
from sqlalchemy.exc import IntegrityError
from database import SessionLocal
from models import Form, FormQuestion, ApplicationAnswer, FormDocument
from schemas import FormQuestionOut, FormQuestionCreate, FormQuestionUpdate, FormQuestionListOut, DeleteResponse

router = APIRouter(prefix="/api/forms", tags=["FormQuestions"])


@router.get("/{form_id}/questions", response_model=FormQuestionListOut, operation_id="list_form_questions", summary="List all questions for a form", description="Retrieve all form_questions for the given form ordered by display_order.")
async def list_form_questions(form_id: int):
    session = SessionLocal()
    form = session.query(Form).filter(Form.id == form_id).first()
    if not form:
        session.close()
        raise HTTPException(status_code=404, detail="Form not found")
    questions = session.query(FormQuestion).filter(FormQuestion.form_id == form_id).order_by(FormQuestion.display_order, FormQuestion.id).all()
    result = FormQuestionListOut(questions=[FormQuestionOut.model_validate(q, from_attributes=True) for q in questions])
    session.close()
    return result


@router.post("/{form_id}/questions", response_model=FormQuestionOut, operation_id="create_form_question", summary="Create a new question for a form", description="Insert a form_question row for the given form with the supplied fields.")
async def create_form_question(form_id: int, payload: FormQuestionCreate = Body(...)):
    session = SessionLocal()
    form = session.query(Form).filter(Form.id == form_id).first()
    if not form:
        session.close()
        raise HTTPException(status_code=404, detail="Form not found")
    question = FormQuestion(
        form_id=form_id,
        question_text=payload.question_text,
        question_type=payload.question_type,
        is_required=payload.is_required if payload.is_required is not None else 0,
        display_order=payload.display_order if payload.display_order is not None else 0,
        created_at=datetime.utcnow(),
        updated_at=datetime.utcnow(),
    )
    session.add(question)
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Invalid question data")
    session.refresh(question)
    result = FormQuestionOut.model_validate(question, from_attributes=True)
    session.close()
    return result


@router.get("/{form_id}/questions/{question_id}", response_model=FormQuestionOut, operation_id="get_form_question", summary="Get a single form question", description="Retrieve one form_question by its ID scoped to the given form.")
async def get_form_question(form_id: int, question_id: int):
    session = SessionLocal()
    question = session.query(FormQuestion).filter(FormQuestion.id == question_id, FormQuestion.form_id == form_id).first()
    if not question:
        session.close()
        raise HTTPException(status_code=404, detail="Question not found")
    result = FormQuestionOut.model_validate(question, from_attributes=True)
    session.close()
    return result


@router.put("/{form_id}/questions/{question_id}", response_model=FormQuestionOut, operation_id="replace_form_question", summary="Replace a form question", description="Fully update a form_question row with the supplied fields.")
async def replace_form_question(form_id: int, question_id: int, payload: FormQuestionUpdate = Body(...)):
    session = SessionLocal()
    question = session.query(FormQuestion).filter(FormQuestion.id == question_id, FormQuestion.form_id == form_id).first()
    if not question:
        session.close()
        raise HTTPException(status_code=404, detail="Question not found")
    if payload.question_text is not None:
        question.question_text = payload.question_text
    if payload.question_type is not None:
        question.question_type = payload.question_type
    if payload.is_required is not None:
        question.is_required = payload.is_required
    if payload.display_order is not None:
        question.display_order = payload.display_order
    question.updated_at = datetime.utcnow()
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Invalid question data")
    session.refresh(question)
    result = FormQuestionOut.model_validate(question, from_attributes=True)
    session.close()
    return result


@router.patch("/{form_id}/questions/{question_id}", response_model=FormQuestionOut, operation_id="patch_form_question", summary="Partially update a form question", description="Update only the provided fields of a form_question row.")
async def patch_form_question(form_id: int, question_id: int, payload: FormQuestionUpdate = Body(...)):
    session = SessionLocal()
    question = session.query(FormQuestion).filter(FormQuestion.id == question_id, FormQuestion.form_id == form_id).first()
    if not question:
        session.close()
        raise HTTPException(status_code=404, detail="Question not found")
    if payload.question_text is not None:
        question.question_text = payload.question_text
    if payload.question_type is not None:
        question.question_type = payload.question_type
    if payload.is_required is not None:
        question.is_required = payload.is_required
    if payload.display_order is not None:
        question.display_order = payload.display_order
    question.updated_at = datetime.utcnow()
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Invalid question data")
    session.refresh(question)
    result = FormQuestionOut.model_validate(question, from_attributes=True)
    session.close()
    return result


@router.delete("/{form_id}/questions/{question_id}", response_model=DeleteResponse, operation_id="delete_form_question", summary="Delete a form question", description="Remove a form_question row and cascade to dependent answers and documents.")
async def delete_form_question(form_id: int, question_id: int):
    session = SessionLocal()
    question = session.query(FormQuestion).filter(FormQuestion.id == question_id, FormQuestion.form_id == form_id).first()
    if not question:
        session.close()
        raise HTTPException(status_code=404, detail="Question not found")
    session.delete(question)
    session.commit()
    session.close()
    return DeleteResponse(message="Question deleted successfully")