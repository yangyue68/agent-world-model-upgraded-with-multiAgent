from datetime import datetime, date
from typing import Optional, List
from pydantic import BaseModel, ConfigDict, Field

class ApplicationOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    application_number: str
    applicant_id: int
    intake_id: int
    status: str
    submitted_at: Optional[datetime] = None
    decision_at: Optional[datetime] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class ApplicationDetailOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    application_number: str
    applicant_id: int
    applicant_name: Optional[str] = None
    applicant_email: Optional[str] = None
    intake_id: int
    program_name: Optional[str] = None
    term: Optional[str] = None
    year: Optional[int] = None
    status: str
    submitted_at: Optional[datetime] = None
    decision_at: Optional[datetime] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class ApplicationListOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    applications: List[ApplicationOut]
    total: int

class StatusUpdateRequest(BaseModel):
    new_status: str
    reason: Optional[str] = None
    changed_by_user_id: Optional[int] = None

class StatusUpdateOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    previous_status: Optional[str] = None
    new_status: str
    changed_at: Optional[datetime] = None

class NoteCreateRequest(BaseModel):
    note: str
    is_internal: Optional[int] = 1
    author_user_id: Optional[int] = None

class NoteUpdateRequest(BaseModel):
    note: Optional[str] = None
    is_internal: Optional[int] = None

class NoteOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    application_id: int
    author_user_id: int
    note: str
    is_internal: int
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class NoteListOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    notes: List[NoteOut]
    total: int

class NoteDeleteOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    deleted: bool
    note_id: int

class DocumentCreateRequest(BaseModel):
    document_type: str
    file_name: str
    file_path: str
    mime_type: Optional[str] = None
    file_size_bytes: Optional[int] = None
    uploaded_by_user_id: Optional[int] = None

class DocumentUpdateRequest(BaseModel):
    document_type: Optional[str] = None
    file_name: Optional[str] = None
    is_active: Optional[int] = None

class DocumentOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    application_id: int
    document_type: str
    file_name: str
    file_path: str
    mime_type: Optional[str] = None
    file_size_bytes: Optional[int] = None
    uploaded_by_user_id: Optional[int] = None
    uploaded_at: Optional[datetime] = None
    is_active: int
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class DocumentListOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    documents: List[DocumentOut]

class DocumentDeleteOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    deleted: bool
    document_id: int

class EmailSendRequest(BaseModel):
    recipient_email: str
    subject: str
    body: Optional[str] = None
    template_name: Optional[str] = None
    sent_by_user_id: Optional[int] = None

class EmailLogCreateRequest(BaseModel):
    application_id: Optional[int] = None
    recipient_email: str
    subject: str
    body: Optional[str] = None
    template_name: Optional[str] = None
    status: Optional[str] = 'Sent'
    error_message: Optional[str] = None
    sent_by_user_id: Optional[int] = None

class EmailLogUpdateRequest(BaseModel):
    status: Optional[str] = None
    error_message: Optional[str] = None

class EmailLogOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    application_id: Optional[int] = None
    recipient_email: str
    subject: str
    body: Optional[str] = None
    template_name: Optional[str] = None
    sent_by_user_id: Optional[int] = None
    sent_at: Optional[datetime] = None
    status: str
    error_message: Optional[str] = None
    created_at: Optional[datetime] = None

class EmailLogListOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    email_log: List[EmailLogOut]
    total: int

class EmailLogDeleteOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    deleted: bool
    id: int

class StatusHistoryCreateRequest(BaseModel):
    new_status: str
    reason: Optional[str] = None
    changed_by_user_id: Optional[int] = None

class StatusHistoryUpdateRequest(BaseModel):
    reason: Optional[str] = None

class StatusHistoryOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    application_id: int
    previous_status: Optional[str] = None
    new_status: str
    changed_by_user_id: Optional[int] = None
    changed_at: Optional[datetime] = None
    reason: Optional[str] = None

class StatusHistoryListOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    data: List[StatusHistoryOut]
    total: int

class StatusHistoryDeleteOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    deleted: bool
    id: int