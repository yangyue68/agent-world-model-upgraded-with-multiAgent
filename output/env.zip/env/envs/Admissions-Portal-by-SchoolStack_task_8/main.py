import os
from fastapi import FastAPI
import uvicorn

from database import Base, engine
from routers import applications, notes, documents, emails, status_history

Base.metadata.create_all(engine)

app = FastAPI(
    title="Admissions Portal by SchoolStack",
    description="Application and registration management platform for schools, universities, camps, and programs.",
    version="1.0.0",
)

app.include_router(applications.router)
app.include_router(notes.router)
app.include_router(documents.router)
app.include_router(emails.router)
app.include_router(status_history.router)


@app.get(
    "/health",
    summary="Health check",
    description="Return service health status.",
    tags=["Health"],
    operation_id="health_check",
)
async def health_check():
    return {"status": "ok"}


if __name__ == "__main__":
    host = os.getenv("HOST", "127.0.0.1")
    port = int(os.getenv("PORT", "8000"))
    uvicorn.run(app, host=host, port=port)