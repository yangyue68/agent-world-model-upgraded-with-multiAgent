from datetime import datetime
from typing import Optional
from fastapi import APIRouter, Query, HTTPException, Body
from sqlalchemy import desc

from database import SessionLocal
from models import Application, Applicant, Intake, Program, ApplicationStatusHistory
from schemas import (
    ApplicationListOut,
    ApplicationDetailOut,
    StatusUpdateRequest,
    StatusUpdateOut,
)

router = APIRouter(prefix="/api", tags=["Applications"])

VALID_STATUSES = {
    "Submitted",
    "Under Review",
    "Interview",
    "Decision Pending",
    "Admitted",
    "Denied",
    "Waitlisted",
    "Withdrawn",
}


@router.get(
    "/applications",
    summary="List applications with optional filters",
    description="Retrieve applications filtered by status, intake, applicant, or application number.",
    tags=["Applications"],
    operation_id="list_applications",
    response_model=ApplicationListOut,
)
async def list_applications(
    status: Optional[str] = Query(None),
    intake_id: Optional[int] = Query(None),
    applicant_id: Optional[int] = Query(None),
    application_number: Optional[str] = Query(None),
    limit: int = Query(50),
    offset: int = Query(0),
):
    session = SessionLocal()
    query = session.query(Application)
    if status is not None:
        query = query.filter(Application.status == status)
    if intake_id is not None:
        query = query.filter(Application.intake_id == intake_id)
    if applicant_id is not None:
        query = query.filter(Application.applicant_id == applicant_id)
    if application_number is not None:
        query = query.filter(Application.application_number == application_number)
    total = query.count()
    rows = query.order_by(desc(Application.id)).offset(offset).limit(limit).all()
    result = ApplicationListOut(applications=rows, total=total)
    session.close()
    return result


@router.get(
    "/applications/{application_id}",
    summary="Get a single application by id",
    description="Retrieve full details of an application including applicant and intake info.",
    tags=["Applications"],
    operation_id="get_application",
    response_model=ApplicationDetailOut,
)
async def get_application(application_id: int):
    session = SessionLocal()
    app_obj = session.query(Application).filter(Application.id == application_id).first()
    if app_obj is None:
        session.close()
        raise HTTPException(status_code=404, detail="Application not found")
    applicant = session.query(Applicant).filter(Applicant.id == app_obj.applicant_id).first()
    intake = session.query(Intake).filter(Intake.id == app_obj.intake_id).first()
    program = None
    if intake is not None:
        program = session.query(Program).filter(Program.id == intake.program_id).first()
    detail = ApplicationDetailOut(
        id=app_obj.id,
        application_number=app_obj.application_number,
        applicant_id=app_obj.applicant_id,
        applicant_name=(applicant.first_name + " " + applicant.last_name) if applicant else None,
        applicant_email=applicant.email if applicant else None,
        intake_id=app_obj.intake_id,
        program_name=program.name if program else None,
        term=intake.term if intake else None,
        year=intake.year if intake else None,
        status=app_obj.status,
        submitted_at=app_obj.submitted_at,
        decision_at=app_obj.decision_at,
        created_at=app_obj.created_at,
        updated_at=app_obj.updated_at,
    )
    session.close()
    return detail


@router.patch(
    "/applications/{application_id}/status",
    summary="Update application status",
    description="Change application status and record status history entry.",
    tags=["Applications"],
    operation_id="update_application_status",
    response_model=StatusUpdateOut,
)
async def update_application_status(application_id: int, payload: StatusUpdateRequest = Body(...)):
    session = SessionLocal()
    app_obj = session.query(Application).filter(Application.id == application_id).first()
    if app_obj is None:
        session.close()
        raise HTTPException(status_code=404, detail="Application not found")
    if payload.new_status not in VALID_STATUSES:
        session.close()
        raise HTTPException(status_code=400, detail="Invalid status value")
    previous = app_obj.status
    now = datetime.utcnow()
    app_obj.status = payload.new_status
    app_obj.updated_at = now
    if payload.new_status in ("Admitted", "Denied", "Waitlisted"):
        app_obj.decision_at = now
    history = ApplicationStatusHistory(
        application_id=app_obj.id,
        previous_status=previous,
        new_status=payload.new_status,
        changed_by_user_id=payload.changed_by_user_id if payload.changed_by_user_id is not None else 1,
        changed_at=now,
        reason=payload.reason,
    )
    session.add(history)
    session.commit()
    out = StatusUpdateOut(
        id=app_obj.id,
        previous_status=previous,
        new_status=payload.new_status,
        changed_at=now,
    )
    session.close()
    return out