from datetime import datetime
from typing import Optional
from fastapi import APIRouter, Query, HTTPException, Body
from sqlalchemy import desc

from database import SessionLocal
from models import Application, ApplicationNote
from schemas import (
    NoteCreateRequest,
    NoteUpdateRequest,
    NoteOut,
    NoteListOut,
    NoteDeleteOut,
)

router = APIRouter(prefix="/api", tags=["ApplicationNotes"])


@router.get(
    "/applications/{application_id}/notes",
    summary="List notes for an application",
    description="Retrieve all notes associated with a given application, newest first.",
    tags=["ApplicationNotes"],
    operation_id="list_application_notes",
    response_model=NoteListOut,
)
async def list_application_notes(
    application_id: int,
    is_internal: Optional[int] = Query(None),
    limit: int = Query(50),
    offset: int = Query(0),
):
    session = SessionLocal()
    app_obj = session.query(Application).filter(Application.id == application_id).first()
    if app_obj is None:
        session.close()
        raise HTTPException(status_code=404, detail="Application not found")
    query = session.query(ApplicationNote).filter(ApplicationNote.application_id == application_id)
    if is_internal is not None:
        query = query.filter(ApplicationNote.is_internal == is_internal)
    total = query.count()
    rows = query.order_by(desc(ApplicationNote.created_at)).offset(offset).limit(limit).all()
    result = NoteListOut(notes=rows, total=total)
    session.close()
    return result


@router.post(
    "/applications/{application_id}/notes",
    summary="Add a note to an application",
    description="Create a new note on the specified application authored by the current user.",
    tags=["ApplicationNotes"],
    operation_id="create_application_note",
    response_model=NoteOut,
)
async def create_application_note(application_id: int, payload: NoteCreateRequest = Body(...)):
    session = SessionLocal()
    app_obj = session.query(Application).filter(Application.id == application_id).first()
    if app_obj is None:
        session.close()
        raise HTTPException(status_code=404, detail="Application not found")
    now = datetime.utcnow()
    note = ApplicationNote(
        application_id=application_id,
        author_user_id=payload.author_user_id if payload.author_user_id is not None else 1,
        note=payload.note,
        is_internal=payload.is_internal if payload.is_internal is not None else 1,
        created_at=now,
        updated_at=now,
    )
    session.add(note)
    session.commit()
    session.refresh(note)
    out = NoteOut.model_validate(note, from_attributes=True)
    session.close()
    return out


@router.get(
    "/applications/{application_id}/notes/{note_id}",
    summary="Get a single application note",
    description="Retrieve one note by its ID within the given application.",
    tags=["ApplicationNotes"],
    operation_id="get_application_note",
    response_model=NoteOut,
)
async def get_application_note(application_id: int, note_id: int):
    session = SessionLocal()
    note = (
        session.query(ApplicationNote)
        .filter(ApplicationNote.id == note_id, ApplicationNote.application_id == application_id)
        .first()
    )
    if note is None:
        session.close()
        raise HTTPException(status_code=404, detail="Note not found")
    out = NoteOut.model_validate(note, from_attributes=True)
    session.close()
    return out


@router.patch(
    "/applications/{application_id}/notes/{note_id}",
    summary="Update an application note",
    description="Partially update the text or internal flag of an existing note.",
    tags=["ApplicationNotes"],
    operation_id="update_application_note",
    response_model=NoteOut,
)
async def update_application_note(application_id: int, note_id: int, payload: NoteUpdateRequest = Body(...)):
    session = SessionLocal()
    note = (
        session.query(ApplicationNote)
        .filter(ApplicationNote.id == note_id, ApplicationNote.application_id == application_id)
        .first()
    )
    if note is None:
        session.close()
        raise HTTPException(status_code=404, detail="Note not found")
    if payload.note is not None:
        note.note = payload.note
    if payload.is_internal is not None:
        note.is_internal = payload.is_internal
    note.updated_at = datetime.utcnow()
    session.commit()
    session.refresh(note)
    out = NoteOut.model_validate(note, from_attributes=True)
    session.close()
    return out


@router.delete(
    "/applications/{application_id}/notes/{note_id}",
    summary="Delete an application note",
    description="Permanently remove a note from the specified application.",
    tags=["ApplicationNotes"],
    operation_id="delete_application_note",
    response_model=NoteDeleteOut,
)
async def delete_application_note(application_id: int, note_id: int):
    session = SessionLocal()
    note = (
        session.query(ApplicationNote)
        .filter(ApplicationNote.id == note_id, ApplicationNote.application_id == application_id)
        .first()
    )
    if note is None:
        session.close()
        raise HTTPException(status_code=404, detail="Note not found")
    session.delete(note)
    session.commit()
    out = NoteDeleteOut(deleted=True, note_id=note_id)
    session.close()
    return out