from datetime import datetime
from typing import Optional
from fastapi import APIRouter, Query, HTTPException, Body
from sqlalchemy import desc

from database import SessionLocal
from models import Application, Document
from schemas import (
    DocumentCreateRequest,
    DocumentUpdateRequest,
    DocumentOut,
    DocumentListOut,
    DocumentDeleteOut,
)

router = APIRouter(prefix="/api", tags=["Documents"])

VALID_DOCUMENT_TYPES = {
    "Transcript",
    "Recommendation Letter",
    "Personal Statement",
    "Resume",
    "Test Score",
    "Other",
}


@router.get(
    "/applications/{application_id}/documents",
    summary="List documents for an application",
    description="Retrieve all documents attached to a given application, optionally filtered by type or active status.",
    tags=["Documents"],
    operation_id="list_application_documents",
    response_model=DocumentListOut,
)
async def list_application_documents(
    application_id: int,
    document_type: Optional[str] = Query(None),
    is_active: Optional[int] = Query(None),
):
    session = SessionLocal()
    app_obj = session.query(Application).filter(Application.id == application_id).first()
    if app_obj is None:
        session.close()
        raise HTTPException(status_code=404, detail="Application not found")
    query = session.query(Document).filter(Document.application_id == application_id)
    if document_type is not None:
        query = query.filter(Document.document_type == document_type)
    if is_active is not None:
        query = query.filter(Document.is_active == is_active)
    rows = query.order_by(desc(Document.id)).all()
    result = DocumentListOut(documents=rows)
    session.close()
    return result


@router.post(
    "/applications/{application_id}/documents",
    summary="Upload a document for an application",
    description="Create a new document record attached to the given application.",
    tags=["Documents"],
    operation_id="create_application_document",
    response_model=DocumentOut,
)
async def create_application_document(application_id: int, payload: DocumentCreateRequest = Body(...)):
    session = SessionLocal()
    app_obj = session.query(Application).filter(Application.id == application_id).first()
    if app_obj is None:
        session.close()
        raise HTTPException(status_code=404, detail="Application not found")
    if payload.document_type not in VALID_DOCUMENT_TYPES:
        session.close()
        raise HTTPException(status_code=400, detail="Invalid document_type")
    now = datetime.utcnow()
    doc = Document(
        application_id=application_id,
        document_type=payload.document_type,
        file_name=payload.file_name,
        file_path=payload.file_path,
        mime_type=payload.mime_type,
        file_size_bytes=payload.file_size_bytes,
        uploaded_by_user_id=payload.uploaded_by_user_id if payload.uploaded_by_user_id is not None else 1,
        uploaded_at=now,
        is_active=1,
        created_at=now,
        updated_at=now,
    )
    session.add(doc)
    session.commit()
    session.refresh(doc)
    out = DocumentOut.model_validate(doc, from_attributes=True)
    session.close()
    return out


@router.get(
    "/documents/{document_id}",
    summary="Get a single document by ID",
    description="Retrieve metadata for one document record.",
    tags=["Documents"],
    operation_id="get_document",
    response_model=DocumentOut,
)
async def get_document(document_id: int):
    session = SessionLocal()
    doc = session.query(Document).filter(Document.id == document_id).first()
    if doc is None:
        session.close()
        raise HTTPException(status_code=404, detail="Document not found")
    out = DocumentOut.model_validate(doc, from_attributes=True)
    session.close()
    return out


@router.patch(
    "/documents/{document_id}",
    summary="Update document metadata",
    description="Partially update a document record, such as its type or active status.",
    tags=["Documents"],
    operation_id="update_document",
    response_model=DocumentOut,
)
async def update_document(document_id: int, payload: DocumentUpdateRequest = Body(...)):
    session = SessionLocal()
    doc = session.query(Document).filter(Document.id == document_id).first()
    if doc is None:
        session.close()
        raise HTTPException(status_code=404, detail="Document not found")
    if payload.document_type is not None:
        if payload.document_type not in VALID_DOCUMENT_TYPES:
            session.close()
            raise HTTPException(status_code=400, detail="Invalid document_type")
        doc.document_type = payload.document_type
    if payload.file_name is not None:
        doc.file_name = payload.file_name
    if payload.is_active is not None:
        doc.is_active = payload.is_active
    doc.updated_at = datetime.utcnow()
    session.commit()
    session.refresh(doc)
    out = DocumentOut.model_validate(doc, from_attributes=True)
    session.close()
    return out


@router.delete(
    "/documents/{document_id}",
    summary="Delete a document record",
    description="Permanently delete a document record from the system.",
    tags=["Documents"],
    operation_id="delete_document",
    response_model=DocumentDeleteOut,
)
async def delete_document(document_id: int):
    session = SessionLocal()
    doc = session.query(Document).filter(Document.id == document_id).first()
    if doc is None:
        session.close()
        raise HTTPException(status_code=404, detail="Document not found")
    session.delete(doc)
    session.commit()
    out = DocumentDeleteOut(deleted=True, document_id=document_id)
    session.close()
    return out