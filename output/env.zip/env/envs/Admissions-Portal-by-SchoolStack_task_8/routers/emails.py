from datetime import datetime
from typing import Optional
from fastapi import APIRouter, Query, HTTPException, Body
from sqlalchemy import desc

from database import SessionLocal
from models import Application, EmailLog
from schemas import (
    EmailSendRequest,
    EmailLogCreateRequest,
    EmailLogUpdateRequest,
    EmailLogOut,
    EmailLogListOut,
    EmailLogDeleteOut,
)

router = APIRouter(prefix="/api", tags=["EmailLog"])

VALID_EMAIL_STATUSES = {"Sent", "Failed", "Queued"}


def _parse_dt(value: Optional[str]):
    if value is None:
        return None
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00")).replace(tzinfo=None)
    except ValueError:
        return None


@router.get(
    "/email-log",
    summary="List email log entries",
    description="Retrieve email log entries with optional filters by application, recipient, status, and date range.",
    tags=["EmailLog"],
    operation_id="list_email_log",
    response_model=EmailLogListOut,
)
async def list_email_log(
    application_id: Optional[int] = Query(None),
    recipient_email: Optional[str] = Query(None),
    status: Optional[str] = Query(None),
    template_name: Optional[str] = Query(None),
    sent_after: Optional[str] = Query(None),
    sent_before: Optional[str] = Query(None),
    limit: int = Query(50),
    offset: int = Query(0),
):
    session = SessionLocal()
    query = session.query(EmailLog)
    if application_id is not None:
        query = query.filter(EmailLog.application_id == application_id)
    if recipient_email is not None:
        query = query.filter(EmailLog.recipient_email == recipient_email)
    if status is not None:
        query = query.filter(EmailLog.status == status)
    if template_name is not None:
        query = query.filter(EmailLog.template_name == template_name)
    after_dt = _parse_dt(sent_after)
    before_dt = _parse_dt(sent_before)
    if after_dt is not None:
        query = query.filter(EmailLog.sent_at >= after_dt)
    if before_dt is not None:
        query = query.filter(EmailLog.sent_at <= before_dt)
    total = query.count()
    rows = query.order_by(desc(EmailLog.id)).offset(offset).limit(limit).all()
    result = EmailLogListOut(email_log=rows, total=total)
    session.close()
    return result


@router.get(
    "/email-log/{id}",
    summary="Get a single email log entry",
    description="Retrieve one email log entry by its ID.",
    tags=["EmailLog"],
    operation_id="get_email_log",
    response_model=EmailLogOut,
)
async def get_email_log(id: int):
    session = SessionLocal()
    entry = session.query(EmailLog).filter(EmailLog.id == id).first()
    if entry is None:
        session.close()
        raise HTTPException(status_code=404, detail="Email log entry not found")
    out = EmailLogOut.model_validate(entry, from_attributes=True)
    session.close()
    return out


@router.post(
    "/email-log",
    summary="Create an email log entry",
    description="Record a sent, failed, or queued email associated with an application.",
    tags=["EmailLog"],
    operation_id="create_email_log",
    response_model=EmailLogOut,
)
async def create_email_log(payload: EmailLogCreateRequest = Body(...)):
    session = SessionLocal()
    if payload.application_id is not None:
        app_obj = session.query(Application).filter(Application.id == payload.application_id).first()
        if app_obj is None:
            session.close()
            raise HTTPException(status_code=404, detail="Application not found")
    status_value = payload.status if payload.status is not None else "Sent"
    if status_value not in VALID_EMAIL_STATUSES:
        session.close()
        raise HTTPException(status_code=400, detail="Invalid status")
    now = datetime.utcnow()
    entry = EmailLog(
        application_id=payload.application_id,
        recipient_email=payload.recipient_email,
        subject=payload.subject,
        body=payload.body,
        template_name=payload.template_name,
        sent_by_user_id=payload.sent_by_user_id if payload.sent_by_user_id is not None else 1,
        sent_at=now,
        status=status_value,
        error_message=payload.error_message,
        created_at=now,
    )
    session.add(entry)
    session.commit()
    session.refresh(entry)
    out = EmailLogOut.model_validate(entry, from_attributes=True)
    session.close()
    return out


@router.patch(
    "/email-log/{id}",
    summary="Update an email log entry",
    description="Update status or error details of an existing email log entry.",
    tags=["EmailLog"],
    operation_id="update_email_log",
    response_model=EmailLogOut,
)
async def update_email_log(id: int, payload: EmailLogUpdateRequest = Body(...)):
    session = SessionLocal()
    entry = session.query(EmailLog).filter(EmailLog.id == id).first()
    if entry is None:
        session.close()
        raise HTTPException(status_code=404, detail="Email log entry not found")
    if payload.status is not None:
        if payload.status not in VALID_EMAIL_STATUSES:
            session.close()
            raise HTTPException(status_code=400, detail="Invalid status")
        entry.status = payload.status
    if payload.error_message is not None:
        entry.error_message = payload.error_message
    session.commit()
    session.refresh(entry)
    out = EmailLogOut.model_validate(entry, from_attributes=True)
    session.close()
    return out


@router.delete(
    "/email-log/{id}",
    summary="Delete an email log entry",
    description="Permanently remove an email log entry by its ID.",
    tags=["EmailLog"],
    operation_id="delete_email_log",
    response_model=EmailLogDeleteOut,
)
async def delete_email_log(id: int):
    session = SessionLocal()
    entry = session.query(EmailLog).filter(EmailLog.id == id).first()
    if entry is None:
        session.close()
        raise HTTPException(status_code=404, detail="Email log entry not found")
    session.delete(entry)
    session.commit()
    out = EmailLogDeleteOut(deleted=True, id=id)
    session.close()
    return out


@router.get(
    "/applications/{application_id}/email-log",
    summary="List email log entries for an application",
    description="Retrieve all email log entries associated with a specific application.",
    tags=["EmailLog"],
    operation_id="list_application_email_log",
    response_model=EmailLogListOut,
)
async def list_application_email_log(
    application_id: int,
    status: Optional[str] = Query(None),
    limit: int = Query(50),
    offset: int = Query(0),
):
    session = SessionLocal()
    app_obj = session.query(Application).filter(Application.id == application_id).first()
    if app_obj is None:
        session.close()
        raise HTTPException(status_code=404, detail="Application not found")
    query = session.query(EmailLog).filter(EmailLog.application_id == application_id)
    if status is not None:
        query = query.filter(EmailLog.status == status)
    total = query.count()
    rows = query.order_by(desc(EmailLog.id)).offset(offset).limit(limit).all()
    result = EmailLogListOut(email_log=rows, total=total)
    session.close()
    return result


@router.post(
    "/applications/{application_id}/email-log",
    summary="Send and log an email for an application",
    description="Send an email to the applicant and record it in the email log.",
    tags=["EmailLog"],
    operation_id="send_application_email",
    response_model=EmailLogOut,
)
async def send_application_email(application_id: int, payload: EmailSendRequest = Body(...)):
    session = SessionLocal()
    app_obj = session.query(Application).filter(Application.id == application_id).first()
    if app_obj is None:
        session.close()
        raise HTTPException(status_code=404, detail="Application not found")
    now = datetime.utcnow()
    entry = EmailLog(
        application_id=application_id,
        recipient_email=payload.recipient_email,
        subject=payload.subject,
        body=payload.body,
        template_name=payload.template_name,
        sent_by_user_id=payload.sent_by_user_id if payload.sent_by_user_id is not None else 1,
        sent_at=now,
        status="Sent",
        error_message=None,
        created_at=now,
    )
    session.add(entry)
    session.commit()
    session.refresh(entry)
    out = EmailLogOut.model_validate(entry, from_attributes=True)
    session.close()
    return out