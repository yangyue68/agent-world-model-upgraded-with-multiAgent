from datetime import datetime
from typing import Optional
from fastapi import APIRouter, Query, HTTPException, Body
from sqlalchemy import desc

from database import SessionLocal
from models import Application, ApplicationStatusHistory
from schemas import (
    StatusHistoryCreateRequest,
    StatusHistoryUpdateRequest,
    StatusHistoryOut,
    StatusHistoryListOut,
    StatusHistoryDeleteOut,
)

router = APIRouter(prefix="/api", tags=["ApplicationStatusHistory"])

VALID_STATUSES = {
    "Submitted",
    "Under Review",
    "Interview",
    "Decision Pending",
    "Admitted",
    "Denied",
    "Waitlisted",
    "Withdrawn",
}


def _parse_date(value: Optional[str]):
    if value is None:
        return None
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00")).replace(tzinfo=None)
    except ValueError:
        return None


@router.get(
    "/application-status-history",
    summary="List status history entries with optional filters",
    description="Retrieve application status history records, optionally filtered by application or status.",
    tags=["ApplicationStatusHistory"],
    operation_id="list_application_status_history",
    response_model=StatusHistoryListOut,
)
async def list_application_status_history(
    application_id: Optional[int] = Query(None),
    new_status: Optional[str] = Query(None),
    previous_status: Optional[str] = Query(None),
    changed_by_user_id: Optional[int] = Query(None),
    changed_from: Optional[str] = Query(None),
    changed_to: Optional[str] = Query(None),
    limit: int = Query(50),
    offset: int = Query(0),
):
    session = SessionLocal()
    query = session.query(ApplicationStatusHistory)
    if application_id is not None:
        query = query.filter(ApplicationStatusHistory.application_id == application_id)
    if new_status is not None:
        query = query.filter(ApplicationStatusHistory.new_status == new_status)
    if previous_status is not None:
        query = query.filter(ApplicationStatusHistory.previous_status == previous_status)
    if changed_by_user_id is not None:
        query = query.filter(ApplicationStatusHistory.changed_by_user_id == changed_by_user_id)
    from_dt = _parse_date(changed_from)
    to_dt = _parse_date(changed_to)
    if from_dt is not None:
        query = query.filter(ApplicationStatusHistory.changed_at >= from_dt)
    if to_dt is not None:
        query = query.filter(ApplicationStatusHistory.changed_at <= to_dt)
    total = query.count()
    rows = query.order_by(desc(ApplicationStatusHistory.changed_at)).offset(offset).limit(limit).all()
    result = StatusHistoryListOut(data=rows, total=total)
    session.close()
    return result


@router.get(
    "/application-status-history/{id}",
    summary="Get a single status history entry by ID",
    description="Retrieve one application status history record by its primary key.",
    tags=["ApplicationStatusHistory"],
    operation_id="get_application_status_history",
    response_model=StatusHistoryOut,
)
async def get_application_status_history(id: int):
    session = SessionLocal()
    entry = session.query(ApplicationStatusHistory).filter(ApplicationStatusHistory.id == id).first()
    if entry is None:
        session.close()
        raise HTTPException(status_code=404, detail="Status history entry not found")
    out = StatusHistoryOut.model_validate(entry, from_attributes=True)
    session.close()
    return out


@router.get(
    "/applications/{application_id}/status-history",
    summary="List status history for an application",
    description="Retrieve all status history records for a specific application, newest first.",
    tags=["ApplicationStatusHistory"],
    operation_id="list_status_history_by_application",
    response_model=StatusHistoryListOut,
)
async def list_status_history_by_application(
    application_id: int,
    limit: int = Query(50),
    offset: int = Query(0),
):
    session = SessionLocal()
    app_obj = session.query(Application).filter(Application.id == application_id).first()
    if app_obj is None:
        session.close()
        raise HTTPException(status_code=404, detail="Application not found")
    query = session.query(ApplicationStatusHistory).filter(
        ApplicationStatusHistory.application_id == application_id
    )
    total = query.count()
    rows = query.order_by(desc(ApplicationStatusHistory.changed_at)).offset(offset).limit(limit).all()
    result = StatusHistoryListOut(data=rows, total=total)
    session.close()
    return result


@router.post(
    "/applications/{application_id}/status-history",
    summary="Record a status change for an application",
    description="Insert a status history entry and update the application's current status atomically.",
    tags=["ApplicationStatusHistory"],
    operation_id="create_application_status_history",
    response_model=StatusHistoryOut,
)
async def create_application_status_history(application_id: int, payload: StatusHistoryCreateRequest = Body(...)):
    session = SessionLocal()
    app_obj = session.query(Application).filter(Application.id == application_id).first()
    if app_obj is None:
        session.close()
        raise HTTPException(status_code=404, detail="Application not found")
    if payload.new_status not in VALID_STATUSES:
        session.close()
        raise HTTPException(status_code=400, detail="Invalid status value")
    previous = app_obj.status
    now = datetime.utcnow()
    app_obj.status = payload.new_status
    app_obj.updated_at = now
    if payload.new_status in ("Admitted", "Denied", "Waitlisted"):
        app_obj.decision_at = now
    entry = ApplicationStatusHistory(
        application_id=application_id,
        previous_status=previous,
        new_status=payload.new_status,
        changed_by_user_id=payload.changed_by_user_id if payload.changed_by_user_id is not None else 1,
        changed_at=now,
        reason=payload.reason,
    )
    session.add(entry)
    session.commit()
    session.refresh(entry)
    out = StatusHistoryOut.model_validate(entry, from_attributes=True)
    session.close()
    return out


@router.patch(
    "/application-status-history/{id}",
    summary="Update a status history entry",
    description="Update mutable fields of a status history record such as reason.",
    tags=["ApplicationStatusHistory"],
    operation_id="update_application_status_history",
    response_model=StatusHistoryOut,
)
async def update_application_status_history(id: int, payload: StatusHistoryUpdateRequest = Body(...)):
    session = SessionLocal()
    entry = session.query(ApplicationStatusHistory).filter(ApplicationStatusHistory.id == id).first()
    if entry is None:
        session.close()
        raise HTTPException(status_code=404, detail="Status history entry not found")
    if payload.reason is not None:
        entry.reason = payload.reason
    session.commit()
    session.refresh(entry)
    out = StatusHistoryOut.model_validate(entry, from_attributes=True)
    session.close()
    return out


@router.delete(
    "/application-status-history/{id}",
    summary="Delete a status history entry",
    description="Remove a status history record by its ID.",
    tags=["ApplicationStatusHistory"],
    operation_id="delete_application_status_history",
    response_model=StatusHistoryDeleteOut,
)
async def delete_application_status_history(id: int):
    session = SessionLocal()
    entry = session.query(ApplicationStatusHistory).filter(ApplicationStatusHistory.id == id).first()
    if entry is None:
        session.close()
        raise HTTPException(status_code=404, detail="Status history entry not found")
    session.delete(entry)
    session.commit()
    out = StatusHistoryDeleteOut(deleted=True, id=id)
    session.close()
    return out