from datetime import datetime
from fastapi import APIRouter, Body
from pydantic import BaseModel
from typing import Optional

router = APIRouter(prefix="/api/audit", tags=["Audit"])

AUDIT_LOG = []


class AuditEntryCreate(BaseModel):
    entity_type: str
    entity_id: int
    action: str
    reviewer_id: Optional[int] = None
    details: Optional[str] = None


@router.post("/entries", operation_id="create_audit_entry", summary="Create an audit entry", description="Record a versioned change with reviewer identity and timestamp for compliance.")
async def create_audit_entry(payload: AuditEntryCreate = Body(...)):
    entry = {
        "id": len(AUDIT_LOG) + 1,
        "entity_type": payload.entity_type,
        "entity_id": payload.entity_id,
        "action": payload.action,
        "reviewer_id": payload.reviewer_id,
        "details": payload.details,
        "timestamp": datetime.utcnow().isoformat(),
    }
    AUDIT_LOG.append(entry)
    return entry


@router.get("/entries", operation_id="list_audit_entries", summary="List audit entries", description="Retrieve audit log entries, optionally filtered by entity type and ID.")
async def list_audit_entries(entity_type: str = None, entity_id: int = None):
    results = AUDIT_LOG
    if entity_type is not None:
        results = [e for e in results if e["entity_type"] == entity_type]
    if entity_id is not None:
        results = [e for e in results if e["entity_id"] == entity_id]
    return {"entries": results, "total": len(results)}