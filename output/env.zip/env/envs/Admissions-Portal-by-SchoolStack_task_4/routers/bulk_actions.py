from datetime import datetime
from fastapi import APIRouter, Body, HTTPException
from pydantic import BaseModel
from typing import List, Optional
from database import SessionLocal
from models import Application, ApplicationAnswer, ApplicationDocument, ApplicationFee, RecommendationRequest

router = APIRouter(prefix="/api/bulk", tags=["BulkActions"])

VALID_STATUSES = {"draft", "submitted", "under_review", "accepted", "rejected", "waitlisted"}


class BatchStatusRequest(BaseModel):
    application_ids: List[int]
    status: str


class MergeRequest(BaseModel):
    primary_application_id: int
    duplicate_application_id: int


@router.post("/batch-status", operation_id="bulk_batch_status_change", summary="Batch change application statuses", description="Change the status of multiple applications in a single request.")
async def bulk_batch_status_change(payload: BatchStatusRequest = Body(...)):
    if payload.status not in VALID_STATUSES:
        raise HTTPException(status_code=400, detail="Invalid application status")
    session = SessionLocal()
    updated = 0
    for app_id in payload.application_ids:
        application = session.query(Application).filter(Application.id == app_id).first()
        if application is not None:
            application.status = payload.status
            application.updated_at = datetime.utcnow()
            updated += 1
    session.commit()
    session.close()
    return {"updated": updated, "status": payload.status}


@router.get("/export-applicants", operation_id="bulk_export_applicants", summary="Export applicant list", description="Export a list of applicants for a form as structured data.")
async def bulk_export_applicants(form_id: int = None, status: str = None):
    session = SessionLocal()
    query = session.query(Application)
    if form_id is not None:
        query = query.filter(Application.form_id == form_id)
    if status is not None:
        query = query.filter(Application.status == status)
    applications = query.order_by(Application.id).all()
    export = []
    for application in applications:
        export.append({
            "id": application.id,
            "form_id": application.form_id,
            "applicant_user_id": application.applicant_user_id,
            "status": application.status,
            "submitted_at": application.submitted_at.isoformat() if application.submitted_at else None,
        })
    session.close()
    return {"applicants": export, "total": len(export)}


@router.post("/merge-duplicates", operation_id="bulk_merge_duplicates", summary="Merge duplicate applications", description="Merge a duplicate application into a primary application and delete the duplicate.")
async def bulk_merge_duplicates(payload: MergeRequest = Body(...)):
    session = SessionLocal()
    primary = session.query(Application).filter(Application.id == payload.primary_application_id).first()
    if primary is None:
        session.close()
        raise HTTPException(status_code=404, detail="Primary application not found")
    duplicate = session.query(Application).filter(Application.id == payload.duplicate_application_id).first()
    if duplicate is None:
        session.close()
        raise HTTPException(status_code=404, detail="Duplicate application not found")
    answers = session.query(ApplicationAnswer).filter(ApplicationAnswer.application_id == duplicate.id).all()
    for answer in answers:
        existing = session.query(ApplicationAnswer).filter(
            ApplicationAnswer.application_id == primary.id,
            ApplicationAnswer.field_id == answer.field_id,
        ).first()
        if existing is None:
            answer.application_id = primary.id
        else:
            session.delete(answer)
    documents = session.query(ApplicationDocument).filter(ApplicationDocument.application_id == duplicate.id).all()
    for document in documents:
        document.application_id = primary.id
    recommendations = session.query(RecommendationRequest).filter(RecommendationRequest.application_id == duplicate.id).all()
    for recommendation in recommendations:
        recommendation.application_id = primary.id
    duplicate_fee = session.query(ApplicationFee).filter(ApplicationFee.application_id == duplicate.id).first()
    if duplicate_fee is not None:
        primary_fee = session.query(ApplicationFee).filter(ApplicationFee.application_id == primary.id).first()
        if primary_fee is None:
            duplicate_fee.application_id = primary.id
        else:
            session.delete(duplicate_fee)
    session.delete(duplicate)
    primary.updated_at = datetime.utcnow()
    session.commit()
    session.close()
    return {"merged": True, "primary_application_id": payload.primary_application_id, "removed_application_id": payload.duplicate_application_id}