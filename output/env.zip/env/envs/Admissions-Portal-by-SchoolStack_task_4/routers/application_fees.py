from datetime import datetime
from fastapi import APIRouter, Body, HTTPException
from sqlalchemy.exc import IntegrityError
from database import SessionLocal
from models import Application, ApplicationFee
from schemas import (
    ApplicationFeeOut, ApplicationFeeCreate, ApplicationFeeUpdate,
    ApplicationFeeListOut, MessageOut
)

router = APIRouter(tags=["ApplicationFees"])

VALID_STATUSES = {"pending", "paid", "waived", "refunded"}


def _validate_status(status):
    if status not in VALID_STATUSES:
        raise HTTPException(status_code=400, detail="Invalid fee status")


@router.get("/api/application-fees", response_model=ApplicationFeeListOut, operation_id="list_application_fees", summary="List application fees", description="Retrieve a list of application fees, optionally filtered by status.")
async def list_application_fees(status: str = None, application_id: int = None):
    session = SessionLocal()
    query = session.query(ApplicationFee)
    if status is not None:
        query = query.filter(ApplicationFee.status == status)
    if application_id is not None:
        query = query.filter(ApplicationFee.application_id == application_id)
    fees = query.order_by(ApplicationFee.id).all()
    result = ApplicationFeeListOut(application_fees=fees)
    session.close()
    return result


@router.post("/api/application-fees", response_model=ApplicationFeeOut, operation_id="create_application_fee", summary="Create an application fee", description="Create a new application fee for an application.")
async def create_application_fee(payload: ApplicationFeeCreate = Body(...)):
    session = SessionLocal()
    application = session.query(Application).filter(Application.id == payload.application_id).first()
    if application is None:
        session.close()
        raise HTTPException(status_code=404, detail="Application not found")
    existing = session.query(ApplicationFee).filter(ApplicationFee.application_id == payload.application_id).first()
    if existing is not None:
        session.close()
        raise HTTPException(status_code=400, detail="Fee already exists for this application")
    fee = ApplicationFee(
        application_id=payload.application_id,
        amount_cents=payload.amount_cents,
        currency=payload.currency if payload.currency is not None else "USD",
        status=payload.status if payload.status is not None else "pending",
    )
    session.add(fee)
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Invalid application fee data")
    session.refresh(fee)
    result = ApplicationFeeOut.model_validate(fee)
    session.close()
    return result


@router.get("/api/application-fees/{id}", response_model=ApplicationFeeOut, operation_id="get_application_fee", summary="Get an application fee by ID", description="Retrieve a single application fee by its ID.")
async def get_application_fee(id: int):
    session = SessionLocal()
    fee = session.query(ApplicationFee).filter(ApplicationFee.id == id).first()
    if fee is None:
        session.close()
        raise HTTPException(status_code=404, detail="Application fee not found")
    result = ApplicationFeeOut.model_validate(fee)
    session.close()
    return result


@router.put("/api/application-fees/{id}", response_model=ApplicationFeeOut, operation_id="update_application_fee", summary="Update an application fee", description="Update an existing application fee by ID.")
async def update_application_fee(id: int, payload: ApplicationFeeUpdate = Body(...)):
    if payload.status is not None:
        _validate_status(payload.status)
    session = SessionLocal()
    fee = session.query(ApplicationFee).filter(ApplicationFee.id == id).first()
    if fee is None:
        session.close()
        raise HTTPException(status_code=404, detail="Application fee not found")
    if payload.amount_cents is not None:
        fee.amount_cents = payload.amount_cents
    if payload.currency is not None:
        fee.currency = payload.currency
    if payload.status is not None:
        fee.status = payload.status
    if payload.paid_at is not None:
        fee.paid_at = payload.paid_at
    fee.updated_at = datetime.utcnow()
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Invalid application fee data")
    session.refresh(fee)
    result = ApplicationFeeOut.model_validate(fee)
    session.close()
    return result


@router.patch("/api/application-fees/{id}", response_model=ApplicationFeeOut, operation_id="patch_application_fee", summary="Partially update an application fee", description="Update specific fields of an application fee.")
async def patch_application_fee(id: int, payload: ApplicationFeeUpdate = Body(...)):
    if payload.status is not None:
        _validate_status(payload.status)
    session = SessionLocal()
    fee = session.query(ApplicationFee).filter(ApplicationFee.id == id).first()
    if fee is None:
        session.close()
        raise HTTPException(status_code=404, detail="Application fee not found")
    if payload.amount_cents is not None:
        fee.amount_cents = payload.amount_cents
    if payload.currency is not None:
        fee.currency = payload.currency
    if payload.status is not None:
        fee.status = payload.status
    if payload.paid_at is not None:
        fee.paid_at = payload.paid_at
    fee.updated_at = datetime.utcnow()
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Invalid application fee data")
    session.refresh(fee)
    result = ApplicationFeeOut.model_validate(fee)
    session.close()
    return result


@router.delete("/api/application-fees/{id}", response_model=MessageOut, operation_id="delete_application_fee", summary="Delete an application fee", description="Delete an application fee by ID.")
async def delete_application_fee(id: int):
    session = SessionLocal()
    fee = session.query(ApplicationFee).filter(ApplicationFee.id == id).first()
    if fee is None:
        session.close()
        raise HTTPException(status_code=404, detail="Application fee not found")
    session.delete(fee)
    session.commit()
    session.close()
    return MessageOut(message="Application fee deleted successfully")


@router.get("/api/applications/{application_id}/fee", response_model=ApplicationFeeOut, operation_id="get_application_fee_by_application", summary="Get the application fee", description="Retrieve the fee details for a given application.")
async def get_application_fee_by_application(application_id: int):
    session = SessionLocal()
    fee = session.query(ApplicationFee).filter(ApplicationFee.application_id == application_id).first()
    if fee is None:
        session.close()
        raise HTTPException(status_code=404, detail="Application fee not found")
    result = ApplicationFeeOut.model_validate(fee)
    session.close()
    return result


@router.post("/api/applications/{application_id}/fee", response_model=ApplicationFeeOut, operation_id="create_application_fee_for_application", summary="Create an application fee", description="Create a fee record for the application.")
async def create_application_fee_for_application(application_id: int, payload: ApplicationFeeUpdate = Body(...)):
    session = SessionLocal()
    application = session.query(Application).filter(Application.id == application_id).first()
    if application is None:
        session.close()
        raise HTTPException(status_code=404, detail="Application not found")
    existing = session.query(ApplicationFee).filter(ApplicationFee.application_id == application_id).first()
    if existing is not None:
        session.close()
        raise HTTPException(status_code=400, detail="Fee already exists for this application")
    amount = payload.amount_cents if payload.amount_cents is not None else 0
    fee = ApplicationFee(
        application_id=application_id,
        amount_cents=amount,
        currency=payload.currency if payload.currency is not None else "USD",
        status=payload.status if payload.status is not None else "pending",
        paid_at=payload.paid_at,
    )
    session.add(fee)
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Invalid application fee data")
    session.refresh(fee)
    result = ApplicationFeeOut.model_validate(fee)
    session.close()
    return result