import base64
from datetime import datetime
from fastapi import APIRouter, Body, HTTPException
from fastapi.responses import Response
from sqlalchemy.exc import IntegrityError
from database import SessionLocal
from models import Application, ApplicationDocument, FormRequirement
from schemas import (
    ApplicationDocumentOut, ApplicationDocumentCreate, ApplicationDocumentListOut,
    SuccessOut
)

router = APIRouter(tags=["ApplicationDocuments"])


@router.get("/api/applications/{application_id}/documents", response_model=ApplicationDocumentListOut, operation_id="list_application_documents", summary="List documents for an application", description="Retrieve all uploaded documents for a given application.")
async def list_application_documents(application_id: int):
    session = SessionLocal()
    application = session.query(Application).filter(Application.id == application_id).first()
    if application is None:
        session.close()
        raise HTTPException(status_code=404, detail="Application not found")
    documents = session.query(ApplicationDocument).filter(ApplicationDocument.application_id == application_id).order_by(ApplicationDocument.id).all()
    result = ApplicationDocumentListOut(documents=documents)
    session.close()
    return result


@router.post("/api/applications/{application_id}/documents", response_model=ApplicationDocumentOut, operation_id="upload_application_document", summary="Upload a document for an application", description="Upload a file as an application document, optionally linked to a requirement.")
async def upload_application_document(application_id: int, payload: ApplicationDocumentCreate = Body(...)):
    session = SessionLocal()
    application = session.query(Application).filter(Application.id == application_id).first()
    if application is None:
        session.close()
        raise HTTPException(status_code=404, detail="Application not found")
    if payload.requirement_id is not None:
        requirement = session.query(FormRequirement).filter(FormRequirement.id == payload.requirement_id).first()
        if requirement is None:
            session.close()
            raise HTTPException(status_code=404, detail="Form requirement not found")
    try:
        file_bytes = base64.b64decode(payload.file_data)
    except Exception:
        session.close()
        raise HTTPException(status_code=400, detail="file_data must be valid base64")
    document = ApplicationDocument(
        application_id=application_id,
        requirement_id=payload.requirement_id,
        file_name=payload.file_name,
        file_type=payload.file_type,
        file_size_bytes=payload.file_size_bytes,
        file_data=file_bytes,
        uploaded_at=datetime.utcnow(),
    )
    session.add(document)
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Invalid document data")
    session.refresh(document)
    result = ApplicationDocumentOut.model_validate(document)
    session.close()
    return result


@router.get("/api/applications/{application_id}/documents/{document_id}", response_model=ApplicationDocumentOut, operation_id="get_application_document", summary="Get a specific application document", description="Retrieve metadata for a single document belonging to an application.")
async def get_application_document(application_id: int, document_id: int):
    session = SessionLocal()
    document = session.query(ApplicationDocument).filter(
        ApplicationDocument.id == document_id,
        ApplicationDocument.application_id == application_id,
    ).first()
    if document is None:
        session.close()
        raise HTTPException(status_code=404, detail="Document not found")
    result = ApplicationDocumentOut.model_validate(document)
    session.close()
    return result


@router.delete("/api/applications/{application_id}/documents/{document_id}", response_model=SuccessOut, operation_id="delete_application_document", summary="Delete an application document", description="Remove a document from an application.")
async def delete_application_document(application_id: int, document_id: int):
    session = SessionLocal()
    document = session.query(ApplicationDocument).filter(
        ApplicationDocument.id == document_id,
        ApplicationDocument.application_id == application_id,
    ).first()
    if document is None:
        session.close()
        raise HTTPException(status_code=404, detail="Document not found")
    session.delete(document)
    session.commit()
    session.close()
    return SuccessOut(success=True)


@router.get("/api/applications/{application_id}/documents/{document_id}/download", operation_id="download_application_document", summary="Download the file content of a document", description="Retrieve the raw binary file data for a specific document.")
async def download_application_document(application_id: int, document_id: int):
    session = SessionLocal()
    document = session.query(ApplicationDocument).filter(
        ApplicationDocument.id == document_id,
        ApplicationDocument.application_id == application_id,
    ).first()
    if document is None:
        session.close()
        raise HTTPException(status_code=404, detail="Document not found")
    content = document.file_data
    file_name = document.file_name
    file_type = document.file_type
    session.close()
    return Response(content=content, media_type=file_type, headers={"Content-Disposition": "attachment; filename=" + file_name})


@router.delete("/api/application-documents/{document_id}", response_model=SuccessOut, operation_id="delete_application_document_by_id", summary="Delete an application document by ID", description="Delete an uploaded document from an application.")
async def delete_application_document_by_id(document_id: int):
    session = SessionLocal()
    document = session.query(ApplicationDocument).filter(ApplicationDocument.id == document_id).first()
    if document is None:
        session.close()
        raise HTTPException(status_code=404, detail="Document not found")
    session.delete(document)
    session.commit()
    session.close()
    return SuccessOut(success=True)