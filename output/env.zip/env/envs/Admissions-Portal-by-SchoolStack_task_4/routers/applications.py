from datetime import datetime
from fastapi import APIRouter, Body, HTTPException
from sqlalchemy.exc import IntegrityError
from database import SessionLocal
from models import Application, ApplicationForm
from schemas import (
    ApplicationOut, ApplicationCreate, ApplicationUpdate, ApplicationListOut,
    SuccessOut
)

router = APIRouter(tags=["Applications"])

CURRENT_USER_ID = 1

VALID_STATUSES = {"draft", "submitted", "under_review", "accepted", "rejected", "waitlisted"}


def _validate_status(status):
    if status not in VALID_STATUSES:
        raise HTTPException(status_code=400, detail="Invalid application status")


@router.get("/api/application-forms/{form_id}/applications", response_model=ApplicationListOut, operation_id="list_applications", summary="List applications for a form", description="Retrieve all applications submitted for a given form.")
async def list_applications(form_id: int, status: str = None):
    session = SessionLocal()
    query = session.query(Application).filter(Application.form_id == form_id)
    if status is not None:
        query = query.filter(Application.status == status)
    applications = query.order_by(Application.id).all()
    result = ApplicationListOut(applications=applications)
    session.close()
    return result


@router.post("/api/application-forms/{form_id}/applications", response_model=ApplicationOut, operation_id="create_application", summary="Create a new application", description="Start a new application for the specified form.")
async def create_application(form_id: int, payload: ApplicationCreate = Body(...)):
    session = SessionLocal()
    form = session.query(ApplicationForm).filter(ApplicationForm.id == form_id).first()
    if form is None:
        session.close()
        raise HTTPException(status_code=404, detail="Application form not found")
    application = Application(
        form_id=form_id,
        applicant_user_id=payload.applicant_user_id if payload.applicant_user_id is not None else CURRENT_USER_ID,
        status="draft",
    )
    session.add(application)
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Invalid application data")
    session.refresh(application)
    result = ApplicationOut.model_validate(application)
    session.close()
    return result


@router.get("/api/applications/{application_id}", response_model=ApplicationOut, operation_id="get_application", summary="Get an application by ID", description="Retrieve details of a specific application.")
async def get_application(application_id: int):
    session = SessionLocal()
    application = session.query(Application).filter(Application.id == application_id).first()
    if application is None:
        session.close()
        raise HTTPException(status_code=404, detail="Application not found")
    result = ApplicationOut.model_validate(application)
    session.close()
    return result


@router.put("/api/applications/{application_id}", response_model=ApplicationOut, operation_id="update_application", summary="Update an application", description="Update the status or details of an application.")
async def update_application(application_id: int, payload: ApplicationUpdate = Body(...)):
    if payload.status is not None:
        _validate_status(payload.status)
    session = SessionLocal()
    application = session.query(Application).filter(Application.id == application_id).first()
    if application is None:
        session.close()
        raise HTTPException(status_code=404, detail="Application not found")
    if payload.status is not None:
        application.status = payload.status
    if payload.submitted_at is not None:
        application.submitted_at = payload.submitted_at
    application.updated_at = datetime.utcnow()
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Invalid application data")
    session.refresh(application)
    result = ApplicationOut.model_validate(application)
    session.close()
    return result


@router.delete("/api/applications/{application_id}", response_model=SuccessOut, operation_id="delete_application", summary="Delete an application", description="Delete an application and all associated data.")
async def delete_application(application_id: int):
    session = SessionLocal()
    application = session.query(Application).filter(Application.id == application_id).first()
    if application is None:
        session.close()
        raise HTTPException(status_code=404, detail="Application not found")
    session.delete(application)
    session.commit()
    session.close()
    return SuccessOut(success=True)