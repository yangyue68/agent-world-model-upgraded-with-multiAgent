from datetime import datetime
from fastapi import APIRouter, Body, HTTPException
from sqlalchemy.exc import IntegrityError
from database import SessionLocal
from models import ApplicationForm, FormSection, FormField
from schemas import (
    FormFieldOut, FormFieldCreate, FormFieldUpdate, FormFieldListOut,
    SuccessOut, DeletedOut
)

router = APIRouter(tags=["FormFields"])

CURRENT_USER_ID = 1

VALID_FIELD_TYPES = {"text", "email", "date", "number", "textarea", "file", "recommendation_request"}


def _validate_field_type(field_type):
    if field_type not in VALID_FIELD_TYPES:
        raise HTTPException(status_code=400, detail="Invalid field_type")


@router.get("/api/application-forms/{form_id}/sections/{section_id}/fields", response_model=FormFieldListOut, operation_id="list_form_fields", summary="List fields in a form section", description="Retrieve all fields for a section in a form created by user_id=1.")
async def list_form_fields(form_id: int, section_id: int):
    session = SessionLocal()
    form = session.query(ApplicationForm).filter(
        ApplicationForm.id == form_id,
        ApplicationForm.created_by == CURRENT_USER_ID,
    ).first()
    if form is None:
        session.close()
        raise HTTPException(status_code=404, detail="Application form not found")
    section = session.query(FormSection).filter(
        FormSection.id == section_id,
        FormSection.form_id == form_id,
    ).first()
    if section is None:
        session.close()
        raise HTTPException(status_code=404, detail="Form section not found")
    fields = session.query(FormField).filter(FormField.section_id == section_id).order_by(FormField.position).all()
    result = FormFieldListOut(fields=fields)
    session.close()
    return result


@router.post("/api/application-forms/{form_id}/sections/{section_id}/fields", response_model=FormFieldOut, operation_id="create_form_field", summary="Create a new field in a form section", description="Add a field to a section in a form created by user_id=1.")
async def create_form_field(form_id: int, section_id: int, payload: FormFieldCreate = Body(...)):
    _validate_field_type(payload.field_type)
    session = SessionLocal()
    form = session.query(ApplicationForm).filter(
        ApplicationForm.id == form_id,
        ApplicationForm.created_by == CURRENT_USER_ID,
    ).first()
    if form is None:
        session.close()
        raise HTTPException(status_code=404, detail="Application form not found")
    section = session.query(FormSection).filter(
        FormSection.id == section_id,
        FormSection.form_id == form_id,
    ).first()
    if section is None:
        session.close()
        raise HTTPException(status_code=404, detail="Form section not found")
    field = FormField(
        section_id=section_id,
        label=payload.label,
        field_type=payload.field_type,
        is_required=payload.is_required if payload.is_required is not None else 0,
        position=payload.position if payload.position is not None else 0,
        placeholder=payload.placeholder,
        help_text=payload.help_text,
        validation_rules=payload.validation_rules,
    )
    session.add(field)
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Invalid form field data")
    session.refresh(field)
    result = FormFieldOut.model_validate(field)
    session.close()
    return result


@router.get("/api/application-forms/{form_id}/sections/{section_id}/fields/{field_id}", response_model=FormFieldOut, operation_id="get_form_field", summary="Get a form field by ID", description="Retrieve a single field belonging to a section in a form created by user_id=1.")
async def get_form_field(form_id: int, section_id: int, field_id: int):
    session = SessionLocal()
    form = session.query(ApplicationForm).filter(
        ApplicationForm.id == form_id,
        ApplicationForm.created_by == CURRENT_USER_ID,
    ).first()
    if form is None:
        session.close()
        raise HTTPException(status_code=404, detail="Application form not found")
    section = session.query(FormSection).filter(
        FormSection.id == section_id,
        FormSection.form_id == form_id,
    ).first()
    if section is None:
        session.close()
        raise HTTPException(status_code=404, detail="Form section not found")
    field = session.query(FormField).filter(
        FormField.id == field_id,
        FormField.section_id == section_id,
    ).first()
    if field is None:
        session.close()
        raise HTTPException(status_code=404, detail="Form field not found")
    result = FormFieldOut.model_validate(field)
    session.close()
    return result


@router.put("/api/application-forms/{form_id}/sections/{section_id}/fields/{field_id}", response_model=FormFieldOut, operation_id="update_form_field", summary="Update a form field", description="Update all fields of a form field in a form created by user_id=1.")
async def update_form_field(form_id: int, section_id: int, field_id: int, payload: FormFieldUpdate = Body(...)):
    if payload.field_type is not None:
        _validate_field_type(payload.field_type)
    session = SessionLocal()
    form = session.query(ApplicationForm).filter(
        ApplicationForm.id == form_id,
        ApplicationForm.created_by == CURRENT_USER_ID,
    ).first()
    if form is None:
        session.close()
        raise HTTPException(status_code=404, detail="Application form not found")
    section = session.query(FormSection).filter(
        FormSection.id == section_id,
        FormSection.form_id == form_id,
    ).first()
    if section is None:
        session.close()
        raise HTTPException(status_code=404, detail="Form section not found")
    field = session.query(FormField).filter(
        FormField.id == field_id,
        FormField.section_id == section_id,
    ).first()
    if field is None:
        session.close()
        raise HTTPException(status_code=404, detail="Form field not found")
    if payload.label is not None:
        field.label = payload.label
    if payload.field_type is not None:
        field.field_type = payload.field_type
    if payload.is_required is not None:
        field.is_required = payload.is_required
    if payload.position is not None:
        field.position = payload.position
    if payload.placeholder is not None:
        field.placeholder = payload.placeholder
    if payload.help_text is not None:
        field.help_text = payload.help_text
    if payload.validation_rules is not None:
        field.validation_rules = payload.validation_rules
    field.updated_at = datetime.utcnow()
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Invalid form field data")
    session.refresh(field)
    result = FormFieldOut.model_validate(field)
    session.close()
    return result


@router.delete("/api/application-forms/{form_id}/sections/{section_id}/fields/{field_id}", response_model=SuccessOut, operation_id="delete_form_field", summary="Delete a form field", description="Delete a field from a section in a form created by user_id=1.")
async def delete_form_field(form_id: int, section_id: int, field_id: int):
    session = SessionLocal()
    form = session.query(ApplicationForm).filter(
        ApplicationForm.id == form_id,
        ApplicationForm.created_by == CURRENT_USER_ID,
    ).first()
    if form is None:
        session.close()
        raise HTTPException(status_code=404, detail="Application form not found")
    section = session.query(FormSection).filter(
        FormSection.id == section_id,
        FormSection.form_id == form_id,
    ).first()
    if section is None:
        session.close()
        raise HTTPException(status_code=404, detail="Form section not found")
    field = session.query(FormField).filter(
        FormField.id == field_id,
        FormField.section_id == section_id,
    ).first()
    if field is None:
        session.close()
        raise HTTPException(status_code=404, detail="Form field not found")
    session.delete(field)
    session.commit()
    session.close()
    return SuccessOut(success=True)


@router.get("/api/forms/{form_id}/sections/{section_id}/fields", response_model=FormFieldListOut, operation_id="list_section_fields", summary="List all fields in a section", description="Retrieve all form fields for a given section ordered by position.")
async def list_section_fields(form_id: int, section_id: int):
    session = SessionLocal()
    section = session.query(FormSection).filter(
        FormSection.id == section_id,
        FormSection.form_id == form_id,
    ).first()
    if section is None:
        session.close()
        raise HTTPException(status_code=404, detail="Form section not found")
    fields = session.query(FormField).filter(FormField.section_id == section_id).order_by(FormField.position).all()
    result = FormFieldListOut(fields=fields)
    session.close()
    return result


@router.post("/api/forms/{form_id}/sections/{section_id}/fields", response_model=FormFieldOut, operation_id="create_section_field", summary="Create a new field in a section", description="Add a new form field to the specified section.")
async def create_section_field(form_id: int, section_id: int, payload: FormFieldCreate = Body(...)):
    _validate_field_type(payload.field_type)
    session = SessionLocal()
    section = session.query(FormSection).filter(
        FormSection.id == section_id,
        FormSection.form_id == form_id,
    ).first()
    if section is None:
        session.close()
        raise HTTPException(status_code=404, detail="Form section not found")
    field = FormField(
        section_id=section_id,
        label=payload.label,
        field_type=payload.field_type,
        is_required=payload.is_required if payload.is_required is not None else 0,
        position=payload.position if payload.position is not None else 0,
        placeholder=payload.placeholder,
        help_text=payload.help_text,
        validation_rules=payload.validation_rules,
    )
    session.add(field)
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Invalid form field data")
    session.refresh(field)
    result = FormFieldOut.model_validate(field)
    session.close()
    return result


@router.get("/api/forms/{form_id}/sections/{section_id}/fields/{field_id}", response_model=FormFieldOut, operation_id="get_section_field", summary="Get a specific form field", description="Retrieve details of a single form field by its ID.")
async def get_section_field(form_id: int, section_id: int, field_id: int):
    session = SessionLocal()
    field = session.query(FormField).filter(
        FormField.id == field_id,
        FormField.section_id == section_id,
    ).first()
    if field is None:
        session.close()
        raise HTTPException(status_code=404, detail="Form field not found")
    result = FormFieldOut.model_validate(field)
    session.close()
    return result


@router.put("/api/forms/{form_id}/sections/{section_id}/fields/{field_id}", response_model=FormFieldOut, operation_id="update_section_field", summary="Update a form field", description="Replace label, type, required flag, position, and other properties of a field.")
async def update_section_field(form_id: int, section_id: int, field_id: int, payload: FormFieldUpdate = Body(...)):
    if payload.field_type is not None:
        _validate_field_type(payload.field_type)
    session = SessionLocal()
    field = session.query(FormField).filter(
        FormField.id == field_id,
        FormField.section_id == section_id,
    ).first()
    if field is None:
        session.close()
        raise HTTPException(status_code=404, detail="Form field not found")
    if payload.label is not None:
        field.label = payload.label
    if payload.field_type is not None:
        field.field_type = payload.field_type
    if payload.is_required is not None:
        field.is_required = payload.is_required
    if payload.position is not None:
        field.position = payload.position
    if payload.placeholder is not None:
        field.placeholder = payload.placeholder
    if payload.help_text is not None:
        field.help_text = payload.help_text
    if payload.validation_rules is not None:
        field.validation_rules = payload.validation_rules
    field.updated_at = datetime.utcnow()
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Invalid form field data")
    session.refresh(field)
    result = FormFieldOut.model_validate(field)
    session.close()
    return result


@router.delete("/api/forms/{form_id}/sections/{section_id}/fields/{field_id}", response_model=DeletedOut, operation_id="delete_section_field", summary="Delete a form field", description="Remove a form field from a section.")
async def delete_section_field(form_id: int, section_id: int, field_id: int):
    session = SessionLocal()
    field = session.query(FormField).filter(
        FormField.id == field_id,
        FormField.section_id == section_id,
    ).first()
    if field is None:
        session.close()
        raise HTTPException(status_code=404, detail="Form field not found")
    session.delete(field)
    session.commit()
    session.close()
    return DeletedOut(deleted=True)


@router.get("/api/form-sections/{section_id}/fields", response_model=FormFieldListOut, operation_id="list_form_fields_by_section", summary="List all fields in a form section", description="Retrieve all form fields belonging to a specific section, ordered by position.")
async def list_form_fields_by_section(section_id: int):
    session = SessionLocal()
    fields = session.query(FormField).filter(FormField.section_id == section_id).order_by(FormField.position).all()
    result = FormFieldListOut(fields=fields)
    session.close()
    return result


@router.post("/api/form-sections/{section_id}/fields", response_model=FormFieldOut, operation_id="create_form_field_by_section", summary="Create a new form field in a section", description="Add a single form field to the specified section with label, type, and validation.")
async def create_form_field_by_section(section_id: int, payload: FormFieldCreate = Body(...)):
    _validate_field_type(payload.field_type)
    session = SessionLocal()
    section = session.query(FormSection).filter(FormSection.id == section_id).first()
    if section is None:
        session.close()
        raise HTTPException(status_code=404, detail="Form section not found")
    field = FormField(
        section_id=section_id,
        label=payload.label,
        field_type=payload.field_type,
        is_required=payload.is_required if payload.is_required is not None else 0,
        position=payload.position if payload.position is not None else 0,
        placeholder=payload.placeholder,
        help_text=payload.help_text,
        validation_rules=payload.validation_rules,
    )
    session.add(field)
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Invalid form field data")
    session.refresh(field)
    result = FormFieldOut.model_validate(field)
    session.close()
    return result


@router.get("/api/form-fields/{field_id}", response_model=FormFieldOut, operation_id="get_form_field_by_id", summary="Get a single form field by ID", description="Retrieve detailed information about a specific form field.")
async def get_form_field_by_id(field_id: int):
    session = SessionLocal()
    field = session.query(FormField).filter(FormField.id == field_id).first()
    if field is None:
        session.close()
        raise HTTPException(status_code=404, detail="Form field not found")
    result = FormFieldOut.model_validate(field)
    session.close()
    return result


@router.put("/api/form-fields/{field_id}", response_model=FormFieldOut, operation_id="replace_form_field", summary="Replace a form field", description="Update all mutable properties of a form field in a single operation.")
async def replace_form_field(field_id: int, payload: FormFieldUpdate = Body(...)):
    if payload.field_type is not None:
        _validate_field_type(payload.field_type)
    session = SessionLocal()
    field = session.query(FormField).filter(FormField.id == field_id).first()
    if field is None:
        session.close()
        raise HTTPException(status_code=404, detail="Form field not found")
    if payload.label is not None:
        field.label = payload.label
    if payload.field_type is not None:
        field.field_type = payload.field_type
    if payload.is_required is not None:
        field.is_required = payload.is_required
    if payload.position is not None:
        field.position = payload.position
    if payload.placeholder is not None:
        field.placeholder = payload.placeholder
    if payload.help_text is not None:
        field.help_text = payload.help_text
    if payload.validation_rules is not None:
        field.validation_rules = payload.validation_rules
    field.updated_at = datetime.utcnow()
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Invalid form field data")
    session.refresh(field)
    result = FormFieldOut.model_validate(field)
    session.close()
    return result


@router.patch("/api/form-fields/{field_id}", response_model=FormFieldOut, operation_id="patch_form_field", summary="Partially update a form field", description="Update one or more properties of a form field without replacing the entire resource.")
async def patch_form_field(field_id: int, payload: FormFieldUpdate = Body(...)):
    if payload.field_type is not None:
        _validate_field_type(payload.field_type)
    session = SessionLocal()
    field = session.query(FormField).filter(FormField.id == field_id).first()
    if field is None:
        session.close()
        raise HTTPException(status_code=404, detail="Form field not found")
    if payload.label is not None:
        field.label = payload.label
    if payload.field_type is not None:
        field.field_type = payload.field_type
    if payload.is_required is not None:
        field.is_required = payload.is_required
    if payload.position is not None:
        field.position = payload.position
    if payload.placeholder is not None:
        field.placeholder = payload.placeholder
    if payload.help_text is not None:
        field.help_text = payload.help_text
    if payload.validation_rules is not None:
        field.validation_rules = payload.validation_rules
    field.updated_at = datetime.utcnow()
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Invalid form field data")
    session.refresh(field)
    result = FormFieldOut.model_validate(field)
    session.close()
    return result


@router.delete("/api/form-fields/{field_id}", response_model=DeletedOut, operation_id="delete_form_field_by_id", summary="Delete a form field", description="Remove a form field and its associated answers from the system.")
async def delete_form_field_by_id(field_id: int):
    session = SessionLocal()
    field = session.query(FormField).filter(FormField.id == field_id).first()
    if field is None:
        session.close()
        raise HTTPException(status_code=404, detail="Form field not found")
    session.delete(field)
    session.commit()
    session.close()
    return DeletedOut(deleted=True)