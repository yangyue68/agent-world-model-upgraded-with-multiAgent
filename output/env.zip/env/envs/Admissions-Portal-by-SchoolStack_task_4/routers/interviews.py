from datetime import datetime
from fastapi import APIRouter, Body, HTTPException
from pydantic import BaseModel
from typing import Optional, List
from database import SessionLocal
from models import Application

router = APIRouter(prefix="/api/interviews", tags=["Interviews"])

INTERVIEWS = []
AVAILABILITY = []


class InterviewCreate(BaseModel):
    application_id: int
    scheduled_at: datetime
    duration_minutes: Optional[int] = 30
    interviewer: Optional[str] = None
    location: Optional[str] = None


class AvailabilityCreate(BaseModel):
    interviewer: str
    available_from: datetime
    available_to: datetime


@router.post("/schedule", operation_id="schedule_interview", summary="Schedule an interview", description="Schedule an interview for an application.")
async def schedule_interview(payload: InterviewCreate = Body(...)):
    session = SessionLocal()
    application = session.query(Application).filter(Application.id == payload.application_id).first()
    if application is None:
        session.close()
        raise HTTPException(status_code=404, detail="Application not found")
    interview = {
        "id": len(INTERVIEWS) + 1,
        "application_id": payload.application_id,
        "scheduled_at": payload.scheduled_at.isoformat(),
        "duration_minutes": payload.duration_minutes,
        "interviewer": payload.interviewer,
        "location": payload.location,
        "status": "scheduled",
        "created_at": datetime.utcnow().isoformat(),
    }
    INTERVIEWS.append(interview)
    session.close()
    return interview


@router.get("/schedule", operation_id="list_interviews", summary="List scheduled interviews", description="Retrieve all scheduled interviews, optionally filtered by application.")
async def list_interviews(application_id: int = None):
    if application_id is None:
        return {"interviews": INTERVIEWS, "total": len(INTERVIEWS)}
    filtered = [i for i in INTERVIEWS if i["application_id"] == application_id]
    return {"interviews": filtered, "total": len(filtered)}


@router.post("/availability", operation_id="create_interview_availability", summary="Create interview availability", description="Add an interviewer availability window.")
async def create_interview_availability(payload: AvailabilityCreate = Body(...)):
    availability = {
        "id": len(AVAILABILITY) + 1,
        "interviewer": payload.interviewer,
        "available_from": payload.available_from.isoformat(),
        "available_to": payload.available_to.isoformat(),
        "created_at": datetime.utcnow().isoformat(),
    }
    AVAILABILITY.append(availability)
    return availability


@router.get("/availability", operation_id="list_interview_availability", summary="List interview availability", description="Retrieve all interviewer availability windows.")
async def list_interview_availability():
    return {"availability": AVAILABILITY, "total": len(AVAILABILITY)}