from datetime import datetime
from fastapi import APIRouter, Body, HTTPException
from pydantic import BaseModel
from typing import Optional
from database import SessionLocal
from models import Application, ApplicationForm

router = APIRouter(prefix="/api/notifications", tags=["Notifications"])

MESSAGE_LOG = []


class NotificationRequest(BaseModel):
    application_id: Optional[int] = None
    form_id: Optional[int] = None
    recipient_email: Optional[str] = None
    message_type: Optional[str] = "confirmation"


@router.post("/confirmation", operation_id="send_confirmation_email", summary="Send confirmation email", description="Simulate sending a confirmation email and log the message.")
async def send_confirmation_email(payload: NotificationRequest = Body(...)):
    session = SessionLocal()
    recipient = payload.recipient_email
    if payload.application_id is not None:
        application = session.query(Application).filter(Application.id == payload.application_id).first()
        if application is None:
            session.close()
            raise HTTPException(status_code=404, detail="Application not found")
    message = {
        "type": "confirmation",
        "application_id": payload.application_id,
        "form_id": payload.form_id,
        "recipient_email": recipient,
        "sent_at": datetime.utcnow().isoformat(),
        "body": "Your application has been received. Thank you for applying.",
    }
    MESSAGE_LOG.append(message)
    session.close()
    return message


@router.post("/status-update", operation_id="send_status_update", summary="Send status update", description="Simulate sending a status update notification and log the message.")
async def send_status_update(payload: NotificationRequest = Body(...)):
    session = SessionLocal()
    status = None
    if payload.application_id is not None:
        application = session.query(Application).filter(Application.id == payload.application_id).first()
        if application is None:
            session.close()
            raise HTTPException(status_code=404, detail="Application not found")
        status = application.status
    message = {
        "type": "status_update",
        "application_id": payload.application_id,
        "status": status,
        "recipient_email": payload.recipient_email,
        "sent_at": datetime.utcnow().isoformat(),
        "body": "Your application status has been updated.",
    }
    MESSAGE_LOG.append(message)
    session.close()
    return message


@router.post("/reminder", operation_id="send_reminder_nudge", summary="Send reminder nudge", description="Simulate sending a reminder nudge for incomplete applications and log the message.")
async def send_reminder_nudge(payload: NotificationRequest = Body(...)):
    session = SessionLocal()
    if payload.application_id is not None:
        application = session.query(Application).filter(Application.id == payload.application_id).first()
        if application is None:
            session.close()
            raise HTTPException(status_code=404, detail="Application not found")
    message = {
        "type": "reminder",
        "application_id": payload.application_id,
        "recipient_email": payload.recipient_email,
        "sent_at": datetime.utcnow().isoformat(),
        "body": "Reminder: your application is incomplete. Please submit the missing items.",
    }
    MESSAGE_LOG.append(message)
    session.close()
    return message


@router.get("/log", operation_id="list_notification_log", summary="List notification log", description="Retrieve all simulated notification messages that have been logged.")
async def list_notification_log():
    return {"messages": MESSAGE_LOG, "total": len(MESSAGE_LOG)}