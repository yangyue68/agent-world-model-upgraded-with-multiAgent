from datetime import datetime
from fastapi import APIRouter, Body, HTTPException
from sqlalchemy.exc import IntegrityError
from database import SessionLocal
from models import User
from schemas import UserOut, UserCreate

router = APIRouter(prefix="/api/users", tags=["Users"])


@router.get("", response_model=list[UserOut], operation_id="list_users", summary="List users", description="Retrieve all users in the system.")
async def list_users():
    session = SessionLocal()
    users = session.query(User).order_by(User.id).all()
    result = [UserOut.model_validate(u) for u in users]
    session.close()
    return result


@router.post("", response_model=UserOut, operation_id="create_user", summary="Create a user", description="Create a new user record.")
async def create_user(payload: UserCreate = Body(...)):
    session = SessionLocal()
    user = User(username=payload.username, email=payload.email, full_name=payload.full_name)
    session.add(user)
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Username or email already exists")
    session.refresh(user)
    result = UserOut.model_validate(user)
    session.close()
    return result


@router.get("/{user_id}", response_model=UserOut, operation_id="get_user", summary="Get a user by ID", description="Retrieve a single user by their ID.")
async def get_user(user_id: int):
    session = SessionLocal()
    user = session.query(User).filter(User.id == user_id).first()
    if user is None:
        session.close()
        raise HTTPException(status_code=404, detail="User not found")
    result = UserOut.model_validate(user)
    session.close()
    return result