from datetime import datetime
from fastapi import APIRouter, Body, HTTPException
from pydantic import BaseModel
from typing import Optional, List
from database import SessionLocal
from models import Application, ApplicationFee

router = APIRouter(prefix="/api/cohorts", tags=["Cohorts"])

COHORTS = []
ENROLLMENTS = []
DEPOSITS = []
CONFIRMATIONS = []


class CohortCreate(BaseModel):
    name: str
    form_id: Optional[int] = None
    capacity: Optional[int] = 0


class EnrollRequest(BaseModel):
    cohort_id: int
    application_id: int


class DepositRequest(BaseModel):
    application_id: int
    amount_cents: int
    currency: Optional[str] = "USD"


class PromoteRequest(BaseModel):
    form_id: int
    seats: int


@router.post("", operation_id="create_cohort", summary="Create a cohort", description="Create a new cohort for accepted applicants.")
async def create_cohort(payload: CohortCreate = Body(...)):
    cohort = {
        "id": len(COHORTS) + 1,
        "name": payload.name,
        "form_id": payload.form_id,
        "capacity": payload.capacity,
        "created_at": datetime.utcnow().isoformat(),
    }
    COHORTS.append(cohort)
    return cohort


@router.get("", operation_id="list_cohorts", summary="List cohorts", description="Retrieve all cohorts.")
async def list_cohorts():
    return {"cohorts": COHORTS, "total": len(COHORTS)}


@router.post("/enroll", operation_id="enroll_applicant", summary="Enroll an accepted applicant", description="Enroll an accepted applicant into a cohort.")
async def enroll_applicant(payload: EnrollRequest = Body(...)):
    session = SessionLocal()
    application = session.query(Application).filter(Application.id == payload.application_id).first()
    if application is None:
        session.close()
        raise HTTPException(status_code=404, detail="Application not found")
    if application.status != "accepted":
        session.close()
        raise HTTPException(status_code=400, detail="Only accepted applicants can be enrolled")
    enrollment = {
        "id": len(ENROLLMENTS) + 1,
        "cohort_id": payload.cohort_id,
        "application_id": payload.application_id,
        "enrolled_at": datetime.utcnow().isoformat(),
    }
    ENROLLMENTS.append(enrollment)
    session.close()
    return enrollment


@router.get("/enrollments", operation_id="list_enrollments", summary="List enrollments", description="Retrieve all cohort enrollments.")
async def list_enrollments():
    return {"enrollments": ENROLLMENTS, "total": len(ENROLLMENTS)}


@router.post("/deposits", operation_id="collect_tuition_deposit", summary="Collect a tuition deposit", description="Simulate collecting a tuition deposit for an application.")
async def collect_tuition_deposit(payload: DepositRequest = Body(...)):
    session = SessionLocal()
    application = session.query(Application).filter(Application.id == payload.application_id).first()
    if application is None:
        session.close()
        raise HTTPException(status_code=404, detail="Application not found")
    deposit = {
        "id": len(DEPOSITS) + 1,
        "application_id": payload.application_id,
        "amount_cents": payload.amount_cents,
        "currency": payload.currency,
        "status": "paid",
        "paid_at": datetime.utcnow().isoformat(),
    }
    DEPOSITS.append(deposit)
    session.close()
    return deposit


@router.get("/deposits", operation_id="list_tuition_deposits", summary="List tuition deposits", description="Retrieve all simulated tuition deposits.")
async def list_tuition_deposits():
    return {"deposits": DEPOSITS, "total": len(DEPOSITS)}


@router.post("/promote-waitlist", operation_id="promote_waitlisted_applicants", summary="Promote waitlisted applicants", description="Promote waitlisted applicants to accepted when seats open.")
async def promote_waitlisted_applicants(payload: PromoteRequest = Body(...)):
    session = SessionLocal()
    waitlisted = session.query(Application).filter(
        Application.form_id == payload.form_id,
        Application.status == "waitlisted",
    ).order_by(Application.id).limit(payload.seats).all()
    promoted = []
    for application in waitlisted:
        application.status = "accepted"
        application.updated_at = datetime.utcnow()
        promoted.append(application.id)
    session.commit()
    session.close()
    return {"promoted": promoted, "count": len(promoted)}


@router.post("/registration-confirmations", operation_id="issue_registration_confirmation", summary="Issue a registration confirmation", description="Issue a registration confirmation for an enrolled applicant.")
async def issue_registration_confirmation(payload: EnrollRequest = Body(...)):
    session = SessionLocal()
    application = session.query(Application).filter(Application.id == payload.application_id).first()
    if application is None:
        session.close()
        raise HTTPException(status_code=404, detail="Application not found")
    confirmation = {
        "id": len(CONFIRMATIONS) + 1,
        "cohort_id": payload.cohort_id,
        "application_id": payload.application_id,
        "confirmation_number": "REG-" + str(payload.application_id) + "-" + str(len(CONFIRMATIONS) + 1),
        "issued_at": datetime.utcnow().isoformat(),
    }
    CONFIRMATIONS.append(confirmation)
    session.close()
    return confirmation


@router.get("/registration-confirmations", operation_id="list_registration_confirmations", summary="List registration confirmations", description="Retrieve all issued registration confirmations.")
async def list_registration_confirmations():
    return {"confirmations": CONFIRMATIONS, "total": len(CONFIRMATIONS)}