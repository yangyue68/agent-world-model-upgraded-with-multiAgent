from datetime import datetime
from fastapi import APIRouter, Body, HTTPException
from sqlalchemy.exc import IntegrityError
from database import SessionLocal
from models import Application, RecommendationRequest
from schemas import (
    RecommendationRequestOut, RecommendationRequestCreate, RecommendationRequestUpdate,
    RecommendationRequestListOut, MessageOut
)

router = APIRouter(tags=["RecommendationRequests"])

VALID_STATUSES = {"pending", "sent", "completed", "declined"}


def _validate_status(status):
    if status not in VALID_STATUSES:
        raise HTTPException(status_code=400, detail="Invalid recommendation request status")


@router.get("/api/applications/{application_id}/recommendation-requests", response_model=RecommendationRequestListOut, operation_id="list_recommendation_requests", summary="List recommendation requests for an application", description="Retrieve all recommendation requests associated with the given application.")
async def list_recommendation_requests(application_id: int, status: str = None):
    session = SessionLocal()
    application = session.query(Application).filter(Application.id == application_id).first()
    if application is None:
        session.close()
        raise HTTPException(status_code=404, detail="Application not found")
    query = session.query(RecommendationRequest).filter(RecommendationRequest.application_id == application_id)
    if status is not None:
        query = query.filter(RecommendationRequest.status == status)
    requests = query.order_by(RecommendationRequest.id).all()
    result = RecommendationRequestListOut(recommendation_requests=requests)
    session.close()
    return result


@router.post("/api/applications/{application_id}/recommendation-requests", response_model=RecommendationRequestOut, operation_id="create_recommendation_request", summary="Create a recommendation request for an application", description="Add a new recommendation request to the specified application.")
async def create_recommendation_request(application_id: int, payload: RecommendationRequestCreate = Body(...)):
    session = SessionLocal()
    application = session.query(Application).filter(Application.id == application_id).first()
    if application is None:
        session.close()
        raise HTTPException(status_code=404, detail="Application not found")
    request = RecommendationRequest(
        application_id=application_id,
        requirement_id=payload.requirement_id,
        recommender_name=payload.recommender_name,
        recommender_email=payload.recommender_email,
        recommender_phone=payload.recommender_phone,
        relationship=payload.relationship,
        status="pending",
        requested_at=datetime.utcnow(),
    )
    session.add(request)
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Invalid recommendation request data")
    session.refresh(request)
    result = RecommendationRequestOut.model_validate(request)
    session.close()
    return result


@router.get("/api/applications/{application_id}/recommendation-requests/{id}", response_model=RecommendationRequestOut, operation_id="get_recommendation_request", summary="Get a recommendation request by ID", description="Retrieve a single recommendation request for the given application.")
async def get_recommendation_request(application_id: int, id: int):
    session = SessionLocal()
    request = session.query(RecommendationRequest).filter(
        RecommendationRequest.id == id,
        RecommendationRequest.application_id == application_id,
    ).first()
    if request is None:
        session.close()
        raise HTTPException(status_code=404, detail="Recommendation request not found")
    result = RecommendationRequestOut.model_validate(request)
    session.close()
    return result


@router.put("/api/applications/{application_id}/recommendation-requests/{id}", response_model=RecommendationRequestOut, operation_id="update_recommendation_request", summary="Update a recommendation request", description="Replace all fields of an existing recommendation request.")
async def update_recommendation_request(application_id: int, id: int, payload: RecommendationRequestUpdate = Body(...)):
    if payload.status is not None:
        _validate_status(payload.status)
    session = SessionLocal()
    request = session.query(RecommendationRequest).filter(
        RecommendationRequest.id == id,
        RecommendationRequest.application_id == application_id,
    ).first()
    if request is None:
        session.close()
        raise HTTPException(status_code=404, detail="Recommendation request not found")
    if payload.requirement_id is not None:
        request.requirement_id = payload.requirement_id
    if payload.recommender_name is not None:
        request.recommender_name = payload.recommender_name
    if payload.recommender_email is not None:
        request.recommender_email = payload.recommender_email
    if payload.recommender_phone is not None:
        request.recommender_phone = payload.recommender_phone
    if payload.relationship is not None:
        request.relationship = payload.relationship
    if payload.status is not None:
        request.status = payload.status
    if payload.completed_at is not None:
        request.completed_at = payload.completed_at
    request.updated_at = datetime.utcnow()
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Invalid recommendation request data")
    session.refresh(request)
    result = RecommendationRequestOut.model_validate(request)
    session.close()
    return result


@router.patch("/api/applications/{application_id}/recommendation-requests/{id}", response_model=RecommendationRequestOut, operation_id="patch_recommendation_request", summary="Partially update a recommendation request", description="Update one or more fields of an existing recommendation request.")
async def patch_recommendation_request(application_id: int, id: int, payload: RecommendationRequestUpdate = Body(...)):
    if payload.status is not None:
        _validate_status(payload.status)
    session = SessionLocal()
    request = session.query(RecommendationRequest).filter(
        RecommendationRequest.id == id,
        RecommendationRequest.application_id == application_id,
    ).first()
    if request is None:
        session.close()
        raise HTTPException(status_code=404, detail="Recommendation request not found")
    if payload.requirement_id is not None:
        request.requirement_id = payload.requirement_id
    if payload.recommender_name is not None:
        request.recommender_name = payload.recommender_name
    if payload.recommender_email is not None:
        request.recommender_email = payload.recommender_email
    if payload.recommender_phone is not None:
        request.recommender_phone = payload.recommender_phone
    if payload.relationship is not None:
        request.relationship = payload.relationship
    if payload.status is not None:
        request.status = payload.status
    if payload.completed_at is not None:
        request.completed_at = payload.completed_at
    request.updated_at = datetime.utcnow()
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Invalid recommendation request data")
    session.refresh(request)
    result = RecommendationRequestOut.model_validate(request)
    session.close()
    return result


@router.delete("/api/applications/{application_id}/recommendation-requests/{id}", response_model=MessageOut, operation_id="delete_recommendation_request", summary="Delete a recommendation request", description="Remove a recommendation request from the application.")
async def delete_recommendation_request(application_id: int, id: int):
    session = SessionLocal()
    request = session.query(RecommendationRequest).filter(
        RecommendationRequest.id == id,
        RecommendationRequest.application_id == application_id,
    ).first()
    if request is None:
        session.close()
        raise HTTPException(status_code=404, detail="Recommendation request not found")
    session.delete(request)
    session.commit()
    session.close()
    return MessageOut(message="Recommendation request deleted successfully")


@router.put("/api/recommendation-requests/{request_id}", response_model=RecommendationRequestOut, operation_id="update_recommendation_request_by_id", summary="Update a recommendation request by ID", description="Update the status or details of a recommendation request.")
async def update_recommendation_request_by_id(request_id: int, payload: RecommendationRequestUpdate = Body(...)):
    if payload.status is not None:
        _validate_status(payload.status)
    session = SessionLocal()
    request = session.query(RecommendationRequest).filter(RecommendationRequest.id == request_id).first()
    if request is None:
        session.close()
        raise HTTPException(status_code=404, detail="Recommendation request not found")
    if payload.requirement_id is not None:
        request.requirement_id = payload.requirement_id
    if payload.recommender_name is not None:
        request.recommender_name = payload.recommender_name
    if payload.recommender_email is not None:
        request.recommender_email = payload.recommender_email
    if payload.recommender_phone is not None:
        request.recommender_phone = payload.recommender_phone
    if payload.relationship is not None:
        request.relationship = payload.relationship
    if payload.status is not None:
        request.status = payload.status
    if payload.completed_at is not None:
        request.completed_at = payload.completed_at
    request.updated_at = datetime.utcnow()
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Invalid recommendation request data")
    session.refresh(request)
    result = RecommendationRequestOut.model_validate(request)
    session.close()
    return result


@router.delete("/api/recommendation-requests/{request_id}", response_model=MessageOut, operation_id="delete_recommendation_request_by_id", summary="Delete a recommendation request by ID", description="Delete a recommendation request.")
async def delete_recommendation_request_by_id(request_id: int):
    session = SessionLocal()
    request = session.query(RecommendationRequest).filter(RecommendationRequest.id == request_id).first()
    if request is None:
        session.close()
        raise HTTPException(status_code=404, detail="Recommendation request not found")
    session.delete(request)
    session.commit()
    session.close()
    return MessageOut(message="Recommendation request deleted successfully")