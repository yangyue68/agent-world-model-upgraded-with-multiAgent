from datetime import datetime
from fastapi import APIRouter, Body, HTTPException
from sqlalchemy.exc import IntegrityError
from database import SessionLocal
from models import ApplicationForm, FormSection
from schemas import (
    FormSectionOut, FormSectionCreate, FormSectionUpdate, FormSectionListOut,
    SuccessOut, DeletedOut
)

router = APIRouter(tags=["FormSections"])

CURRENT_USER_ID = 1


def _get_form(session, form_id):
    return session.query(ApplicationForm).filter(
        ApplicationForm.id == form_id,
        ApplicationForm.created_by == CURRENT_USER_ID,
    ).first()


@router.get("/api/application-forms/{form_id}/sections", response_model=FormSectionListOut, operation_id="list_form_sections", summary="List sections of an application form", description="Retrieve all sections for a given form created by user_id=1.")
async def list_form_sections(form_id: int):
    session = SessionLocal()
    form = _get_form(session, form_id)
    if form is None:
        session.close()
        raise HTTPException(status_code=404, detail="Application form not found")
    sections = session.query(FormSection).filter(FormSection.form_id == form_id).order_by(FormSection.position).all()
    result = FormSectionListOut(sections=sections)
    session.close()
    return result


@router.post("/api/application-forms/{form_id}/sections", response_model=FormSectionOut, operation_id="create_form_section", summary="Create a new section in an application form", description="Add a section to a form created by user_id=1.")
async def create_form_section(form_id: int, payload: FormSectionCreate = Body(...)):
    session = SessionLocal()
    form = _get_form(session, form_id)
    if form is None:
        session.close()
        raise HTTPException(status_code=404, detail="Application form not found")
    section = FormSection(
        form_id=form_id,
        title=payload.title,
        position=payload.position if payload.position is not None else 0,
    )
    session.add(section)
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Section title already exists for this form")
    session.refresh(section)
    result = FormSectionOut.model_validate(section)
    session.close()
    return result


@router.get("/api/application-forms/{form_id}/sections/{section_id}", response_model=FormSectionOut, operation_id="get_form_section", summary="Get a form section by ID", description="Retrieve a single section belonging to a form created by user_id=1.")
async def get_form_section(form_id: int, section_id: int):
    session = SessionLocal()
    form = _get_form(session, form_id)
    if form is None:
        session.close()
        raise HTTPException(status_code=404, detail="Application form not found")
    section = session.query(FormSection).filter(
        FormSection.id == section_id,
        FormSection.form_id == form_id,
    ).first()
    if section is None:
        session.close()
        raise HTTPException(status_code=404, detail="Form section not found")
    result = FormSectionOut.model_validate(section)
    session.close()
    return result


@router.put("/api/application-forms/{form_id}/sections/{section_id}", response_model=FormSectionOut, operation_id="update_form_section", summary="Update a form section", description="Update title and position of a section in a form created by user_id=1.")
async def update_form_section(form_id: int, section_id: int, payload: FormSectionUpdate = Body(...)):
    session = SessionLocal()
    form = _get_form(session, form_id)
    if form is None:
        session.close()
        raise HTTPException(status_code=404, detail="Application form not found")
    section = session.query(FormSection).filter(
        FormSection.id == section_id,
        FormSection.form_id == form_id,
    ).first()
    if section is None:
        session.close()
        raise HTTPException(status_code=404, detail="Form section not found")
    if payload.title is not None:
        section.title = payload.title
    if payload.position is not None:
        section.position = payload.position
    section.updated_at = datetime.utcnow()
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Section title already exists for this form")
    session.refresh(section)
    result = FormSectionOut.model_validate(section)
    session.close()
    return result


@router.delete("/api/application-forms/{form_id}/sections/{section_id}", response_model=SuccessOut, operation_id="delete_form_section", summary="Delete a form section", description="Delete a section from a form created by user_id=1.")
async def delete_form_section(form_id: int, section_id: int):
    session = SessionLocal()
    form = _get_form(session, form_id)
    if form is None:
        session.close()
        raise HTTPException(status_code=404, detail="Application form not found")
    section = session.query(FormSection).filter(
        FormSection.id == section_id,
        FormSection.form_id == form_id,
    ).first()
    if section is None:
        session.close()
        raise HTTPException(status_code=404, detail="Form section not found")
    session.delete(section)
    session.commit()
    session.close()
    return SuccessOut(success=True)


@router.get("/api/forms/{form_id}/sections", response_model=FormSectionListOut, operation_id="list_form_sections_alt", summary="List all sections for a form", description="Retrieve all form sections ordered by position for the given form.")
async def list_form_sections_alt(form_id: int):
    session = SessionLocal()
    sections = session.query(FormSection).filter(FormSection.form_id == form_id).order_by(FormSection.position).all()
    result = FormSectionListOut(sections=sections)
    session.close()
    return result


@router.post("/api/forms/{form_id}/sections", response_model=FormSectionOut, operation_id="create_form_section_alt", summary="Create a new section for a form", description="Add a new section to the specified form with title and position.")
async def create_form_section_alt(form_id: int, payload: FormSectionCreate = Body(...)):
    session = SessionLocal()
    form = session.query(ApplicationForm).filter(ApplicationForm.id == form_id).first()
    if form is None:
        session.close()
        raise HTTPException(status_code=404, detail="Application form not found")
    section = FormSection(
        form_id=form_id,
        title=payload.title,
        position=payload.position if payload.position is not None else 0,
    )
    session.add(section)
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Section title already exists for this form")
    session.refresh(section)
    result = FormSectionOut.model_validate(section)
    session.close()
    return result


@router.get("/api/forms/{form_id}/sections/{section_id}", response_model=FormSectionOut, operation_id="get_form_section_alt", summary="Get a specific form section", description="Retrieve details of a single form section by its ID.")
async def get_form_section_alt(form_id: int, section_id: int):
    session = SessionLocal()
    section = session.query(FormSection).filter(
        FormSection.id == section_id,
        FormSection.form_id == form_id,
    ).first()
    if section is None:
        session.close()
        raise HTTPException(status_code=404, detail="Form section not found")
    result = FormSectionOut.model_validate(section)
    session.close()
    return result


@router.put("/api/forms/{form_id}/sections/{section_id}", response_model=FormSectionOut, operation_id="update_form_section_alt", summary="Update a form section", description="Replace title and/or position of an existing form section.")
async def update_form_section_alt(form_id: int, section_id: int, payload: FormSectionUpdate = Body(...)):
    session = SessionLocal()
    section = session.query(FormSection).filter(
        FormSection.id == section_id,
        FormSection.form_id == form_id,
    ).first()
    if section is None:
        session.close()
        raise HTTPException(status_code=404, detail="Form section not found")
    if payload.title is not None:
        section.title = payload.title
    if payload.position is not None:
        section.position = payload.position
    section.updated_at = datetime.utcnow()
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Section title already exists for this form")
    session.refresh(section)
    result = FormSectionOut.model_validate(section)
    session.close()
    return result


@router.delete("/api/forms/{form_id}/sections/{section_id}", response_model=DeletedOut, operation_id="delete_form_section_alt", summary="Delete a form section", description="Remove a form section and its associated fields.")
async def delete_form_section_alt(form_id: int, section_id: int):
    session = SessionLocal()
    section = session.query(FormSection).filter(
        FormSection.id == section_id,
        FormSection.form_id == form_id,
    ).first()
    if section is None:
        session.close()
        raise HTTPException(status_code=404, detail="Form section not found")
    session.delete(section)
    session.commit()
    session.close()
    return DeletedOut(deleted=True)


@router.put("/api/form-sections/{section_id}", response_model=FormSectionOut, operation_id="update_form_section_by_id", summary="Update a form section by ID", description="Update the title or position of a form section.")
async def update_form_section_by_id(section_id: int, payload: FormSectionUpdate = Body(...)):
    session = SessionLocal()
    section = session.query(FormSection).filter(FormSection.id == section_id).first()
    if section is None:
        session.close()
        raise HTTPException(status_code=404, detail="Form section not found")
    if payload.title is not None:
        section.title = payload.title
    if payload.position is not None:
        section.position = payload.position
    section.updated_at = datetime.utcnow()
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Section title already exists for this form")
    session.refresh(section)
    result = FormSectionOut.model_validate(section)
    session.close()
    return result


@router.delete("/api/form-sections/{section_id}", response_model=SuccessOut, operation_id="delete_form_section_by_id", summary="Delete a form section by ID", description="Delete a form section and its fields.")
async def delete_form_section_by_id(section_id: int):
    session = SessionLocal()
    section = session.query(FormSection).filter(FormSection.id == section_id).first()
    if section is None:
        session.close()
        raise HTTPException(status_code=404, detail="Form section not found")
    session.delete(section)
    session.commit()
    session.close()
    return SuccessOut(success=True)