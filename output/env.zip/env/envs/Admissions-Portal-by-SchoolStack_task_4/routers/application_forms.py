from datetime import datetime
from fastapi import APIRouter, Body, HTTPException
from sqlalchemy.exc import IntegrityError
from database import SessionLocal
from models import ApplicationForm
from schemas import (
    ApplicationFormOut, ApplicationFormCreate, ApplicationFormUpdate,
    ApplicationFormListOut, SuccessOut, StatusOut
)

router = APIRouter(prefix="/api/application-forms", tags=["ApplicationForms"])

CURRENT_USER_ID = 1


def _resolve_fee_cents(payload):
    if getattr(payload, "application_fee_cents", None) is not None:
        return payload.application_fee_cents
    fee = getattr(payload, "fee", None)
    if fee is not None:
        return int(round(fee * 100))
    return None


@router.get("", response_model=ApplicationFormListOut, operation_id="list_application_forms", summary="List application forms created by current user", description="Retrieve all application forms created by user_id=1 with optional status filter.")
async def list_application_forms(status: str = None, limit: int = 20, offset: int = 0):
    session = SessionLocal()
    query = session.query(ApplicationForm).filter(ApplicationForm.created_by == CURRENT_USER_ID)
    if status is not None:
        query = query.filter(ApplicationForm.status == status)
    total = query.count()
    forms = query.order_by(ApplicationForm.id).offset(offset).limit(limit).all()
    result = ApplicationFormListOut(forms=forms, total=total)
    session.close()
    return result


@router.post("", response_model=ApplicationFormOut, operation_id="create_application_form", summary="Create a new application form", description="Create a new application form with name, description, fee, deadline, and status.")
async def create_application_form(payload: ApplicationFormCreate = Body(...)):
    session = SessionLocal()
    fee_cents = _resolve_fee_cents(payload)
    form = ApplicationForm(
        name=payload.name,
        description=payload.description,
        created_by=CURRENT_USER_ID,
        application_fee_cents=fee_cents if fee_cents is not None else 0,
        deadline=payload.deadline,
        status=payload.status if payload.status is not None else "draft",
    )
    session.add(form)
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Invalid application form data")
    session.refresh(form)
    result = ApplicationFormOut.model_validate(form)
    session.close()
    return result


@router.get("/{form_id}", response_model=ApplicationFormOut, operation_id="get_application_form", summary="Get an application form by ID", description="Retrieve a single application form created by user_id=1.")
async def get_application_form(form_id: int):
    session = SessionLocal()
    form = session.query(ApplicationForm).filter(
        ApplicationForm.id == form_id,
        ApplicationForm.created_by == CURRENT_USER_ID,
    ).first()
    if form is None:
        session.close()
        raise HTTPException(status_code=404, detail="Application form not found")
    result = ApplicationFormOut.model_validate(form)
    session.close()
    return result


@router.put("/{form_id}", response_model=ApplicationFormOut, operation_id="update_application_form", summary="Update an application form", description="Update all fields of an application form created by user_id=1.")
async def update_application_form(form_id: int, payload: ApplicationFormUpdate = Body(...)):
    session = SessionLocal()
    form = session.query(ApplicationForm).filter(
        ApplicationForm.id == form_id,
        ApplicationForm.created_by == CURRENT_USER_ID,
    ).first()
    if form is None:
        session.close()
        raise HTTPException(status_code=404, detail="Application form not found")
    if payload.name is not None:
        form.name = payload.name
    if payload.description is not None:
        form.description = payload.description
    fee_cents = _resolve_fee_cents(payload)
    if fee_cents is not None:
        form.application_fee_cents = fee_cents
    if payload.deadline is not None:
        form.deadline = payload.deadline
    if payload.status is not None:
        form.status = payload.status
    form.updated_at = datetime.utcnow()
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Invalid application form data")
    session.refresh(form)
    result = ApplicationFormOut.model_validate(form)
    session.close()
    return result


@router.delete("/{form_id}", response_model=SuccessOut, operation_id="delete_application_form", summary="Delete an application form", description="Delete an application form created by user_id=1.")
async def delete_application_form(form_id: int):
    session = SessionLocal()
    form = session.query(ApplicationForm).filter(
        ApplicationForm.id == form_id,
        ApplicationForm.created_by == CURRENT_USER_ID,
    ).first()
    if form is None:
        session.close()
        raise HTTPException(status_code=404, detail="Application form not found")
    session.delete(form)
    session.commit()
    session.close()
    return SuccessOut(success=True)


@router.post("/{form_id}/publish", response_model=StatusOut, operation_id="publish_application_form", summary="Publish an application form", description="Change status of a form created by user_id=1 to 'published'.")
async def publish_application_form(form_id: int):
    session = SessionLocal()
    form = session.query(ApplicationForm).filter(
        ApplicationForm.id == form_id,
        ApplicationForm.created_by == CURRENT_USER_ID,
    ).first()
    if form is None:
        session.close()
        raise HTTPException(status_code=404, detail="Application form not found")
    form.status = "published"
    form.updated_at = datetime.utcnow()
    session.commit()
    session.refresh(form)
    result = StatusOut(id=form.id, status=form.status, updated_at=form.updated_at)
    session.close()
    return result


@router.post("/{form_id}/close", response_model=StatusOut, operation_id="close_application_form", summary="Close an application form", description="Change status of a form created by user_id=1 to 'closed'.")
async def close_application_form(form_id: int):
    session = SessionLocal()
    form = session.query(ApplicationForm).filter(
        ApplicationForm.id == form_id,
        ApplicationForm.created_by == CURRENT_USER_ID,
    ).first()
    if form is None:
        session.close()
        raise HTTPException(status_code=404, detail="Application form not found")
    form.status = "closed"
    form.updated_at = datetime.utcnow()
    session.commit()
    session.refresh(form)
    result = StatusOut(id=form.id, status=form.status, updated_at=form.updated_at)
    session.close()
    return result