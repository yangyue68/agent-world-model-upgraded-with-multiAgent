from datetime import datetime
from fastapi import APIRouter, Body, HTTPException
from sqlalchemy.exc import IntegrityError
from database import SessionLocal
from models import ApplicationForm, FormRequirement
from schemas import (
    FormRequirementOut, FormRequirementCreate, FormRequirementUpdate,
    FormRequirementListOut, SuccessOut, DeletedOut
)

router = APIRouter(tags=["FormRequirements"])

CURRENT_USER_ID = 1

VALID_REQ_TYPES = {"document_upload", "recommendation_request"}


def _validate_req_type(requirement_type):
    if requirement_type not in VALID_REQ_TYPES:
        raise HTTPException(status_code=400, detail="Invalid requirement_type")


@router.get("/api/application-forms/{form_id}/requirements", response_model=FormRequirementListOut, operation_id="list_form_requirements", summary="List requirements of an application form", description="Retrieve all requirements for a form created by user_id=1.")
async def list_form_requirements(form_id: int):
    session = SessionLocal()
    form = session.query(ApplicationForm).filter(
        ApplicationForm.id == form_id,
        ApplicationForm.created_by == CURRENT_USER_ID,
    ).first()
    if form is None:
        session.close()
        raise HTTPException(status_code=404, detail="Application form not found")
    requirements = session.query(FormRequirement).filter(FormRequirement.form_id == form_id).order_by(FormRequirement.id).all()
    result = FormRequirementListOut(requirements=requirements)
    session.close()
    return result


@router.post("/api/application-forms/{form_id}/requirements", response_model=FormRequirementOut, operation_id="create_form_requirement", summary="Create a new requirement for an application form", description="Add a requirement to a form created by user_id=1.")
async def create_form_requirement(form_id: int, payload: FormRequirementCreate = Body(...)):
    _validate_req_type(payload.requirement_type)
    session = SessionLocal()
    form = session.query(ApplicationForm).filter(
        ApplicationForm.id == form_id,
        ApplicationForm.created_by == CURRENT_USER_ID,
    ).first()
    if form is None:
        session.close()
        raise HTTPException(status_code=404, detail="Application form not found")
    requirement = FormRequirement(
        form_id=form_id,
        requirement_type=payload.requirement_type,
        title=payload.title,
        description=payload.description,
        is_required=payload.is_required if payload.is_required is not None else 1,
        allowed_file_types=payload.allowed_file_types,
        max_file_size_bytes=payload.max_file_size_bytes,
        recommendation_count=payload.recommendation_count if payload.recommendation_count is not None else 1,
    )
    session.add(requirement)
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Invalid form requirement data")
    session.refresh(requirement)
    result = FormRequirementOut.model_validate(requirement)
    session.close()
    return result


@router.get("/api/application-forms/{form_id}/requirements/{requirement_id}", response_model=FormRequirementOut, operation_id="get_form_requirement", summary="Get a form requirement by ID", description="Retrieve a single requirement belonging to a form created by user_id=1.")
async def get_form_requirement(form_id: int, requirement_id: int):
    session = SessionLocal()
    form = session.query(ApplicationForm).filter(
        ApplicationForm.id == form_id,
        ApplicationForm.created_by == CURRENT_USER_ID,
    ).first()
    if form is None:
        session.close()
        raise HTTPException(status_code=404, detail="Application form not found")
    requirement = session.query(FormRequirement).filter(
        FormRequirement.id == requirement_id,
        FormRequirement.form_id == form_id,
    ).first()
    if requirement is None:
        session.close()
        raise HTTPException(status_code=404, detail="Form requirement not found")
    result = FormRequirementOut.model_validate(requirement)
    session.close()
    return result


@router.put("/api/application-forms/{form_id}/requirements/{requirement_id}", response_model=FormRequirementOut, operation_id="update_form_requirement", summary="Update a form requirement", description="Update all fields of a requirement in a form created by user_id=1.")
async def update_form_requirement(form_id: int, requirement_id: int, payload: FormRequirementUpdate = Body(...)):
    if payload.requirement_type is not None:
        _validate_req_type(payload.requirement_type)
    session = SessionLocal()
    form = session.query(ApplicationForm).filter(
        ApplicationForm.id == form_id,
        ApplicationForm.created_by == CURRENT_USER_ID,
    ).first()
    if form is None:
        session.close()
        raise HTTPException(status_code=404, detail="Application form not found")
    requirement = session.query(FormRequirement).filter(
        FormRequirement.id == requirement_id,
        FormRequirement.form_id == form_id,
    ).first()
    if requirement is None:
        session.close()
        raise HTTPException(status_code=404, detail="Form requirement not found")
    if payload.requirement_type is not None:
        requirement.requirement_type = payload.requirement_type
    if payload.title is not None:
        requirement.title = payload.title
    if payload.description is not None:
        requirement.description = payload.description
    if payload.is_required is not None:
        requirement.is_required = payload.is_required
    if payload.allowed_file_types is not None:
        requirement.allowed_file_types = payload.allowed_file_types
    if payload.max_file_size_bytes is not None:
        requirement.max_file_size_bytes = payload.max_file_size_bytes
    if payload.recommendation_count is not None:
        requirement.recommendation_count = payload.recommendation_count
    requirement.updated_at = datetime.utcnow()
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Invalid form requirement data")
    session.refresh(requirement)
    result = FormRequirementOut.model_validate(requirement)
    session.close()
    return result


@router.delete("/api/application-forms/{form_id}/requirements/{requirement_id}", response_model=SuccessOut, operation_id="delete_form_requirement", summary="Delete a form requirement", description="Delete a requirement from a form created by user_id=1.")
async def delete_form_requirement(form_id: int, requirement_id: int):
    session = SessionLocal()
    form = session.query(ApplicationForm).filter(
        ApplicationForm.id == form_id,
        ApplicationForm.created_by == CURRENT_USER_ID,
    ).first()
    if form is None:
        session.close()
        raise HTTPException(status_code=404, detail="Application form not found")
    requirement = session.query(FormRequirement).filter(
        FormRequirement.id == requirement_id,
        FormRequirement.form_id == form_id,
    ).first()
    if requirement is None:
        session.close()
        raise HTTPException(status_code=404, detail="Form requirement not found")
    session.delete(requirement)
    session.commit()
    session.close()
    return SuccessOut(success=True)


@router.get("/api/forms/{form_id}/requirements", response_model=FormRequirementListOut, operation_id="list_form_requirements_alt", summary="List all requirements for a form", description="Retrieve all form requirements belonging to the specified application form.")
async def list_form_requirements_alt(form_id: int, requirement_type: str = None):
    session = SessionLocal()
    query = session.query(FormRequirement).filter(FormRequirement.form_id == form_id)
    if requirement_type is not None:
        query = query.filter(FormRequirement.requirement_type == requirement_type)
    requirements = query.order_by(FormRequirement.id).all()
    result = FormRequirementListOut(requirements=requirements)
    session.close()
    return result


@router.post("/api/forms/{form_id}/requirements", response_model=FormRequirementOut, operation_id="create_form_requirement_alt", summary="Create a new requirement for a form", description="Add a document upload or recommendation request requirement to an application form.")
async def create_form_requirement_alt(form_id: int, payload: FormRequirementCreate = Body(...)):
    _validate_req_type(payload.requirement_type)
    session = SessionLocal()
    form = session.query(ApplicationForm).filter(ApplicationForm.id == form_id).first()
    if form is None:
        session.close()
        raise HTTPException(status_code=404, detail="Application form not found")
    requirement = FormRequirement(
        form_id=form_id,
        requirement_type=payload.requirement_type,
        title=payload.title,
        description=payload.description,
        is_required=payload.is_required if payload.is_required is not None else 1,
        allowed_file_types=payload.allowed_file_types,
        max_file_size_bytes=payload.max_file_size_bytes,
        recommendation_count=payload.recommendation_count if payload.recommendation_count is not None else 1,
    )
    session.add(requirement)
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Invalid form requirement data")
    session.refresh(requirement)
    result = FormRequirementOut.model_validate(requirement)
    session.close()
    return result


@router.get("/api/forms/{form_id}/requirements/{requirement_id}", response_model=FormRequirementOut, operation_id="get_form_requirement_alt", summary="Get a specific form requirement", description="Retrieve details of a single form requirement by its ID.")
async def get_form_requirement_alt(form_id: int, requirement_id: int):
    session = SessionLocal()
    requirement = session.query(FormRequirement).filter(
        FormRequirement.id == requirement_id,
        FormRequirement.form_id == form_id,
    ).first()
    if requirement is None:
        session.close()
        raise HTTPException(status_code=404, detail="Form requirement not found")
    result = FormRequirementOut.model_validate(requirement)
    session.close()
    return result


@router.put("/api/forms/{form_id}/requirements/{requirement_id}", response_model=FormRequirementOut, operation_id="update_form_requirement_alt", summary="Update a form requirement", description="Replace all fields of an existing form requirement.")
async def update_form_requirement_alt(form_id: int, requirement_id: int, payload: FormRequirementUpdate = Body(...)):
    if payload.requirement_type is not None:
        _validate_req_type(payload.requirement_type)
    session = SessionLocal()
    requirement = session.query(FormRequirement).filter(
        FormRequirement.id == requirement_id,
        FormRequirement.form_id == form_id,
    ).first()
    if requirement is None:
        session.close()
        raise HTTPException(status_code=404, detail="Form requirement not found")
    if payload.requirement_type is not None:
        requirement.requirement_type = payload.requirement_type
    if payload.title is not None:
        requirement.title = payload.title
    if payload.description is not None:
        requirement.description = payload.description
    if payload.is_required is not None:
        requirement.is_required = payload.is_required
    if payload.allowed_file_types is not None:
        requirement.allowed_file_types = payload.allowed_file_types
    if payload.max_file_size_bytes is not None:
        requirement.max_file_size_bytes = payload.max_file_size_bytes
    if payload.recommendation_count is not None:
        requirement.recommendation_count = payload.recommendation_count
    requirement.updated_at = datetime.utcnow()
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Invalid form requirement data")
    session.refresh(requirement)
    result = FormRequirementOut.model_validate(requirement)
    session.close()
    return result


@router.patch("/api/forms/{form_id}/requirements/{requirement_id}", response_model=FormRequirementOut, operation_id="patch_form_requirement", summary="Partially update a form requirement", description="Update one or more fields of an existing form requirement.")
async def patch_form_requirement(form_id: int, requirement_id: int, payload: FormRequirementUpdate = Body(...)):
    if payload.requirement_type is not None:
        _validate_req_type(payload.requirement_type)
    session = SessionLocal()
    requirement = session.query(FormRequirement).filter(
        FormRequirement.id == requirement_id,
        FormRequirement.form_id == form_id,
    ).first()
    if requirement is None:
        session.close()
        raise HTTPException(status_code=404, detail="Form requirement not found")
    if payload.requirement_type is not None:
        requirement.requirement_type = payload.requirement_type
    if payload.title is not None:
        requirement.title = payload.title
    if payload.description is not None:
        requirement.description = payload.description
    if payload.is_required is not None:
        requirement.is_required = payload.is_required
    if payload.allowed_file_types is not None:
        requirement.allowed_file_types = payload.allowed_file_types
    if payload.max_file_size_bytes is not None:
        requirement.max_file_size_bytes = payload.max_file_size_bytes
    if payload.recommendation_count is not None:
        requirement.recommendation_count = payload.recommendation_count
    requirement.updated_at = datetime.utcnow()
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Invalid form requirement data")
    session.refresh(requirement)
    result = FormRequirementOut.model_validate(requirement)
    session.close()
    return result


@router.delete("/api/forms/{form_id}/requirements/{requirement_id}", response_model=DeletedOut, operation_id="delete_form_requirement_alt", summary="Delete a form requirement", description="Remove a form requirement from an application form.")
async def delete_form_requirement_alt(form_id: int, requirement_id: int):
    session = SessionLocal()
    requirement = session.query(FormRequirement).filter(
        FormRequirement.id == requirement_id,
        FormRequirement.form_id == form_id,
    ).first()
    if requirement is None:
        session.close()
        raise HTTPException(status_code=404, detail="Form requirement not found")
    session.delete(requirement)
    session.commit()
    session.close()
    return DeletedOut(deleted=True)


@router.put("/api/form-requirements/{requirement_id}", response_model=FormRequirementOut, operation_id="update_form_requirement_by_id", summary="Update a form requirement by ID", description="Update the details of a form requirement.")
async def update_form_requirement_by_id(requirement_id: int, payload: FormRequirementUpdate = Body(...)):
    if payload.requirement_type is not None:
        _validate_req_type(payload.requirement_type)
    session = SessionLocal()
    requirement = session.query(FormRequirement).filter(FormRequirement.id == requirement_id).first()
    if requirement is None:
        session.close()
        raise HTTPException(status_code=404, detail="Form requirement not found")
    if payload.requirement_type is not None:
        requirement.requirement_type = payload.requirement_type
    if payload.title is not None:
        requirement.title = payload.title
    if payload.description is not None:
        requirement.description = payload.description
    if payload.is_required is not None:
        requirement.is_required = payload.is_required
    if payload.allowed_file_types is not None:
        requirement.allowed_file_types = payload.allowed_file_types
    if payload.max_file_size_bytes is not None:
        requirement.max_file_size_bytes = payload.max_file_size_bytes
    if payload.recommendation_count is not None:
        requirement.recommendation_count = payload.recommendation_count
    requirement.updated_at = datetime.utcnow()
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Invalid form requirement data")
    session.refresh(requirement)
    result = FormRequirementOut.model_validate(requirement)
    session.close()
    return result


@router.delete("/api/form-requirements/{requirement_id}", response_model=SuccessOut, operation_id="delete_form_requirement_by_id", summary="Delete a form requirement by ID", description="Delete a form requirement and its associated data.")
async def delete_form_requirement_by_id(requirement_id: int):
    session = SessionLocal()
    requirement = session.query(FormRequirement).filter(FormRequirement.id == requirement_id).first()
    if requirement is None:
        session.close()
        raise HTTPException(status_code=404, detail="Form requirement not found")
    session.delete(requirement)
    session.commit()
    session.close()
    return SuccessOut(success=True)