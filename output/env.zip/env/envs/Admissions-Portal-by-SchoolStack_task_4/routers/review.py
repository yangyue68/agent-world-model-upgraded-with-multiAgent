from datetime import datetime
from fastapi import APIRouter, Body, HTTPException
from pydantic import BaseModel
from typing import Optional, List
from database import SessionLocal
from models import Application

router = APIRouter(prefix="/api/review", tags=["Review"])

ASSIGNMENTS = []
RUBRICS = []
COMMENTS = []
DECISIONS = []
COMMITTEES = []


class AssignmentCreate(BaseModel):
    application_id: int
    reviewer_id: int
    stage: Optional[str] = "initial"


class RubricCreate(BaseModel):
    name: str
    criteria: Optional[str] = None
    max_score: Optional[int] = 100


class CommentCreate(BaseModel):
    application_id: int
    reviewer_id: int
    comment: str


class DecisionCreate(BaseModel):
    application_id: int
    reviewer_id: int
    decision: str
    notes: Optional[str] = None


class CommitteeCreate(BaseModel):
    name: str
    stages: Optional[str] = None


@router.post("/assignments", operation_id="create_reviewer_assignment", summary="Assign a reviewer", description="Assign a reviewer to an application with a review stage.")
async def create_reviewer_assignment(payload: AssignmentCreate = Body(...)):
    session = SessionLocal()
    application = session.query(Application).filter(Application.id == payload.application_id).first()
    if application is None:
        session.close()
        raise HTTPException(status_code=404, detail="Application not found")
    assignment = {
        "id": len(ASSIGNMENTS) + 1,
        "application_id": payload.application_id,
        "reviewer_id": payload.reviewer_id,
        "stage": payload.stage,
        "status": "assigned",
        "created_at": datetime.utcnow().isoformat(),
    }
    ASSIGNMENTS.append(assignment)
    session.close()
    return assignment


@router.get("/assignments", operation_id="list_reviewer_assignments", summary="List reviewer assignments", description="Retrieve all reviewer assignments, optionally filtered by application.")
async def list_reviewer_assignments(application_id: int = None):
    if application_id is None:
        return {"assignments": ASSIGNMENTS, "total": len(ASSIGNMENTS)}
    filtered = [a for a in ASSIGNMENTS if a["application_id"] == application_id]
    return {"assignments": filtered, "total": len(filtered)}


@router.post("/rubrics", operation_id="create_scoring_rubric", summary="Create a scoring rubric", description="Create a scoring rubric for reviewers.")
async def create_scoring_rubric(payload: RubricCreate = Body(...)):
    rubric = {
        "id": len(RUBRICS) + 1,
        "name": payload.name,
        "criteria": payload.criteria,
        "max_score": payload.max_score,
        "created_at": datetime.utcnow().isoformat(),
    }
    RUBRICS.append(rubric)
    return rubric


@router.get("/rubrics", operation_id="list_scoring_rubrics", summary="List scoring rubrics", description="Retrieve all scoring rubrics.")
async def list_scoring_rubrics():
    return {"rubrics": RUBRICS, "total": len(RUBRICS)}


@router.post("/comments", operation_id="create_review_comment", summary="Create a review comment", description="Add a comment to an application review thread.")
async def create_review_comment(payload: CommentCreate = Body(...)):
    session = SessionLocal()
    application = session.query(Application).filter(Application.id == payload.application_id).first()
    if application is None:
        session.close()
        raise HTTPException(status_code=404, detail="Application not found")
    comment = {
        "id": len(COMMENTS) + 1,
        "application_id": payload.application_id,
        "reviewer_id": payload.reviewer_id,
        "comment": payload.comment,
        "created_at": datetime.utcnow().isoformat(),
    }
    COMMENTS.append(comment)
    session.close()
    return comment


@router.get("/comments", operation_id="list_review_comments", summary="List review comments", description="Retrieve review comments, optionally filtered by application.")
async def list_review_comments(application_id: int = None):
    if application_id is None:
        return {"comments": COMMENTS, "total": len(COMMENTS)}
    filtered = [c for c in COMMENTS if c["application_id"] == application_id]
    return {"comments": filtered, "total": len(filtered)}


@router.post("/decisions", operation_id="create_decision_flag", summary="Create a decision flag", description="Record a decision flag (admit, waitlist, deny) for an application.")
async def create_decision_flag(payload: DecisionCreate = Body(...)):
    session = SessionLocal()
    application = session.query(Application).filter(Application.id == payload.application_id).first()
    if application is None:
        session.close()
        raise HTTPException(status_code=404, detail="Application not found")
    decision = {
        "id": len(DECISIONS) + 1,
        "application_id": payload.application_id,
        "reviewer_id": payload.reviewer_id,
        "decision": payload.decision,
        "notes": payload.notes,
        "created_at": datetime.utcnow().isoformat(),
    }
    DECISIONS.append(decision)
    session.close()
    return decision


@router.get("/decisions", operation_id="list_decision_flags", summary="List decision flags", description="Retrieve decision flags, optionally filtered by application.")
async def list_decision_flags(application_id: int = None):
    if application_id is None:
        return {"decisions": DECISIONS, "total": len(DECISIONS)}
    filtered = [d for d in DECISIONS if d["application_id"] == application_id]
    return {"decisions": filtered, "total": len(filtered)}


@router.post("/committees", operation_id="create_review_committee", summary="Create a review committee", description="Create a multi-stage review committee.")
async def create_review_committee(payload: CommitteeCreate = Body(...)):
    committee = {
        "id": len(COMMITTEES) + 1,
        "name": payload.name,
        "stages": payload.stages,
        "created_at": datetime.utcnow().isoformat(),
    }
    COMMITTEES.append(committee)
    return committee


@router.get("/committees", operation_id="list_review_committees", summary="List review committees", description="Retrieve all review committees.")
async def list_review_committees():
    return {"committees": COMMITTEES, "total": len(COMMITTEES)}