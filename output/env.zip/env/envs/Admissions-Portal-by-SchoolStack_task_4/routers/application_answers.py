from datetime import datetime
from fastapi import APIRouter, Body, HTTPException
from sqlalchemy.exc import IntegrityError
from database import SessionLocal
from models import Application, ApplicationAnswer, FormField
from schemas import (
    ApplicationAnswerOut, ApplicationAnswerCreate, ApplicationAnswerUpdate,
    ApplicationAnswerListOut, DeletedOut
)

router = APIRouter(tags=["ApplicationAnswers"])


@router.get("/api/applications/{application_id}/answers", response_model=ApplicationAnswerListOut, operation_id="list_application_answers", summary="List all answers for an application", description="Retrieve all application_answers rows for a given application.")
async def list_application_answers(application_id: int):
    session = SessionLocal()
    application = session.query(Application).filter(Application.id == application_id).first()
    if application is None:
        session.close()
        raise HTTPException(status_code=404, detail="Application not found")
    answers = session.query(ApplicationAnswer).filter(ApplicationAnswer.application_id == application_id).order_by(ApplicationAnswer.id).all()
    result = ApplicationAnswerListOut(answers=answers)
    session.close()
    return result


@router.post("/api/applications/{application_id}/answers", response_model=ApplicationAnswerOut, operation_id="create_application_answer", summary="Create an answer for a form field", description="Insert a new application_answers row for the given application and field.")
async def create_application_answer(application_id: int, payload: ApplicationAnswerCreate = Body(...)):
    session = SessionLocal()
    application = session.query(Application).filter(Application.id == application_id).first()
    if application is None:
        session.close()
        raise HTTPException(status_code=404, detail="Application not found")
    field = session.query(FormField).filter(FormField.id == payload.field_id).first()
    if field is None:
        session.close()
        raise HTTPException(status_code=404, detail="Form field not found")
    existing = session.query(ApplicationAnswer).filter(
        ApplicationAnswer.application_id == application_id,
        ApplicationAnswer.field_id == payload.field_id,
    ).first()
    if existing is not None:
        existing.value = payload.value
        existing.updated_at = datetime.utcnow()
        session.commit()
        session.refresh(existing)
        result = ApplicationAnswerOut.model_validate(existing)
        session.close()
        return result
    answer = ApplicationAnswer(
        application_id=application_id,
        field_id=payload.field_id,
        value=payload.value,
    )
    session.add(answer)
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Invalid answer data")
    session.refresh(answer)
    result = ApplicationAnswerOut.model_validate(answer)
    session.close()
    return result


@router.get("/api/applications/{application_id}/answers/{answer_id}", response_model=ApplicationAnswerOut, operation_id="get_application_answer", summary="Get a single application answer", description="Retrieve one application_answers row by its ID.")
async def get_application_answer(application_id: int, answer_id: int):
    session = SessionLocal()
    answer = session.query(ApplicationAnswer).filter(
        ApplicationAnswer.id == answer_id,
        ApplicationAnswer.application_id == application_id,
    ).first()
    if answer is None:
        session.close()
        raise HTTPException(status_code=404, detail="Answer not found")
    result = ApplicationAnswerOut.model_validate(answer)
    session.close()
    return result


@router.put("/api/applications/{application_id}/answers/{answer_id}", response_model=ApplicationAnswerOut, operation_id="replace_application_answer", summary="Replace an application answer", description="Update the value of an existing application_answers row.")
async def replace_application_answer(application_id: int, answer_id: int, payload: ApplicationAnswerUpdate = Body(...)):
    session = SessionLocal()
    answer = session.query(ApplicationAnswer).filter(
        ApplicationAnswer.id == answer_id,
        ApplicationAnswer.application_id == application_id,
    ).first()
    if answer is None:
        session.close()
        raise HTTPException(status_code=404, detail="Answer not found")
    answer.value = payload.value
    answer.updated_at = datetime.utcnow()
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Invalid answer data")
    session.refresh(answer)
    result = ApplicationAnswerOut.model_validate(answer)
    session.close()
    return result


@router.patch("/api/applications/{application_id}/answers/{answer_id}", response_model=ApplicationAnswerOut, operation_id="update_application_answer", summary="Partially update an application answer", description="Update only the value field of an existing application_answers row.")
async def update_application_answer(application_id: int, answer_id: int, payload: ApplicationAnswerUpdate = Body(...)):
    session = SessionLocal()
    answer = session.query(ApplicationAnswer).filter(
        ApplicationAnswer.id == answer_id,
        ApplicationAnswer.application_id == application_id,
    ).first()
    if answer is None:
        session.close()
        raise HTTPException(status_code=404, detail="Answer not found")
    if payload.value is not None:
        answer.value = payload.value
    answer.updated_at = datetime.utcnow()
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Invalid answer data")
    session.refresh(answer)
    result = ApplicationAnswerOut.model_validate(answer)
    session.close()
    return result


@router.delete("/api/applications/{application_id}/answers/{answer_id}", response_model=DeletedOut, operation_id="delete_application_answer", summary="Delete an application answer", description="Remove an application_answers row by its ID.")
async def delete_application_answer(application_id: int, answer_id: int):
    session = SessionLocal()
    answer = session.query(ApplicationAnswer).filter(
        ApplicationAnswer.id == answer_id,
        ApplicationAnswer.application_id == application_id,
    ).first()
    if answer is None:
        session.close()
        raise HTTPException(status_code=404, detail="Answer not found")
    session.delete(answer)
    session.commit()
    session.close()
    return DeletedOut(deleted=True)


@router.get("/api/applications/{application_id}/answers/by-field/{field_id}", response_model=ApplicationAnswerOut, operation_id="get_application_answer_by_field", summary="Get answer for a specific form field", description="Retrieve the application_answers row matching the given application and field.")
async def get_application_answer_by_field(application_id: int, field_id: int):
    session = SessionLocal()
    answer = session.query(ApplicationAnswer).filter(
        ApplicationAnswer.application_id == application_id,
        ApplicationAnswer.field_id == field_id,
    ).first()
    if answer is None:
        session.close()
        raise HTTPException(status_code=404, detail="Answer not found")
    result = ApplicationAnswerOut.model_validate(answer)
    session.close()
    return result


@router.put("/api/applications/{application_id}/answers/by-field/{field_id}", response_model=ApplicationAnswerOut, operation_id="upsert_application_answer_by_field", summary="Upsert answer for a specific form field", description="Create or replace the application_answers row for the given application and field.")
async def upsert_application_answer_by_field(application_id: int, field_id: int, payload: ApplicationAnswerUpdate = Body(...)):
    session = SessionLocal()
    application = session.query(Application).filter(Application.id == application_id).first()
    if application is None:
        session.close()
        raise HTTPException(status_code=404, detail="Application not found")
    field = session.query(FormField).filter(FormField.id == field_id).first()
    if field is None:
        session.close()
        raise HTTPException(status_code=404, detail="Form field not found")
    answer = session.query(ApplicationAnswer).filter(
        ApplicationAnswer.application_id == application_id,
        ApplicationAnswer.field_id == field_id,
    ).first()
    if answer is None:
        answer = ApplicationAnswer(
            application_id=application_id,
            field_id=field_id,
            value=payload.value,
        )
        session.add(answer)
    else:
        answer.value = payload.value
        answer.updated_at = datetime.utcnow()
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Invalid answer data")
    session.refresh(answer)
    result = ApplicationAnswerOut.model_validate(answer)
    session.close()
    return result