from fastapi import APIRouter, HTTPException
from sqlalchemy import func
from database import SessionLocal
from models import Application, ApplicationForm, User

router = APIRouter(prefix="/api/reports", tags=["Reports"])


@router.get("/funnel-conversion", operation_id="report_funnel_conversion", summary="Funnel conversion report", description="Report on application status funnel conversion counts per form.")
async def report_funnel_conversion(form_id: int = None):
    session = SessionLocal()
    query = session.query(Application.status, func.count(Application.id))
    if form_id is not None:
        query = query.filter(Application.form_id == form_id)
    rows = query.group_by(Application.status).all()
    total = sum(r[1] for r in rows)
    stages = {}
    for status, count in rows:
        stages[status] = count
    session.close()
    return {"form_id": form_id, "total": total, "stages": stages}


@router.get("/applicant-demographics", operation_id="report_applicant_demographics", summary="Applicant demographics report", description="Report on applicant counts grouped by user.")
async def report_applicant_demographics(form_id: int = None):
    session = SessionLocal()
    query = session.query(Application.applicant_user_id, func.count(Application.id))
    if form_id is not None:
        query = query.filter(Application.form_id == form_id)
    rows = query.group_by(Application.applicant_user_id).all()
    demographics = []
    for user_id, count in rows:
        demographics.append({"applicant_user_id": user_id, "application_count": count})
    session.close()
    return {"form_id": form_id, "demographics": demographics}


@router.get("/reviewer-workload", operation_id="report_reviewer_workload", summary="Reviewer workload report", description="Report on application counts per form as a proxy for reviewer workload.")
async def report_reviewer_workload():
    session = SessionLocal()
    rows = session.query(Application.form_id, func.count(Application.id)).group_by(Application.form_id).all()
    workload = []
    for form_id, count in rows:
        workload.append({"form_id": form_id, "application_count": count})
    session.close()
    return {"workload": workload}


@router.get("/yield-rates", operation_id="report_yield_rates", summary="Yield rates report", description="Report on acceptance yield rates per form.")
async def report_yield_rates():
    session = SessionLocal()
    forms = session.query(ApplicationForm).all()
    results = []
    for form in forms:
        total = session.query(func.count(Application.id)).filter(Application.form_id == form.id).scalar()
        accepted = session.query(func.count(Application.id)).filter(
            Application.form_id == form.id,
            Application.status == "accepted",
        ).scalar()
        rate = (accepted / total) if total else 0.0
        results.append({"form_id": form.id, "total": total, "accepted": accepted, "yield_rate": rate})
    session.close()
    return {"yield_rates": results}