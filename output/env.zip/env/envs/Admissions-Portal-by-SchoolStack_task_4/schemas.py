from datetime import datetime
from typing import Optional, List
from pydantic import BaseModel, ConfigDict, Field

class UserOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    username: str
    email: str
    full_name: Optional[str] = None
    created_at: datetime
    updated_at: datetime

class UserCreate(BaseModel):
    username: str
    email: str
    full_name: Optional[str] = None

class ApplicationFormOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    name: str
    description: Optional[str] = None
    created_by: int
    application_fee_cents: int
    deadline: Optional[datetime] = None
    status: str
    created_at: datetime
    updated_at: datetime

class ApplicationFormCreate(BaseModel):
    name: str
    description: Optional[str] = None
    application_fee_cents: Optional[int] = 0
    fee: Optional[int] = None
    deadline: Optional[datetime] = None
    status: Optional[str] = 'draft'

class ApplicationFormUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    application_fee_cents: Optional[int] = None
    fee: Optional[int] = None
    deadline: Optional[datetime] = None
    status: Optional[str] = None

class ApplicationFormListOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    forms: List[ApplicationFormOut]
    total: int

class FormSectionOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    form_id: int
    title: str
    position: int
    created_at: datetime
    updated_at: datetime

class FormSectionCreate(BaseModel):
    title: str
    position: Optional[int] = 0

class FormSectionUpdate(BaseModel):
    title: Optional[str] = None
    position: Optional[int] = None

class FormSectionListOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    sections: List[FormSectionOut]

class FormFieldOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    section_id: int
    label: str
    field_type: str
    is_required: int
    position: int
    placeholder: Optional[str] = None
    help_text: Optional[str] = None
    validation_rules: Optional[str] = None
    created_at: datetime
    updated_at: datetime

class FormFieldCreate(BaseModel):
    label: str
    field_type: str
    is_required: Optional[int] = 0
    position: Optional[int] = 0
    placeholder: Optional[str] = None
    help_text: Optional[str] = None
    validation_rules: Optional[str] = None

class FormFieldUpdate(BaseModel):
    label: Optional[str] = None
    field_type: Optional[str] = None
    is_required: Optional[int] = None
    position: Optional[int] = None
    placeholder: Optional[str] = None
    help_text: Optional[str] = None
    validation_rules: Optional[str] = None

class FormFieldListOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    fields: List[FormFieldOut]

class FormRequirementOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    form_id: int
    requirement_type: str
    title: str
    description: Optional[str] = None
    is_required: int
    allowed_file_types: Optional[str] = None
    max_file_size_bytes: Optional[int] = None
    recommendation_count: int
    created_at: datetime
    updated_at: datetime

class FormRequirementCreate(BaseModel):
    requirement_type: str
    title: str
    description: Optional[str] = None
    is_required: Optional[int] = 1
    allowed_file_types: Optional[str] = None
    max_file_size_bytes: Optional[int] = None
    recommendation_count: Optional[int] = 1

class FormRequirementUpdate(BaseModel):
    requirement_type: Optional[str] = None
    title: Optional[str] = None
    description: Optional[str] = None
    is_required: Optional[int] = None
    allowed_file_types: Optional[str] = None
    max_file_size_bytes: Optional[int] = None
    recommendation_count: Optional[int] = None

class FormRequirementListOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    requirements: List[FormRequirementOut]

class ApplicationOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    form_id: int
    applicant_user_id: Optional[int] = None
    status: str
    submitted_at: Optional[datetime] = None
    created_at: datetime
    updated_at: datetime

class ApplicationCreate(BaseModel):
    applicant_user_id: Optional[int] = None

class ApplicationUpdate(BaseModel):
    status: Optional[str] = None
    submitted_at: Optional[datetime] = None

class ApplicationListOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    applications: List[ApplicationOut]

class ApplicationAnswerOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    application_id: int
    field_id: int
    value: Optional[str] = None
    created_at: datetime
    updated_at: datetime

class ApplicationAnswerCreate(BaseModel):
    field_id: int
    value: Optional[str] = None

class ApplicationAnswerUpdate(BaseModel):
    value: Optional[str] = None

class ApplicationAnswerListOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    answers: List[ApplicationAnswerOut]

class ApplicationDocumentOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    application_id: int
    requirement_id: Optional[int] = None
    file_name: str
    file_type: str
    file_size_bytes: int
    uploaded_at: datetime
    created_at: datetime
    updated_at: datetime

class ApplicationDocumentCreate(BaseModel):
    requirement_id: Optional[int] = None
    file_name: str
    file_type: str
    file_size_bytes: int
    file_data: str

class ApplicationDocumentListOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    documents: List[ApplicationDocumentOut]

class RecommendationRequestOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    application_id: int
    requirement_id: Optional[int] = None
    recommender_name: str
    recommender_email: str
    recommender_phone: Optional[str] = None
    relationship: Optional[str] = None
    status: str
    requested_at: datetime
    completed_at: Optional[datetime] = None
    created_at: datetime
    updated_at: datetime

class RecommendationRequestCreate(BaseModel):
    requirement_id: Optional[int] = None
    recommender_name: str
    recommender_email: str
    recommender_phone: Optional[str] = None
    relationship: Optional[str] = None

class RecommendationRequestUpdate(BaseModel):
    requirement_id: Optional[int] = None
    recommender_name: Optional[str] = None
    recommender_email: Optional[str] = None
    recommender_phone: Optional[str] = None
    relationship: Optional[str] = None
    status: Optional[str] = None
    completed_at: Optional[datetime] = None

class RecommendationRequestListOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    recommendation_requests: List[RecommendationRequestOut]

class ApplicationFeeOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    application_id: int
    amount_cents: int
    currency: str
    status: str
    paid_at: Optional[datetime] = None
    created_at: datetime
    updated_at: datetime

class ApplicationFeeCreate(BaseModel):
    application_id: int
    amount_cents: int
    currency: Optional[str] = 'USD'
    status: Optional[str] = 'pending'

class ApplicationFeeUpdate(BaseModel):
    amount_cents: Optional[int] = None
    currency: Optional[str] = None
    status: Optional[str] = None
    paid_at: Optional[datetime] = None

class ApplicationFeeListOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    application_fees: List[ApplicationFeeOut]

class SuccessOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    success: bool

class DeletedOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    deleted: bool

class MessageOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    message: str

class StatusOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    status: str
    updated_at: datetime