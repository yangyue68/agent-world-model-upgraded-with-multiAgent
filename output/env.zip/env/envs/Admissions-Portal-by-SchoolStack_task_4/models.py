from datetime import datetime
from sqlalchemy import (
    Column, Integer, Text, DateTime, ForeignKey, LargeBinary, UniqueConstraint
)
from sqlalchemy.orm import relationship
from database import Base


class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, autoincrement=True)
    username = Column(Text, nullable=False, unique=True)
    email = Column(Text, nullable=False, unique=True)
    full_name = Column(Text)
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    updated_at = Column(DateTime, nullable=False, default=datetime.utcnow)


class ApplicationForm(Base):
    __tablename__ = "application_forms"
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(Text, nullable=False)
    description = Column(Text)
    created_by = Column(Integer, ForeignKey("users.id"), nullable=False)
    application_fee_cents = Column(Integer, nullable=False, default=0)
    deadline = Column(DateTime)
    status = Column(Text, nullable=False, default="draft")
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    updated_at = Column(DateTime, nullable=False, default=datetime.utcnow)


class FormSection(Base):
    __tablename__ = "form_sections"
    __table_args__ = (UniqueConstraint("form_id", "title"),)
    id = Column(Integer, primary_key=True, autoincrement=True)
    form_id = Column(Integer, ForeignKey("application_forms.id"), nullable=False)
    title = Column(Text, nullable=False)
    position = Column(Integer, nullable=False, default=0)
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    updated_at = Column(DateTime, nullable=False, default=datetime.utcnow)


class FormField(Base):
    __tablename__ = "form_fields"
    id = Column(Integer, primary_key=True, autoincrement=True)
    section_id = Column(Integer, ForeignKey("form_sections.id"), nullable=False)
    label = Column(Text, nullable=False)
    field_type = Column(Text, nullable=False)
    is_required = Column(Integer, nullable=False, default=0)
    position = Column(Integer, nullable=False, default=0)
    placeholder = Column(Text)
    help_text = Column(Text)
    validation_rules = Column(Text)
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    updated_at = Column(DateTime, nullable=False, default=datetime.utcnow)


class FormRequirement(Base):
    __tablename__ = "form_requirements"
    id = Column(Integer, primary_key=True, autoincrement=True)
    form_id = Column(Integer, ForeignKey("application_forms.id"), nullable=False)
    requirement_type = Column(Text, nullable=False)
    title = Column(Text, nullable=False)
    description = Column(Text)
    is_required = Column(Integer, nullable=False, default=1)
    allowed_file_types = Column(Text)
    max_file_size_bytes = Column(Integer)
    recommendation_count = Column(Integer, nullable=False, default=1)
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    updated_at = Column(DateTime, nullable=False, default=datetime.utcnow)


class Application(Base):
    __tablename__ = "applications"
    id = Column(Integer, primary_key=True, autoincrement=True)
    form_id = Column(Integer, ForeignKey("application_forms.id"), nullable=False)
    applicant_user_id = Column(Integer, ForeignKey("users.id"))
    status = Column(Text, nullable=False, default="draft")
    submitted_at = Column(DateTime)
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    updated_at = Column(DateTime, nullable=False, default=datetime.utcnow)


class ApplicationAnswer(Base):
    __tablename__ = "application_answers"
    __table_args__ = (UniqueConstraint("application_id", "field_id"),)
    id = Column(Integer, primary_key=True, autoincrement=True)
    application_id = Column(Integer, ForeignKey("applications.id"), nullable=False)
    field_id = Column(Integer, ForeignKey("form_fields.id"), nullable=False)
    value = Column(Text)
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    updated_at = Column(DateTime, nullable=False, default=datetime.utcnow)


class ApplicationDocument(Base):
    __tablename__ = "application_documents"
    id = Column(Integer, primary_key=True, autoincrement=True)
    application_id = Column(Integer, ForeignKey("applications.id"), nullable=False)
    requirement_id = Column(Integer, ForeignKey("form_requirements.id"))
    file_name = Column(Text, nullable=False)
    file_type = Column(Text, nullable=False)
    file_size_bytes = Column(Integer, nullable=False)
    file_data = Column(LargeBinary, nullable=False)
    uploaded_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    updated_at = Column(DateTime, nullable=False, default=datetime.utcnow)


class RecommendationRequest(Base):
    __tablename__ = "recommendation_requests"
    id = Column(Integer, primary_key=True, autoincrement=True)
    application_id = Column(Integer, ForeignKey("applications.id"), nullable=False)
    requirement_id = Column(Integer, ForeignKey("form_requirements.id"))
    recommender_name = Column(Text, nullable=False)
    recommender_email = Column(Text, nullable=False)
    recommender_phone = Column(Text)
    relationship = Column(Text)
    status = Column(Text, nullable=False, default="pending")
    requested_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    completed_at = Column(DateTime)
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    updated_at = Column(DateTime, nullable=False, default=datetime.utcnow)


class ApplicationFee(Base):
    __tablename__ = "application_fees"
    id = Column(Integer, primary_key=True, autoincrement=True)
    application_id = Column(Integer, ForeignKey("applications.id"), nullable=False, unique=True)
    amount_cents = Column(Integer, nullable=False)
    currency = Column(Text, nullable=False, default="USD")
    status = Column(Text, nullable=False, default="pending")
    paid_at = Column(DateTime)
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    updated_at = Column(DateTime, nullable=False, default=datetime.utcnow)