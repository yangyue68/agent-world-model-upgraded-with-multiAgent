import os
from fastapi import FastAPI
import uvicorn
from database import Base, engine
import models
from routers import (
    application_forms, form_sections, form_fields, form_requirements,
    applications, application_answers, application_documents,
    recommendation_requests, application_fees, users, reports,
    bulk_actions, notifications, interviews, review, cohorts, audit
)

Base.metadata.create_all(engine)

app = FastAPI(title="Admissions Portal by SchoolStack", version="1.0.0")

app.include_router(application_forms.router)
app.include_router(form_sections.router)
app.include_router(form_fields.router)
app.include_router(form_requirements.router)
app.include_router(applications.router)
app.include_router(application_answers.router)
app.include_router(application_documents.router)
app.include_router(recommendation_requests.router)
app.include_router(application_fees.router)
app.include_router(users.router)
app.include_router(reports.router)
app.include_router(bulk_actions.router)
app.include_router(notifications.router)
app.include_router(interviews.router)
app.include_router(review.router)
app.include_router(cohorts.router)
app.include_router(audit.router)


@app.get("/health", operation_id="health_check", summary="Health check", description="Return service health status.")
async def health_check():
    return {"status": "ok"}


if __name__ == "__main__":
    host = os.environ.get("HOST", "127.0.0.1")
    port = int(os.environ.get("PORT", "8000"))
    uvicorn.run(app, host=host, port=port)