import os
import uvicorn
from fastapi import FastAPI
from database import Base, engine
from routers import animals, users

Base.metadata.create_all(bind=engine)

app = FastAPI(title="AdoptPaws API", version="1.0.0")

app.include_router(animals.router)
app.include_router(users.router)


@app.get(
    "/health",
    summary="Health check endpoint",
    description="Returns a simple status indicating the service is running.",
    tags=["Health"],
    operation_id="health_check",
)
async def health_check():
    return {"status": "ok"}


if __name__ == "__main__":
    host = os.getenv("HOST", "127.0.0.1")
    port = int(os.getenv("PORT", "8000"))
    uvicorn.run(app, host=host, port=port)