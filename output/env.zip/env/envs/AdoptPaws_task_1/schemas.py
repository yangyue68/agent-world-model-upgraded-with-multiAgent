from datetime import date, datetime
from typing import Optional, List
from pydantic import BaseModel, ConfigDict, Field

class AnimalBase(BaseModel):
    name: str
    species: str
    breed: Optional[str] = None
    birth_date: Optional[date] = None
    age_years: Optional[int] = None
    temperament: Optional[str] = None
    status: str
    microchip_id: Optional[str] = None
    intake_date: date
    current_location: Optional[str] = None

class AnimalCreate(AnimalBase):
    pass

class AnimalReplace(AnimalBase):
    pass

class AnimalUpdate(BaseModel):
    name: Optional[str] = None
    species: Optional[str] = None
    breed: Optional[str] = None
    birth_date: Optional[date] = None
    age_years: Optional[int] = None
    temperament: Optional[str] = None
    status: Optional[str] = None
    microchip_id: Optional[str] = None
    intake_date: Optional[date] = None
    current_location: Optional[str] = None

class AnimalOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    name: str
    species: str
    breed: Optional[str] = None
    birth_date: Optional[date] = None
    age_years: Optional[int] = None
    temperament: Optional[str] = None
    status: str
    microchip_id: Optional[str] = None
    intake_date: date
    current_location: Optional[str] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class AnimalListOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    animals: List[AnimalOut]
    total: int

class DeleteOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    success: bool
    message: str

class UserBase(BaseModel):
    username: str
    full_name: Optional[str] = None
    email: Optional[str] = None

class UserCreate(UserBase):
    pass

class UserReplace(UserBase):
    pass

class UserUpdate(BaseModel):
    username: Optional[str] = None
    full_name: Optional[str] = None
    email: Optional[str] = None

class UserOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    username: str
    full_name: Optional[str] = None
    email: Optional[str] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class UserListOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    users: List[UserOut]
    total: int