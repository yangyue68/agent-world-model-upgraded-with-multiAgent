from datetime import date
from typing import Optional, List
from fastapi import APIRouter, Body, HTTPException, Query
from sqlalchemy import and_
from sqlalchemy.exc import IntegrityError
from database import SessionLocal
from models import Animal
from schemas import (
    AnimalCreate,
    AnimalReplace,
    AnimalUpdate,
    AnimalOut,
    AnimalListOut,
    DeleteOut,
)

router = APIRouter(prefix="/api/animals", tags=["Animals"])


@router.get(
    "",
    summary="List animals with optional filters",
    description="Retrieve animals filtered by species, status, age, temperament, intake date, microchip, and location.",
    tags=["Animals"],
    operation_id="list_animals",
    response_model=AnimalListOut,
)
async def list_animals(
    species: Optional[str] = Query(None),
    status: Optional[str] = Query(None),
    breed: Optional[str] = Query(None),
    age_years_min: Optional[int] = Query(None),
    age_years_max: Optional[int] = Query(None),
    temperament: Optional[str] = Query(None),
    intake_date_before: Optional[date] = Query(None),
    intake_date_after: Optional[date] = Query(None),
    microchip_id: Optional[str] = Query(None),
    current_location: Optional[str] = Query(None),
    limit: Optional[int] = Query(None),
    offset: Optional[int] = Query(0),
):
    session = SessionLocal()
    query = session.query(Animal)
    conditions = []
    if species is not None:
        conditions.append(Animal.species == species)
    if status is not None:
        conditions.append(Animal.status == status)
    if breed is not None:
        conditions.append(Animal.breed.ilike(f"%{breed}%"))
    if age_years_min is not None:
        conditions.append(Animal.age_years >= age_years_min)
    if age_years_max is not None:
        conditions.append(Animal.age_years <= age_years_max)
    if temperament is not None:
        conditions.append(Animal.temperament == temperament)
    if intake_date_before is not None:
        conditions.append(Animal.intake_date < intake_date_before)
    if intake_date_after is not None:
        conditions.append(Animal.intake_date > intake_date_after)
    if microchip_id is not None:
        conditions.append(Animal.microchip_id == microchip_id)
    if current_location is not None:
        conditions.append(Animal.current_location.ilike(f"%{current_location}%"))
    if conditions:
        query = query.filter(and_(*conditions))
    total = query.count()
    if offset:
        query = query.offset(offset)
    if limit is not None:
        query = query.limit(limit)
    animals = query.all()
    result = AnimalListOut(
        animals=[AnimalOut.model_validate(a, from_attributes=True) for a in animals],
        total=total,
    )
    session.close()
    return result


@router.get(
    "/{id}",
    summary="Get a single animal by ID",
    description="Retrieve detailed information for a specific animal using its unique ID.",
    tags=["Animals"],
    operation_id="get_animal",
    response_model=AnimalOut,
)
async def get_animal(id: int):
    session = SessionLocal()
    animal = session.query(Animal).filter(Animal.id == id).first()
    if animal is None:
        session.close()
        raise HTTPException(status_code=404, detail="Animal not found")
    result = AnimalOut.model_validate(animal, from_attributes=True)
    session.close()
    return result


@router.post(
    "",
    summary="Create a new animal record",
    description="Add a new animal to the system with required and optional attributes.",
    tags=["Animals"],
    operation_id="create_animal",
    response_model=AnimalOut,
)
async def create_animal(payload: AnimalCreate = Body(...)):
    session = SessionLocal()
    animal = Animal(
        name=payload.name,
        species=payload.species,
        breed=payload.breed,
        birth_date=payload.birth_date,
        age_years=payload.age_years,
        temperament=payload.temperament,
        status=payload.status,
        microchip_id=payload.microchip_id,
        intake_date=payload.intake_date,
        current_location=payload.current_location,
    )
    session.add(animal)
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Integrity error: duplicate or invalid data")
    session.refresh(animal)
    result = AnimalOut.model_validate(animal, from_attributes=True)
    session.close()
    return result


@router.put(
    "/{id}",
    summary="Replace an existing animal record",
    description="Update all fields of an animal by its ID, replacing the entire record.",
    tags=["Animals"],
    operation_id="replace_animal",
    response_model=AnimalOut,
)
async def replace_animal(id: int, payload: AnimalReplace = Body(...)):
    session = SessionLocal()
    animal = session.query(Animal).filter(Animal.id == id).first()
    if animal is None:
        session.close()
        raise HTTPException(status_code=404, detail="Animal not found")
    animal.name = payload.name
    animal.species = payload.species
    animal.breed = payload.breed
    animal.birth_date = payload.birth_date
    animal.age_years = payload.age_years
    animal.temperament = payload.temperament
    animal.status = payload.status
    animal.microchip_id = payload.microchip_id
    animal.intake_date = payload.intake_date
    animal.current_location = payload.current_location
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Integrity error: duplicate or invalid data")
    session.refresh(animal)
    result = AnimalOut.model_validate(animal, from_attributes=True)
    session.close()
    return result


@router.patch(
    "/{id}",
    summary="Partially update an animal record",
    description="Update one or more fields of an existing animal without replacing the entire record.",
    tags=["Animals"],
    operation_id="update_animal",
    response_model=AnimalOut,
)
async def update_animal(id: int, payload: AnimalUpdate = Body(...)):
    session = SessionLocal()
    animal = session.query(Animal).filter(Animal.id == id).first()
    if animal is None:
        session.close()
        raise HTTPException(status_code=404, detail="Animal not found")
    update_data = payload.model_dump(exclude_unset=True)
    for field, value in update_data.items():
        setattr(animal, field, value)
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Integrity error: duplicate or invalid data")
    session.refresh(animal)
    result = AnimalOut.model_validate(animal, from_attributes=True)
    session.close()
    return result


@router.delete(
    "/{id}",
    summary="Delete an animal record",
    description="Remove an animal from the system by its unique ID.",
    tags=["Animals"],
    operation_id="delete_animal",
    response_model=DeleteOut,
)
async def delete_animal(id: int):
    session = SessionLocal()
    animal = session.query(Animal).filter(Animal.id == id).first()
    if animal is None:
        session.close()
        raise HTTPException(status_code=404, detail="Animal not found")
    session.delete(animal)
    session.commit()
    session.close()
    return DeleteOut(success=True, message="Animal deleted successfully.")