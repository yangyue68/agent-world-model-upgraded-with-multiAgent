from typing import Optional, List
from fastapi import APIRouter, Body, HTTPException, Query
from sqlalchemy.exc import IntegrityError
from database import SessionLocal
from models import User
from schemas import (
    UserCreate,
    UserReplace,
    UserUpdate,
    UserOut,
    UserListOut,
    DeleteOut,
)

router = APIRouter(prefix="/api/users", tags=["Users"])


@router.get(
    "",
    summary="List users",
    description="Retrieve staff/user accounts with optional filters.",
    tags=["Users"],
    operation_id="list_users",
    response_model=UserListOut,
)
async def list_users(
    username: Optional[str] = Query(None),
    email: Optional[str] = Query(None),
    limit: Optional[int] = Query(None),
    offset: Optional[int] = Query(0),
):
    session = SessionLocal()
    query = session.query(User)
    if username is not None:
        query = query.filter(User.username == username)
    if email is not None:
        query = query.filter(User.email == email)
    total = query.count()
    if offset:
        query = query.offset(offset)
    if limit is not None:
        query = query.limit(limit)
    users = query.all()
    result = UserListOut(
        users=[UserOut.model_validate(u, from_attributes=True) for u in users],
        total=total,
    )
    session.close()
    return result


@router.get(
    "/{id}",
    summary="Get a single user by ID",
    description="Retrieve detailed information for a specific user using their unique ID.",
    tags=["Users"],
    operation_id="get_user",
    response_model=UserOut,
)
async def get_user(id: int):
    session = SessionLocal()
    user = session.query(User).filter(User.id == id).first()
    if user is None:
        session.close()
        raise HTTPException(status_code=404, detail="User not found")
    result = UserOut.model_validate(user, from_attributes=True)
    session.close()
    return result


@router.post(
    "",
    summary="Create a new user record",
    description="Add a new staff/user account to the system.",
    tags=["Users"],
    operation_id="create_user",
    response_model=UserOut,
)
async def create_user(payload: UserCreate = Body(...)):
    session = SessionLocal()
    user = User(
        username=payload.username,
        full_name=payload.full_name,
        email=payload.email,
    )
    session.add(user)
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Integrity error: duplicate or invalid data")
    session.refresh(user)
    result = UserOut.model_validate(user, from_attributes=True)
    session.close()
    return result


@router.put(
    "/{id}",
    summary="Replace an existing user record",
    description="Update all fields of a user by their ID, replacing the entire record.",
    tags=["Users"],
    operation_id="replace_user",
    response_model=UserOut,
)
async def replace_user(id: int, payload: UserReplace = Body(...)):
    session = SessionLocal()
    user = session.query(User).filter(User.id == id).first()
    if user is None:
        session.close()
        raise HTTPException(status_code=404, detail="User not found")
    user.username = payload.username
    user.full_name = payload.full_name
    user.email = payload.email
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Integrity error: duplicate or invalid data")
    session.refresh(user)
    result = UserOut.model_validate(user, from_attributes=True)
    session.close()
    return result


@router.patch(
    "/{id}",
    summary="Partially update a user record",
    description="Update one or more fields of an existing user without replacing the entire record.",
    tags=["Users"],
    operation_id="update_user",
    response_model=UserOut,
)
async def update_user(id: int, payload: UserUpdate = Body(...)):
    session = SessionLocal()
    user = session.query(User).filter(User.id == id).first()
    if user is None:
        session.close()
        raise HTTPException(status_code=404, detail="User not found")
    update_data = payload.model_dump(exclude_unset=True)
    for field, value in update_data.items():
        setattr(user, field, value)
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        session.close()
        raise HTTPException(status_code=400, detail="Integrity error: duplicate or invalid data")
    session.refresh(user)
    result = UserOut.model_validate(user, from_attributes=True)
    session.close()
    return result


@router.delete(
    "/{id}",
    summary="Delete a user record",
    description="Remove a user from the system by their unique ID.",
    tags=["Users"],
    operation_id="delete_user",
    response_model=DeleteOut,
)
async def delete_user(id: int):
    session = SessionLocal()
    user = session.query(User).filter(User.id == id).first()
    if user is None:
        session.close()
        raise HTTPException(status_code=404, detail="User not found")
    session.delete(user)
    session.commit()
    session.close()
    return DeleteOut(success=True, message="User deleted successfully.")